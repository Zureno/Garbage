from __future__ import annotations
import sys
import json
import re
import time
import math
import html
from pathlib import Path

try:
    import requests  
except Exception as e:  
    print("ERROR: requests library required (pip install requests)")
    raise

BASE_URL = "https://cwe.mitre.org/data/definitions/{id}.html"
TITLE_RE = re.compile(r"CWE-(\d+):\s*(.+)")

# Output toggles (set to True to re-enable). Default behavior: only mismatches printed.
# SHOW_SUMMARY = True
# SHOW_EXACT_MATCHES = True
# SHOW_CLOSE_MATCHES = True
# SHOW_NOT_FOUND = True
SHOW_SUMMARY = False
SHOW_EXACT_MATCHES = False
SHOW_CLOSE_MATCHES = False
SHOW_NOT_FOUND = False

# Aggregate report filtering: by default we only persist mismatches to the
# JSON report. Set REPORT_STATUSES to an empty set (or None) to include all.
# Example to include everything:
#   REPORT_STATUSES = None
# Example to include mismatches + not_found:
#   REPORT_STATUSES = {"mismatch", "not_found"}
REPORT_STATUSES: set[str] | None = {"mismatch"}

def levenshtein(a: str, b: str):
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            cur.append(min(
                prev[j] + 1,
                cur[j - 1] + 1,
                prev[j - 1] + cost
            ))
        prev = cur
    return prev[-1]

_VERSION_SUFFIX_RE = re.compile(r"\s*\(\d+(?:\.\d+)*\)\s*$")

def normalize(s: str):
    if not s:
        return ""
    s = html.unescape(s)
    s = _VERSION_SUFFIX_RE.sub("", s)  
    s = s.replace("“", '"').replace("”", '"').replace("’", "'")
    s = re.sub(r"\s+", " ", s.strip()).lower()
    return s

_PAGE_CACHE: dict[int, str | None] = {}

def fetch_official_title(cwe_id: int, timeout: float = 8.0):
    if cwe_id in _PAGE_CACHE:
        return _PAGE_CACHE[cwe_id]
    url = BASE_URL.format(id=cwe_id)
    title: str | None = None
    try:
        r = requests.get(url, timeout=timeout)
        if r.status_code != 200:
            _PAGE_CACHE[cwe_id] = None
            return None
        text = r.text
        # Primary regex search
        m = TITLE_RE.search(text)
        if m:
            title = html.unescape(m.group(2).strip())
        else:

            for h2 in re.findall(r"<h2[^>]*>(.*?)</h2>", text, flags=re.IGNORECASE | re.DOTALL):
                raw = html.unescape(re.sub(r"<[^>]+>", "", h2)).strip()
                m2 = TITLE_RE.search(raw)
                if m2 and int(m2.group(1)) == cwe_id:
                    title = m2.group(2).strip()
                    break
    except Exception:
        title = None
    _PAGE_CACHE[cwe_id] = title
    return title

def validate(entries: list[dict]):
    results = []
    for idx, item in enumerate(entries, 1):
        raw_id = item.get("cwe_id")
        name = item.get("cwe_name", "")
        status = ""; official = None; distance = None
        cwe_id: int | None = None

        if isinstance(raw_id, int):
            cwe_id = raw_id
        elif isinstance(raw_id, str) and re.fullmatch(r"\d+", raw_id):
            try:
                cwe_id = int(raw_id)
            except ValueError:
                cwe_id = None

        if cwe_id is None:
            results.append({"cwe_id": raw_id, "provided": name, "official": official, "status": "invalid_id"})
            continue

        official = fetch_official_title(cwe_id)
        if official is None:
            status = "not_found"
        else:
            n_prov = normalize(name)
            n_off = normalize(official)
            if n_prov == n_off:
                status = "exact_match"
            else:
                distance = levenshtein(n_prov, n_off)
                thresh = max(10, math.ceil(max(len(n_prov), len(n_off))*0.15))
                status = "close_match" if distance <= thresh else "mismatch"
        results.append({
            "cwe_id": cwe_id,
            "provided": name,
            "official": official,
            "status": status,
            "levenshtein": distance
        })

        time.sleep(0.15)
    return results

def summarize(results: list[dict]):
    counts = {}
    for r in results:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    return counts

def _resolve_json(path_str: str):
    p = Path(path_str)
    if p.exists():
        return p
    if not p.is_absolute():
        alt = Path(__file__).parent / "cwemap" / path_str
        if alt.exists():
            return alt
    return p  

def main(argv: list[str]):
    script_dir = Path(__file__).parent
    cwemap_dir = script_dir / "cwemap"
    if not cwemap_dir.exists():
        print(f"cwemap directory not found: {cwemap_dir}")
        return 1
    json_files = sorted(cwemap_dir.glob("*.json"))
    if not json_files:
        print("No JSON files found in cwemap directory.")
        return 0
    
    aggregate_out = script_dir / "cwe_validation_all.json"
    if len(argv) >= 2:
        aggregate_out = _resolve_json(argv[1])
        aggregate_out.parent.mkdir(parents=True, exist_ok=True)

    all_results: list[dict] = []

    def _print_entries(label: str, items: list[dict], file_label: str):
        print(f"\n{label} ({file_label}):")
        for r in items:
            print(f"  CWE-{r['cwe_id']}: provided='{r['provided']}' official='{r['official']}' status={r['status']} distance={r['levenshtein']}")

    for jf in json_files:
        try:
            entries = json.loads(jf.read_text())
            if not isinstance(entries, list):
                print(f"Skipping {jf.name}: JSON root not a list")
                continue
        except Exception as e:
            print(f"Skipping {jf.name}: failed to parse JSON ({e})")
            continue
        results = validate(entries)
        all_results.extend({**r, "source_file": jf.name} for r in results)
        counts = summarize(results)
        if SHOW_SUMMARY:
            print(f"\nSummary for {jf.name}:")
            for k, v in sorted(counts.items()):
                print(f"  {k}: {v}")
        if SHOW_EXACT_MATCHES:
            _print_entries("Exact Matches", [r for r in results if r["status"] == "exact_match"], jf.name)
        if SHOW_CLOSE_MATCHES:
            _print_entries("Close Matches", [r for r in results if r["status"] == "close_match"], jf.name)
        if SHOW_NOT_FOUND:
            _print_entries("Not Found / Invalid", [r for r in results if r["status"] in {"not_found", "invalid_id"}], jf.name)
        mismatches = [r for r in results if r["status"] == "mismatch"]
        if mismatches:
            _print_entries("Mismatches", mismatches, jf.name)


    if REPORT_STATUSES:
        to_write = [r for r in all_results if r.get("status") in REPORT_STATUSES]
    else:
        to_write = all_results
    aggregate_out.write_text(json.dumps(to_write, indent=2))
    print(f"\nAggregate report written to {aggregate_out} (processed {len(json_files)} files)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
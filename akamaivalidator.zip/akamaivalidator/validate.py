from logger import logger

# ---------------------------------------------------------------------------
# Akamai validation — compare collected data against validator criteria
# ---------------------------------------------------------------------------


def validate_akamai(validator: dict, akamai_data: list[str]) -> bool:
    """
    Determine whether the Akamai validator passes or fails.

    Args:
        validator:   The validator definition dict, e.g.
                     {"type": "akamai", "criteria": ["akamai"]}
        akamai_data: List returned by data.get_akamai_onboarding_compliance(),
                     e.g. ["akamai"] on compliance or [] on non-compliance.

    Returns:
        True  → PASS
        False → FAIL
    """
    criteria = validator.get("criteria", [])

    for result in akamai_data:
        if result == "akamai" and criteria == ["akamai"]:
            logger.info("Akamai validation PASSED — criteria matched")
            return True

    logger.info("Akamai validation FAILED — criteria not met")
    return False

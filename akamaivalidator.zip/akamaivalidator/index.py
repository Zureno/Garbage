import json
from logger import logger
from input import extract_lambda_input
from data import get_akamai_onboarding_compliance
from validate import validate_akamai
from output import build_result, write_result


def handler(event, context):
    """
    Akamai Validator Lambda — standalone microservice.

    Expected event (direct invocation):
        {
            "identifier": "BFM",
            "control": "CDR-NSS3.4.2 - App01",
            "validator": {"type": "akamai", "criteria": ["akamai"]}
        }

    Or SNS-wrapped in event["Records"][0]["Sns"]["Message"].

    Flow:
        1. Parse input  → identifier, control name, validator config
        2. Collect data  → query Athena for Akamai onboarding compliance
        3. Validate      → compare criteria against collected data
        4. Build output  → assemble standardised result dict
        5. Write result  → persist to eqa-validation-results-table
    """
    try:
        # 1. Parse input
        identifier, control, validator = extract_lambda_input(event)

        # 2. Collect data from Athena
        logger.info(f"Querying Akamai onboarding data for AppCI {identifier}")
        akamai_data = get_akamai_onboarding_compliance(identifier)

        # 3. Validate
        passed = validate_akamai(validator, akamai_data)

        # 4. Build output
        result = build_result(identifier, control, validator, passed)
        logger.info(f"Validation result: {json.dumps(result)}")

        # 5. Write to DynamoDB
        write_result(identifier, control, validator, result)

        return result

    except Exception as e:
        logger.exception(f"Akamai validator failed: {e}")
        raise


# ---------------------------------------------------------------------------
# Local testing — run directly:  python index.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    test_event = {
        "identifier": "BFM",
        "control": "CDR-NSS3.4.2 - App01",
        "validator": {
            "type": "akamai",
            "criteria": ["akamai"]
        }
    }

    result = handler(test_event, None)
    print(json.dumps(result, indent=2))

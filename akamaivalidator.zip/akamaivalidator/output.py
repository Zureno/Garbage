import json
import boto3
from datetime import datetime
from botocore.exceptions import ClientError
from logger import logger

# ---------------------------------------------------------------------------
# DynamoDB table for validation results
# ---------------------------------------------------------------------------

TABLE_NAME = "eqa-validation-results-table"
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table(TABLE_NAME)


# ---------------------------------------------------------------------------
# Build the sort key:  control#[validator]
# ---------------------------------------------------------------------------


def build_sort_key(control: str, validator: dict) -> str:
    return f"{control}#[{validator}]"



# ---------------------------------------------------------------------------
# Evidence message builders (akamai-specific)
# ---------------------------------------------------------------------------


def _build_evidence_message(identifier: str, criteria: list, passed: bool) -> str:
    """
    Return a human-readable evidence string for the akamai validator.
    Criteria determines the message variant: ["waf"], ["bot_manager"], or generic ["akamai"].
    """
    if criteria == ["waf"]:
        if passed:
            return f"This requirement has passed because AppCI {identifier} has been onboarded to Akamai."
        return (
            f"This requirement has failed because AppCI {identifier} has not been onboarded to Akamai. "
            "To pass this requirement, please complete the HelpHub Akamai Support Request form for "
            "onboarding support: https://united.service-now.com/hrportal?id=sc_cat_item_guide"
            "&table=sc_cat_item&sys_id=2e3d3cf487893ad4a912eacd8bbb3528&searchTerm=akamai"
        )

    if criteria == ["bot_manager"]:
        if passed:
            return f"This requirement has passed because AppCI {identifier} is covered by Akamai Bot Manager."
        return f"This requirement has failed because AppCI {identifier} is not covered by Akamai Bot Manager."

    # Generic akamai criteria (e.g. ["akamai"])
    if passed:
        return "This requirement has passed; no action is required."
    return (
        f"This requirement has failed because AppCI {identifier} has not been onboarded to Akamai. "
        "To pass this requirement, please complete the HelpHub Akamai Support Request form for "
        "onboarding support: https://united.service-now.com/hrportal?id=sc_cat_item_guide"
        "&table=sc_cat_item&sys_id=2e3d3cf487893ad4a912eacd8bbb3528&searchTerm=akamai"
    )


# ---------------------------------------------------------------------------
# Build the standardised result dict
# ---------------------------------------------------------------------------


def build_result(
    identifier: str,
    control: str,
    validator: dict,
    passed: bool,
) -> dict:
    """
    Assemble the validation result dict matching the expected output schema:

        {
          "control":         str,
          "passed":          bool,
          "avit":            [],
          "number":          int,    # count of passing validators (0 or 1)
          "confidence":      str,
          "validations":     [...],
          "raw_evidence":    str,
          "evidence":        str,
          "finding_ids":     str,
          "review_required": str
        }
    """
    criteria = validator.get("criteria", [])
    status = "PASS" if passed else "FAIL"

    # Single-validator validation entry
    validation_entry = {
        "type": validator.get("type", "akamai"),
        "criteria": criteria,
        "identifier": identifier,
        "name": control,
        "status": status,
    }

    # Raw evidence — matches monolith pattern
    if passed:
        raw_evidence = (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has passed because the following criteria passed: {criteria}"
        )
    else:
        raw_evidence = (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has failed because the following criteria failed: {criteria}"
        )

    # Human-readable evidence
    evidence = _build_evidence_message(identifier, criteria, passed)

    # Truncate if exceeding ServiceNow 4000-char limit
    if len(evidence) > 4000:
        evidence = evidence[:3997] + "..."

    return {
        "control": control,
        "passed": passed,
        "avit": [],
        "number": 1 if passed else 0,
        "confidence": "",  # single validator type → "low"
        "validations": [validation_entry],
        "raw_evidence": raw_evidence,
        "evidence": evidence,
        "finding_ids": "",
        "review_required": "No",
    }


# ---------------------------------------------------------------------------
# Write result to DynamoDB
# ---------------------------------------------------------------------------


def write_result(identifier: str, control: str, validator: dict, result: dict) -> str:
    """
    Persist the validation result to eqa-validation-results-table.

    Key schema:
        PK  = identifier  (AppCI)
        SK  = control#[validator]
    """
    sort_key = build_sort_key(control, validator)
    current_date = datetime.now().strftime("%m/%d/%Y")

    try:
        table.update_item(
            Key={
                "identifier": identifier,
                "control#validator": sort_key,
            },
            UpdateExpression="SET #res = :res, last_processed = :date",
            ExpressionAttributeNames={"#res": "result"},
            ExpressionAttributeValues={
                ":res": json.dumps(result),
                ":date": current_date,
            },
            ReturnValues="UPDATED_NEW",
        )
        msg = f"Successfully updated results for identifier={identifier}, sort_key={sort_key}"
        logger.info(msg)
        return msg

    except ClientError as e:
        error_msg = f"Error updating validator result: {e.response['Error']['Message']}"
        logger.error(error_msg)
        raise ValueError(error_msg) from e

import json
from logger import logger

CONFIDENCE_MAPPING = {1: "low", 2: "medium"}


def calculate_confidence(validations):
    """
    Calculate confidence based on distinct validation types and tools.
    num = count(distinct types) + count(distinct tools) -> {1: low, 2: medium, >=3: high}
    """
    types = set()
    tools = set()
    for v in validations:
        v_type = v.get('type', '')
        if v_type:
            types.add(v_type)
        tool = v.get('tool', '')
        if tool:
            tools.add(tool)
    num = len(types) + len(tools)
    return CONFIDENCE_MAPPING.get(num, "high" if num >= 3 else "NA")


def build_raw_evidence(control_name, identifier, passed, all_validations, results):
    """Build the raw_evidence string for a control."""
    if passed:
        criteria = []
        for v in all_validations:
            criteria.extend(v.get('criteria', []))
        criteria = sorted(set(criteria))
        return (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has passed because the following criteria passed: {criteria}"
        )
    else:
        criteria = []
        for r in results:
            if not r.get('passed', False):
                for v in r.get('validations', []):
                    criteria.extend(v.get('criteria', []))
        criteria = sorted(set(criteria))
        return (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has failed because the following criteria failed: {criteria}"
        )


def build_evidence(passed, results):
    """Build the evidence string for a control."""
    if passed:
        return "This requirement has passed; no action is required."
    failed_evidence = []
    for r in results:
        if not r.get('passed', False):
            ev = r.get('evidence', '')
            if ev:
                failed_evidence.append(ev)
    return ' '.join(failed_evidence) if failed_evidence else ''


def combine_finding_ids(results):
    """Combine, deduplicate, and sort finding_ids from all results."""
    all_ids = set()
    for r in results:
        fids = r.get('finding_ids', '')
        if fids:
            for fid in fids.split(','):
                fid = fid.strip()
                if fid:
                    all_ids.add(fid)
    return ', '.join(sorted(all_ids))


def aggregate_control(control_name, identifier, results, definition="all"):
    """
    Aggregate multiple validator results for a single control into
    the format expected by the processing table's validation_results column.

    The 'definition' field from the control config determines pass logic:
      - "all": every validator must pass (default)
      - "any": at least one validator must pass
    """
    all_validations = []
    for r in results:
        all_validations.extend(r.get('validations', []))

    if definition == "any":
        passed = any(r.get('passed', False) for r in results)
    else:
        passed = all(r.get('passed', False) for r in results)
    number = sum(1 for r in results if r.get('passed', False))
    confidence = calculate_confidence(all_validations)

    all_avit = []
    for r in results:
        all_avit.extend(r.get('avit', []))

    raw_evidence = build_raw_evidence(control_name, identifier, passed, all_validations, results)
    evidence = build_evidence(passed, results)
    finding_ids = combine_finding_ids(results)

    review_required = "Yes" if any(
        r.get('review_required', 'No') == 'Yes' for r in results
    ) else "No"

    return {
        "control": control_name,
        "passed": passed,
        "avit": all_avit,
        "number": number,
        "confidence": confidence,
        "validations": all_validations,
        "raw_evidence": raw_evidence,
        "evidence": evidence,
        "finding_ids": finding_ids,
        "review_required": review_required,
    }


def parse_result(item):
    """Parse the result field from a validation results table item."""
    result_raw = item.get('result', '')
    if isinstance(result_raw, dict):
        return result_raw
    if isinstance(result_raw, str):
        try:
            return json.loads(result_raw)
        except (json.JSONDecodeError, TypeError):
            return None
    return None


def group_and_aggregate(items, definitions=None):
    """
    Group validation result items by identifier and control, then aggregate.

    Args:
        items: validation result records from DynamoDB
        definitions: dict mapping control_name -> 'any' or 'all'
    Returns: dict mapping identifier -> list of aggregated control dicts
    """
    if definitions is None:
        definitions = {}
    grouped = {}
    for item in items:
        identifier = item.get('identifier', '')
        result = parse_result(item)
        if not result:
            logger.warning(f"Skipping item with unparseable result for identifier: {identifier}")
            continue

        control_name = result.get('control', '')
        if not identifier or not control_name:
            logger.warning("Skipping item with missing identifier or control")
            continue

        grouped.setdefault(identifier, {}).setdefault(control_name, []).append(result)

    aggregated = {}
    for identifier, controls in grouped.items():
        aggregated[identifier] = []
        for control_name, results in controls.items():
            definition = definitions.get(control_name, 'all')
            aggregated[identifier].append(
                aggregate_control(control_name, identifier, results, definition)
            )
        logger.info(f"Aggregated {len(aggregated[identifier])} controls for {identifier}")

    return aggregated

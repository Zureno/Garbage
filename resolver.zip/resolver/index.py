import json
from datetime import datetime
from logger import logger
from dynamo import get_all_validation_results, update_processing_table, get_control_definition
from aggregate import group_and_aggregate


def build_definitions_map(items):
    """
    Extract unique control names from validation results and look up
    each control's definition ('any' or 'all') from the control table.
    """
    control_names = set()
    for item in items:
        result_raw = item.get('result', '')
        if isinstance(result_raw, str):
            try:
                result_raw = json.loads(result_raw)
            except (json.JSONDecodeError, TypeError):
                continue
        if isinstance(result_raw, dict):
            name = result_raw.get('control', '')
            if name:
                control_names.add(name)

    definitions = {}
    for name in control_names:
        definitions[name] = get_control_definition(name)
    logger.info(f"Loaded definitions for {len(definitions)} controls")
    return definitions


def handler(event, context):
    logger.info("Resolver lambda invoked")

    items = get_all_validation_results()
    if not items:
        logger.info("No validation results found")
        return {"statusCode": 200, "body": json.dumps({"message": "No results to process"})}

    definitions = build_definitions_map(items)
    aggregated = group_and_aggregate(items, definitions)

    current_date = datetime.now().strftime("%m/%d/%Y")
    for identifier, controls in aggregated.items():
        validation_results_json = json.dumps(controls)
        update_processing_table(identifier, validation_results_json, current_date)

    logger.info(f"Resolved validation results for {len(aggregated)} identifiers")
    return {
        "statusCode": 200,
        "body": json.dumps({"message": f"Resolved {len(aggregated)} identifiers"})
    }


if __name__ == '__main__':
    handler({}, {})

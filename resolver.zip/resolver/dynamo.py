import boto3
from logger import logger

dynamodb = boto3.resource('dynamodb')

VALIDATION_RESULTS_TABLE = 'eqa-validation-results-table'
PROCESSING_TABLE = 'eqa-cdr-processing-table'


def scan_all(table):
    """Scan all items from a DynamoDB table with pagination."""
    items = []
    response = table.scan()
    items.extend(response.get('Items', []))
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
    return items


def get_all_validation_results():
    """Scan all records from the validation results table."""
    table = dynamodb.Table(VALIDATION_RESULTS_TABLE)
    items = scan_all(table)
    logger.info(f"Scanned {len(items)} records from validation results table")
    return items


CONTROL_TABLE = 'eqa-control-table'


def get_control_definition(control_name):
    """Look up the definition field ('any' or 'all') for a control from the control table."""
    table = dynamodb.Table(CONTROL_TABLE)
    try:
        response = table.get_item(Key={'control': control_name})
        item = response.get('Item')
        if item:
            definition = item.get('definition', 'all')
            logger.info(f"Control '{control_name}' definition: '{definition}'")
            return definition
        else:
            logger.warning(f"Control '{control_name}' not found in {CONTROL_TABLE}, defaulting to 'all'")
    except Exception as e:
        logger.warning(f"Failed to fetch definition for '{control_name}': {e}, defaulting to 'all'")
    return 'all'  # default to strictest requirement


def update_processing_table(identifier, validation_results_json, current_date):
    """Update the processing table with aggregated validation results."""
    table = dynamodb.Table(PROCESSING_TABLE)
    table.update_item(
        Key={'identifier': identifier},
        UpdateExpression="SET validation_results = :val, last_processed = :date",
        ExpressionAttributeValues={
            ':val': validation_results_json,
            ':date': current_date,
        },
    )
    logger.info(f"Updated processing table for identifier: {identifier}")

"""Core Gitleaks validation logic and evidence building."""

from logger import logger


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_gitleaks(gitleaks_findings) -> bool:
    """Return True (pass) if there are no open Gitleaks findings.

    Mirrors GitleaksValidator.validate() from validation/validator/gitleaks_validator.py:
    - No findings at all → pass
    - Any finding with open_status == "true" → fail
    """
    if not gitleaks_findings:
        logger.info("Gitleaks validation PASSED — no findings returned")
        return True

    for finding in gitleaks_findings:
        if str(finding.get("open_status", "")).strip().lower() == "true":
            logger.info(
                f"Gitleaks validation FAILED — open finding detected: "
                f"{finding.get('display_name', '')}"
            )
            return False

    logger.info("Gitleaks validation PASSED — no open findings")
    return True


# ---------------------------------------------------------------------------
# Evidence building
# ---------------------------------------------------------------------------

def build_evidence(
    control_name: str,
    identifier: str,
    criteria: list,
    passed: bool,
    findings: list,
) -> tuple[str, str]:
    """Return (raw_evidence, evidence) strings.

    raw_evidence — detailed machine-oriented message stored in DynamoDB.
    evidence     — human-oriented message sent to ServiceNow.
    """
    if passed:
        raw_evidence = (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has passed because the following criteria passed: {criteria}"
        )
        evidence = "This requirement has passed; no action is required."
    else:
        open_findings = [
            f.get("display_name", "") for f in (findings or [])
            if str(f.get("open_status", "")).strip().lower() == "true"
        ]
        raw_evidence = (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has failed because the following criteria failed: {criteria}. "
            f"Open Gitleaks findings: {open_findings}"
        )
        criteria_str = ", ".join(c for c in criteria if str(c).strip())
        if criteria_str:
            evidence = f"Gitleaks-fail: {criteria_str}"
        else:
            evidence = "Gitleaks-fail: This control has not been implemented yet"

    return raw_evidence, evidence


# ---------------------------------------------------------------------------
# Finding ID extraction
# ---------------------------------------------------------------------------

def extract_finding_ids(findings: list) -> str:
    """Return a comma-separated string of open finding display names."""
    if not findings:
        return ""
    ids = [
        str(f.get("display_name", ""))
        for f in findings
        if str(f.get("open_status", "")).strip().lower() == "true"
        and f.get("display_name")
    ]
    return ", ".join(ids)

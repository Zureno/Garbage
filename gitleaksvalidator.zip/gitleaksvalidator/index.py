"""Standalone Gitleaks validator Lambda.

Receives an event with {identifier, control, validator} (via SNS/SQS or direct),
queries the Gitleaks findings from the Athena datalake, runs the validation,
builds evidence, writes results to the validation-results table, and returns
the normalised control output.
"""

import boto3
from logger import logger
from input import extract_lambda_input
from output import build_lambda_output, build_sort_key, write_validator_result
from data import GitleaksData, get_control_record
from validate import validate_gitleaks, build_evidence, extract_finding_ids
from helpers import get_control_confidence, check_snow_limit

# ---------------------------------------------------------------------------
# DynamoDB table for per-validator results
# ---------------------------------------------------------------------------
RESULTS_TABLE_NAME = "eqa-validation-results-table"
_dynamodb = boto3.resource("dynamodb")
_results_table = _dynamodb.Table(RESULTS_TABLE_NAME)


def handler(event, context):
    """Lambda entry point."""
    logger.info(f"Event received: {event}")

    # ---- 1. Parse input --------------------------------------------------
    identifier, control_name, validator = extract_lambda_input(event)

    criteria = validator.get("criteria", [])
    validator_type = validator.get("type", "gitleaks")

    # ---- 2. Fetch Gitleaks findings from Athena --------------------------
    gitleaks_data = GitleaksData()
    findings = gitleaks_data.get_gitleaks_findings(identifier)
    logger.info(f"Fetched {len(findings) if findings else 0} Gitleaks findings for {identifier}")

    # ---- 3. Run validation -----------------------------------------------
    passed = validate_gitleaks(findings)
    status_label = "PASS" if passed else "FAIL"

    # ---- 4. Build evidence -----------------------------------------------
    raw_evidence, evidence = build_evidence(
        control_name, identifier, criteria, passed, findings
    )

    # ---- 5. Extract finding IDs ------------------------------------------
    finding_ids = extract_finding_ids(findings)

    # ---- 6. Build the validation detail record ---------------------------
    validation_record = {
        "type": validator_type,
        "criteria": criteria,
        "identifier": identifier,
        "name": control_name,
        "status": status_label,
    }

    # ---- 7. Determine confidence (single validation type → "low") --------
    confidence = get_control_confidence(1)

    # ---- 8. Determine review_required from control table -----------------
    review_required = "No"
    control_record = get_control_record(control_name)
    if control_record:
        skip_failure = control_record.get("skip_failure", {}).get("BOOL", False)
        skip_pass = control_record.get("skip_pass", {}).get("BOOL", False)
        if skip_failure and not passed:
            review_required = "Yes"
        if skip_pass and passed:
            review_required = "Yes"

    # ---- 9. Build normalised output --------------------------------------
    number = 1 if passed else 0
    result = build_lambda_output(
        control=control_name,
        passed=passed,
        avit=[],
        number=number,
        confidence=confidence,
        validations=[validation_record],
        raw_evidence=raw_evidence,
        evidence=evidence,
        finding_ids=finding_ids,
        review_required=review_required,
    )

    # Apply ServiceNow size limit
    result = check_snow_limit(result)

    # ---- 10. Persist to DynamoDB -----------------------------------------
    sort_key = build_sort_key(control_name, validator)
    write_validator_result(_results_table, identifier, sort_key, result)

    logger.info(
        f"Gitleaks validation complete — control={control_name}, "
        f"identifier={identifier}, passed={passed}"
    )
    return result


# ---------------------------------------------------------------------------
# Local testing
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import json

    test_event = {
        "identifier": "RDL",
        "control": "DS3.5.2-App02",
        "validator": {
            "type": "gitleaks",
            "criteria": ["gitleaks"],
        },
    }

    print("\n=== Test Event ===")
    print(json.dumps(test_event, indent=2))
    print("==================\n")

    result = handler(test_event, None)

    print("\n=== Result ===")
    print(json.dumps(result, indent=2))
    print("==============\n")

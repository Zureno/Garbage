"""Parse incoming Lambda events (SNS/SQS-triggered or direct invocation)."""

import json
from logger import logger


def extract_lambda_input(event: dict) -> tuple[str, str, dict]:
    """Return (identifier, control, validator) from the Lambda event.

    Supports three formats:
      A. SQS-triggered  — event["Records"][0]["body"]
      B. SNS-triggered  — event["Records"][0]["Sns"]["Message"]
      C. Direct / QA    — event used directly as body
    """
    if "Records" in event:
        try:
            record = event["Records"][0]
            if "body" in record:
                raw = record["body"]
                logger.info("Parsed SQS message body")
            else:
                raw = record["Sns"]["Message"]
                logger.info("Parsed SNS message body")
            body = json.loads(raw)
        except (KeyError, IndexError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not parse message from event: {exc}") from exc
    else:
        body = event
        logger.info("Direct invocation body received")

    identifier: str = body.get("identifier", "")
    control: str = body.get("control", "")
    validator = body.get("validator")

    if isinstance(validator, str):
        try:
            validator = json.loads(validator)
        except json.JSONDecodeError as exc:
            raise ValueError(f"'validator' field is not valid JSON: {exc}") from exc

    missing = [
        name
        for name, val in [("identifier", identifier), ("control", control), ("validator", validator)]
        if not val
    ]
    if missing:
        raise ValueError(f"Missing required field(s) in lambda event: {missing}")

    if not isinstance(validator, dict):
        raise ValueError(f"'validator' must be a dict, got {type(validator).__name__}")

    logger.info(
        f"Input extracted — identifier: {identifier!r}, "
        f"control: {control!r}, validator type: {validator.get('type')!r}"
    )
    return identifier, control, validator

"""Gitleaks data layer — fetches findings from the Athena datalake."""

import os
import boto3
from datetime import datetime, timedelta

from config import CONFIG
from logger import logger
from helpers import (
    sanitize_identifier,
    construct_secure_query,
    execute_athena_query,
    wait_for_query,
    get_query_results,
)


def get_ual_env():
    return os.getenv("UAL_ENV", "").lower()


ual_env = None if CONFIG.get("ENV", "").lower() == "local" else get_ual_env()


class GitleaksData:
    """Fetch Gitleaks findings for a given AppCI from the shared datalake."""

    def get_gitleaks_findings(self, appci: str):
        try:
            if not appci:
                raise Exception("Parameter appci is mandatory")

            yesterday_ymd = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

            safe_database = sanitize_identifier(
                "appsec_database_for_datalake_shared_resources"
            )
            safe_table_name = sanitize_identifier("vipr_findings_shared")

            columns = [
                "Appci",
                "source",
                "closed_timestamp",
                "remediation_description",
                "severity",
                "display_name",
                "risk_score",
                "open_status",
            ]

            where_clauses = [
                {"column": "Appci", "operator": "=", "value": appci},
                {"column": "source", "operator": "=", "value": "Gitleaks"},
                {"column": "Appci", "operator": "<>", "value": "NA"},
            ]

            if CONFIG.get("ENV", "").lower() == "local":
                # columns.append("partition_0")
                # where_clauses.append(
                #     {"column": "partition_0", "operator": "=", "value": "2025-10-28"}
                # )
                pass
            elif ual_env == "dev":
                # where_clauses.append(
                #     {"column": "partition_0", "operator": "=", "value": "2025-10-28"}
                # )
                pass
            else:
                columns.append("partition_0")
                where_clauses.append(
                    {"column": "partition_0", "operator": "=", "value": yesterday_ymd}
                )

            order_by_clauses = [{"column": "closed_timestamp", "ascending": False}]

            sql_query = construct_secure_query(
                safe_table_name,
                columns,
                where_clauses,
                order_by_clauses,
                distinct=True,
            )

            qid = execute_athena_query(safe_database, sql_query, workgroup="primary")
            wait_for_query(qid)
            query_results = get_query_results(qid)

            if query_results is False:
                logger.error(
                    f"Athena query returned False for appci={appci} (Gitleaks). "
                    "Possible rate limit or query failure."
                )
                logger.info(f"The query was: {sql_query}")

            return query_results

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get Gitleaks findings for appci: {appci}. Error={error}"
            )


# ---------------------------------------------------------------------------
# Control-table lookup (shared pattern from onboardedvalidator)
# ---------------------------------------------------------------------------

def get_control_record(control_name: str) -> dict | None:
    """Look up a control from the control table for skip_failure / skip_pass flags.

    Returns the raw DynamoDB item dict, or None if not found.
    """
    dynamo = boto3.client("dynamodb")
    resp = dynamo.scan(
        TableName="eqa-control-table",
        FilterExpression="enabled = :enabled AND control = :ctrl",
        ExpressionAttributeValues={
            ":enabled": {"BOOL": True},
            ":ctrl": {"S": control_name},
        },
    )
    items = resp.get("Items", [])
    return items[0] if items else None

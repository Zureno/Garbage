"""Helper utilities for the gitleaks validator Lambda.

Contains Athena query utilities, SQL builder, sanitize_identifier,
confidence mapping, and ServiceNow size-limit check.

Follows the same pattern as findingsvalidator/helpers.py — all Athena
utilities live here as flat functions; no shared/ subfolder is needed.
"""

import os
import re
import time
import boto3
from typing import List, Optional
from botocore.exceptions import ClientError
from sqlalchemy import Table, Column, MetaData, String, select, and_, func

from logger import logger
from config import CONFIG


# ---------------------------------------------------------------------------
# Environment / Region / S3 bucket
# ---------------------------------------------------------------------------

if CONFIG["ENV"] == "dev":
    REGION = os.environ.get("AWS_REGION", "us-east-1")
else:
    REGION = "us-east-1"

ENV = CONFIG["ENV"]  # Use local config for testing
# ENV = get_ssm_parameter("/eqa/udcrm-control-automation/config/env")  # Uncomment for production

if REGION == "us-east-1":
    S3_BUCKET = f"s3://eqa-udcrm-datalake-bucket-{ENV}"
else:
    S3_BUCKET = f"s3://eqa-udcrm-datalake-bucket-{ENV}-{REGION}"

athena_client = boto3.client("athena", region_name=REGION)


# ---------------------------------------------------------------------------
# Athena utilities
# ---------------------------------------------------------------------------

def execute_athena_query(database: str, query: str, workgroup: str = "primary") -> str:
    """Start an Athena query (non-blocking) and return the QueryExecutionId."""
    params = {
        "QueryString": query,
        "QueryExecutionContext": {"Database": database},
        "ResultConfiguration": {"OutputLocation": S3_BUCKET},
        "WorkGroup": workgroup,
    }
    response = athena_client.start_query_execution(**params)
    return response["QueryExecutionId"]


def wait_for_query(query_execution_id: str, max_wait: int = 300, poll_interval: int = 5) -> None:
    """Block until the Athena query succeeds, or raise on failure / timeout."""
    elapsed = 0
    while elapsed < max_wait:
        response = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
        state = response["QueryExecution"]["Status"]["State"]
        if state == "SUCCEEDED":
            return
        if state in ("FAILED", "CANCELLED"):
            reason = response["QueryExecution"]["Status"].get("StateChangeReason", "Unknown")
            raise RuntimeError(f"Athena query {query_execution_id} {state}: {reason}")
        time.sleep(poll_interval)
        elapsed += poll_interval
    raise TimeoutError(f"Athena query {query_execution_id} did not complete in {max_wait}s")


def get_query_results(query_execution_id: str) -> list[dict]:
    """Fetch all result rows from a completed Athena query as a list of dicts."""
    results = []
    next_token = None

    while True:
        kwargs = {"QueryExecutionId": query_execution_id}
        if next_token:
            kwargs["NextToken"] = next_token

        response = athena_client.get_query_results(**kwargs)
        columns = [
            col["Name"] for col in response["ResultSet"]["ResultSetMetadata"]["ColumnInfo"]
        ]
        rows = response["ResultSet"]["Rows"][1:] if not results else response["ResultSet"]["Rows"]
        for row in rows:
            values = [cell.get("VarCharValue", "") for cell in row["Data"]]
            results.append(dict(zip(columns, values)))

        next_token = response.get("NextToken")
        if not next_token:
            break

    return results


# ---------------------------------------------------------------------------
# Identifier sanitiser + SQL builder
# ---------------------------------------------------------------------------

def sanitize_identifier(identifier: str) -> str:
    """Remove any characters that are not alphanumeric or underscores."""
    sanitized = re.sub(r"[^\w]", "", identifier)
    if sanitized and sanitized[0].isdigit():
        sanitized = "_" + sanitized
    return sanitized


def construct_secure_query(
    table_name: str,
    columns: List[str],
    where_clauses: Optional[List[dict]] = None,
    order_by_clauses: Optional[List[dict]] = None,
    limit: Optional[int] = None,
    distinct: Optional[bool] = False,
) -> str:
    metadata = MetaData()
    table = Table(table_name, metadata, *(Column(col, String) for col in columns))

    query = select(*[table.c[col] for col in columns])
    if distinct:
        query = query.distinct()

    custom_conditions = []
    conditions = []
    if where_clauses:
        for clause in where_clauses:
            if "custom" in clause:
                custom_conditions.append(clause["custom"])
            else:
                column = clause["column"]
                operator = clause["operator"]
                value = clause["value"]
                if operator == "=":
                    conditions.append(table.c[column] == value)
                elif operator == "<>":
                    conditions.append(table.c[column] != value)
                elif operator == ">":
                    conditions.append(table.c[column] > value)
                elif operator == "<":
                    conditions.append(table.c[column] < value)
                elif operator == ">=":
                    conditions.append(table.c[column] >= value)
                elif operator.lower() == "in":
                    conditions.append(table.c[column].in_(value))
                elif operator.lower() == "like":
                    conditions.append(table.c[column].like(value))
                elif operator.lower() == "regexp":
                    conditions.append(func.REGEXP_LIKE(table.c[column], value))

    sql_string = str(query.compile(compile_kwargs={"literal_binds": True}))

    if conditions or custom_conditions:
        where_parts = []
        if conditions:
            compiled_where = str(
                and_(*conditions).compile(compile_kwargs={"literal_binds": True})
            )
            if compiled_where.startswith("AND "):
                compiled_where = compiled_where[4:]
            where_parts.append(compiled_where)
        if custom_conditions:
            where_parts.append(" AND ".join(custom_conditions))
        full_where = " AND ".join(wp for wp in where_parts if wp)
        if "WHERE" in sql_string:
            parts = sql_string.split("WHERE", 1)
            sql_string = f"{parts[0]}WHERE {full_where} AND ({parts[1].strip()})"
        else:
            sql_string += f" WHERE {full_where}"

    if order_by_clauses:
        for clause in order_by_clauses:
            col = clause["column"]
            direction = "ASC" if clause.get("ascending", True) else "DESC"
            sql_string += f" ORDER BY {col} {direction}"

    if limit is not None:
        sql_string += f" LIMIT {limit}"

    logger.info(f"Constructed SQL Query: {sql_string}")
    return sql_string


# ---------------------------------------------------------------------------
# Confidence + ServiceNow size limit
# ---------------------------------------------------------------------------

def get_control_confidence(num_validation_types: int) -> str:
    """Map the number of distinct validation types to a confidence label."""
    mapping = {1: "low", 2: "medium"}
    return mapping.get(num_validation_types, "high" if num_validation_types >= 3 else "NA")


def check_snow_limit(control_status: dict) -> dict:
    """Truncate raw_evidence if it exceeds the ServiceNow 4 000-char limit."""
    limit_msg = (
        "Size limit exceeded. Review output in Value field "
        "for more information about this control validation."
    )
    if "raw_evidence" in control_status:
        if len(str(control_status["raw_evidence"])) > 4000:
            control_status["raw_evidence"] = limit_msg
    return control_status

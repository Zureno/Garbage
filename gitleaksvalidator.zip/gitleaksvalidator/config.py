CONFIG = {
    "ENV": "dev",       # Change to "local" for local testing
    "USE_API": False    # Unused by this validator; kept for consistency
}

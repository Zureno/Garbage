import requests
import json
import logging
from typing import Dict, List, Optional, Any
import urllib3
from shared.secrets_manager import get_secret
from .logger import logger

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
TPP_API_SCOPE = "configuration"
TPP_API_CLIENTID = "venafiAuthToken"

# UPDATE ME
TPP_HOSTNAME = "venafi.ual.com"
BASE_URL = f"https://{TPP_HOSTNAME}"


class VenafiAPIClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        self.access_token = None

    def get_oauth_token(self, username: Optional[str] = None, password: Optional[str] = None):
        uri = f"{self.base_url}/vedauth/authorize/oauth"
        payload = {
            "client_id": TPP_API_CLIENTID,
            "username": username,
            "password": password,
            "scope": "certificate:manage,discover;configuration:manage",
        }

        logger.debug(f"Requesting OAuth token from {uri}")

        try:
            response = requests.post(uri, json=payload, verify=False)
            response.raise_for_status()
            auth_data = response.json()

            self.access_token = auth_data.get("access_token")
            self.headers["Authorization"] = f"Bearer {self.access_token}"

            logger.info("OAuth token obtained successfully")
            return auth_data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get OAuth token: {str(e)}")
            raise

    def config_find_objects_of_class(self, class_name: str, search_start: str, recursive: bool = False) -> Dict:
        uri = f"{self.base_url}/vedsdk/Config/FindObjectsOfClass"
        payload = {
            "Class": class_name,
            "ObjectDN": search_start,
            "Recursive": str(recursive).lower(),
        }

        logger.debug(f"FindObjectsOfClass request: {json.dumps(payload, indent=2)}")

        try:
            response = requests.post(uri, headers=self.headers, json=payload, verify=False)
            response.raise_for_status()
            result = response.json()
            logger.debug(f"FindObjectsOfClass response: Found {len(result.get('Objects', []))} objects")
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Config-FindObjectsOfClass failed: {str(e)}")
            raise

    def metadata_find_item(self, name: str) -> Dict:
        uri = f"{self.base_url}/vedsdk/Metadata/FindItem"
        payload = {"Name": name}

        logger.debug(f"Metadata-FindItem request: {name}")

        try:
            response = requests.post(
                uri, headers=self.headers, json=payload, verify=False
            )
            response.raise_for_status()
            result = response.json()
            logger.debug(f"Metadata-FindItem response: {json.dumps(result, indent=2)}")
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Metadata-FindItem failed: {str(e)}")
            raise

    def metadata_find(self, item_guid: str, value: str) -> Dict:
        uri = f"{self.base_url}/vedsdk/Metadata/Find"
        payload = {"ItemGuid": item_guid, "Value": value}
        print(f"payload this {payload}")

        logger.debug(f"Metadata-Find request: {json.dumps(payload, indent=2)}")

        try:
            response = requests.post(uri, headers=self.headers, json=payload, verify=False)
            response.raise_for_status()
            result = response.json()
            logger.debug(f"Metadata-Find response: Found {len(result.get('Objects', []))} objects")
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Metadata-Find failed: {str(e)}")
            raise


def find_appci_using_metadata_find(base_url, custom_field_name, appci_identifier, username, password):
    client = VenafiAPIClient(base_url)
    client.get_oauth_token(username, password)

    custom_field_info = client.metadata_find_item(custom_field_name)
    custom_field_guid = custom_field_info.get("ItemGuid")

    search_value = f"*{appci_identifier}*"

    try:
        result = client.metadata_find(item_guid=custom_field_guid, value=search_value)

        objects = result.get("Objects", [])
        logger.info(f"Found {len(objects)} objects for AppCI '{appci_identifier}'")

        return objects

    except Exception as e:
        logger.error(f"Search failed for AppCI '{appci_identifier}': {e}", exc_info=True)
        return []


class VenafiData:
    def __init__(self):
        evidence_secret = get_secret()
        self.password = evidence_secret["VENAFI_KEY"]
        self.username = evidence_secret["VENAFI_USERNAME"]
        self.base_url = BASE_URL

    def get_venafi_findings(self, identifier: str):
        logger.info(f"Checking if AppCI '{identifier}' is onboarded in Venafi")

        results = find_appci_using_metadata_find(
            base_url=self.base_url,
            custom_field_name="CI",
            appci_identifier=identifier,
            username=self.username,
            password=self.password,
        )

        count = len(results)
        raw_evidence = results  # list of object dicts from Venafi

        logger.info(
            f"AppCI '{identifier}' -> {count} certificate(s) found in Venafi"
        )
        return raw_evidence

import json
import re
import time
import urllib.parse

import boto3
import jwt
import requests
from botocore.exceptions import ClientError

from .logger import logger


def _load_evidence_secrets(secret_id="eqa-evidence-integrations"):
    """Match ghas.py (shared) when available; otherwise codeql.py (boto3)."""
    try:
        from shared.secrets_manager import get_secret

        return get_secret()
    except ImportError:
        session = boto3.session.Session()
        client = session.client(service_name="secretsmanager", region_name="us-east-1")
        try:
            response = client.get_secret_value(SecretId=secret_id)
        except ClientError as e:
            logger.error(f"Error fetching secret: {e}")
            raise e
        return json.loads(response["SecretString"])


class GhasData:
    """
    Single GitHub Advanced Security data client: CodeQL (repo code-scanning alerts)
    and org-level secret scanning alerts.
    """

    ORG = "United-Airlines-Org"
    API_BASE = "https://api.github.com"
    SEARCH_API_BASE = "https://api.github.com/search/"
    PER_PAGE = 100

    def __init__(self):
        self.api_base = self.API_BASE
        self.search_api_base = self.SEARCH_API_BASE
        self.token = None
        self.token_expires_at = 0
        self.evidence_secrets = _load_evidence_secrets()
        self.key = self.evidence_secrets["Git-App-Key"].replace("\\n", "\n")
        self.clientid = self.evidence_secrets["Git-App-ClientID"]
        self.installid = self.evidence_secrets["Git-App-InstallID"]
        self._gen_new_gitaccess()

    def _gen_new_gitaccess(self):
        self._generate_jwt()
        self._get_installation_token()

    def _generate_jwt(self):
        payload = {
            "iat": int(time.time()),
            "exp": int(time.time()) + 590,
            "iss": self.clientid,
        }
        self.jwt_token = jwt.encode(payload, self.key, algorithm="RS256")

    def _get_installation_token(self):
        headers = {
            "Authorization": f"Bearer {self.jwt_token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        url = f"{self.api_base}/app/installations/{self.installid}/access_tokens"
        response = requests.post(url, headers=headers)
        data = response.json()
        self.token = data["token"]
        self.token_expires_at = int(time.time()) + 3300
        logger.info(f"GitHub token refreshed, expires at {self.token_expires_at}")

    def _ensure_valid_token(self):
        if int(time.time()) >= self.token_expires_at - 60:
            logger.info("GitHub token expired or expiring soon, refreshing...")
            self._gen_new_gitaccess()

    def _headers(self):
        return {
            "Authorization": "token {}".format(self.token),
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    # --- Secret scanning (from ghas.py) ---

    def _paginate(self, url, params=None):
        results = []
        page = 1
        while True:
            full_url = f"{url}?per_page={self.PER_PAGE}&page={page}&secret_type=password"
            # full_url = f"{url}?per_page={self.PER_PAGE}&page={page}"  # all secret types
            if params:
                for k, v in params.items():
                    full_url += f"&{k}={v}"
            self._ensure_valid_token()
            response = requests.get(full_url, headers=self._headers())
            if response.status_code == 401:
                logger.warning("GHAS token expired, refreshing...")
                self._gen_new_gitaccess()
                response = requests.get(full_url, headers=self._headers())
            response.raise_for_status()
            page_data = response.json()
            if not page_data:
                break
            results.extend(page_data)
            page += 1
        return results

    def get_ghas_findings(self, appci):
        try:
            if not appci:
                raise Exception("Parameter appci is mandatory")

            url = f"{self.API_BASE}/orgs/{self.ORG}/secret-scanning/alerts"

            all_alerts = self._paginate(url)
            logger.info(f"Fetched {len(all_alerts)} total org-level GHAS alerts")

            appci_lower = appci.lower()
            filtered = []
            for alert in all_alerts:
                repo_full_name = alert.get("repository", {}).get("full_name", "")
                repo_name = alert.get("repository", {}).get("name", "")
                if appci_lower in repo_name.lower():
                    alert["repo_name"] = repo_full_name
                    filtered.append(alert)

            logger.info(f"Filtered to {len(filtered)} GHAS alerts for appci: {appci}")
            return filtered

        except requests.HTTPError as http_err:
            status = http_err.response.status_code if http_err.response else "unknown"
            logger.error(f"GitHub API HTTP error {status} for appci {appci}: {http_err}")
            raise Exception(f"Could not get GHAS findings for appci: {appci}. Error={http_err}")
        except Exception as error:
            logger.error(error)
            raise Exception(f"Could not get GHAS findings for appci: {appci}. Error={error}")

    #Codeql code scanning

    def _get_repos_by_appci(self, appci):
        self._ensure_valid_token()
        query_string = f"props.AppCI:{appci} org:United-Airlines-Org archived:false"
        url = f"{self.search_api_base}repositories?q={urllib.parse.quote(query_string)}&per_page=100"
        repos = []

        try:
            response = requests.get(url, headers=self._headers())
            if response.status_code == 200:
                data = response.json()
                for repo in data.get("items", []):
                    repo_full_name = repo["full_name"]
                    if repo_full_name not in repos:
                        repos.append(repo_full_name)
                logger.info(f"Found {len(repos)} repositories for AppCI: {appci}")
            else:
                logger.warning(f"Error fetching repos for AppCI {appci}: {response.status_code} - {response.text}")

        except Exception as e:
            logger.error(f"Exception fetching repos for AppCI {appci}: {e}")
            return []

        return repos

    def _get_code_scanning_alerts(self, repo_owner, repo_name):
        self._ensure_valid_token()
        url = f"{self.api_base}/repos/{repo_owner}/{repo_name}/code-scanning/alerts"
        params = {
            "state": "open",
            "per_page": 100,
        }
        all_alerts = []

        try:
            while url:
                response = requests.get(url, headers=self._headers(), params=params)

                if response.status_code == 200:
                    alerts = response.json()
                    all_alerts.extend(alerts)

                    if "Link" in response.headers:
                        links = response.headers["Link"].split(",")
                        url = None
                        for link in links:
                            if 'rel="next"' in link:
                                url = link[link.find("<") + 1 : link.find(">")]
                                params = None
                                break
                    else:
                        url = None

                elif response.status_code == 404:
                    logger.warning(f"Code scanning not enabled or accessible for {repo_owner}/{repo_name}")
                    logger.debug(f"404 Response body: {response.text}")
                    break
                elif response.status_code == 401:
                    logger.error(f"Authentication failed for {repo_owner}/{repo_name} - token may be invalid")
                    logger.debug(f"401 Response body: {response.text}")
                    self._gen_new_gitaccess()
                    logger.info("Refreshed token after 401, retrying...")
                    continue
                else:
                    logger.warning(
                        f"Error fetching code scanning alerts for {repo_owner}/{repo_name}: "
                        f"{response.status_code} - {response.text}"
                    )
                    break

        except Exception as e:
            logger.error(f"Exception fetching code scanning alerts for {repo_owner}/{repo_name}: {e}")
            return []

        return all_alerts

    def get_codeql_findings(self, appci):
        try:
            if appci is None:
                raise Exception("Parameter appci is mandatory")

            repos = self._get_repos_by_appci(appci)

            if not repos:
                logger.info(f"No repositories found for AppCI: {appci}")
                return []

            all_vulns = []

            for repo_full_name in repos:
                parts = repo_full_name.split("/")
                if len(parts) != 2:
                    logger.warning(f"Skipping invalid repo name: {repo_full_name}")
                    continue

                repo_owner = parts[0]
                repo_name = parts[1]

                try:
                    alerts = self._get_code_scanning_alerts(repo_owner, repo_name)

                    for alert in alerts:
                        rule = alert.get("rule", {})
                        description = rule.get("full_description") or rule.get("description", "")

                        normalized = {
                            "display_name": str(alert.get("number", "")),
                            "remediation_description": description,
                            "rule_id": alert.get("rule", {}).get("id", ""),
                            "cwes": self._extract_cwes(alert),
                            "severity": alert.get("rule", {}).get("security_severity_level", "").upper(),
                            "scan_type": "CODEQL",
                            "repository": repo_full_name,
                            "path": alert.get("most_recent_instance", {}).get("location", {}).get("path", ""),
                            "state": alert.get("state", ""),
                            "html_url": alert.get("html_url", ""),
                        }
                        all_vulns.append(normalized)

                except Exception as e:
                    logger.warning(f"Error processing alerts for {repo_full_name}: {e}")
                    continue

            logger.info(f"Total CodeQL findings for AppCI {appci}: {len(all_vulns)}")
            return all_vulns

        except Exception as error:
            logger.error(error)
            raise Exception(f"Could not get CodeQL findings for appci: {appci}. Error={error}")

    def _extract_cwes(self, alert):
        try:
            tags = alert.get("rule", {}).get("tags", [])
            cwe_tags = []
            for tag in tags:
                match = re.search(r"cwe-(\d+)", str(tag).lower())
                if match:
                    cwe_num = match.group(1)
                    cwe_tags.append(f"CWE-{cwe_num}")
            if cwe_tags:
                return str(cwe_tags)
            rule_id = alert.get("rule", {}).get("id", "")
            return str([rule_id]) if rule_id else "[]"

        except Exception as e:
            logger.warning(f"Error extracting CWEs from alert: {e}")
            return "[]"


# Backward-compatible alias for validators that imported CodeqlData from codeql_data.py
CodeqlData = GhasData

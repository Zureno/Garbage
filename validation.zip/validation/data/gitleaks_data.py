from shared.athena_integration import AthenaIntegration
from datetime import datetime, timedelta
import os
import boto3
from .logger import logger
from shared.config import CONFIG


def get_ual_env():
    return os.getenv("UAL_ENV", "").lower()

ual_env = None if CONFIG.get("ENV", "").lower() == "local" else get_ual_env()


class GitleaksData(AthenaIntegration):

    def __init__(self):
        self.database = super()
        self.athena_client = boto3.client('athena')

    def get_gitleaks_findings(self, appci):
        try:
            if not appci:
                raise Exception("Parameter appci is mandatory")

            # Yesterday's date for partition filter
            yesterday_ymd = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

            safe_database = self.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.sanitize_identifier("vipr_findings_shared")

            columns = [
                "Appci",
                "source",
                "closed_timestamp",
                "remediation_description",
                "severity",
                "display_name",
                "risk_score",
                "open_status",
            ]

            where_clauses = [
                {'column': 'Appci', 'operator': '=', 'value': appci},
                {'column': 'source', 'operator': '=', 'value': 'Gitleaks'},
                {'column': 'Appci', 'operator': '<>', 'value': 'NA'},
            ]

            if CONFIG.get("ENV", "").lower() == "local":
                columns.append("partition_0")
                where_clauses.append({'column': 'partition_0', 'operator': '=', 'value': "2025-10-28"})
            elif ual_env == "dev":
                where_clauses.append({'column': 'partition_0', 'operator': '=', 'value': "2025-10-28"})
            else:
                columns.append("partition_0")
                where_clauses.append({'column': 'partition_0', 'operator': '=', 'value': yesterday_ymd})

            order_by_clauses = [
                {'column': 'closed_timestamp', 'ascending': False}
            ]

            sql_query = self.construct_secure_query(
                safe_table_name,
                columns,
                where_clauses,
                order_by_clauses,
                distinct=True
            )

            query_results = self.execute_athena_query(safe_database, sql_query, blocking=True, workgroup='primary')

            if query_results is False:
                logger.error(f"Athena query returned False for appci={appci} (Gitleaks). Possible rate limit.")
                logger.info(f"The query was: {sql_query}")

            return query_results

        except Exception as error:
            logger.error(error)
            raise Exception(f"Could not get Gitleaks findings for appci: {appci}. Error={error}")
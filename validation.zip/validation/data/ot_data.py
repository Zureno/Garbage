from shared.athena_integration import AthenaIntegration
from datetime import datetime, timedelta
import logging
import os
import boto3
from .logger import logger

class OTData(AthenaIntegration):

    def __init__(self):
        self.database = super()
        self.athena_client = boto3.client('athena')

    def get_ot_findings(self, appci):
        try:
            if appci is None:
                raise Exception('Parameter appci is mandatory')
            
            safe_database = self.database.sanitize_identifier("appsec_database_for_datalake_shared_resources")
            safe_table_name = self.database.sanitize_identifier("armis_device_data_shared")
            one_year_ago = datetime.now() - timedelta(days=365)
            one_year_ago_str = one_year_ago.strftime('%Y-%m-%d')

            #In the future, pull additional data columns here
            columns = ['boundaries', "customproperties", "id", "partition_0"]
            
            # Applicable Filters: 
            # 1. Must have an associated AppCI
            # 2. Must be an OT device
            # 3. Must not be stale data (<1 year old)
            where_clauses = [
                {'column': 'boundaries', 'operator': 'LIKE', 'value': f'%ApplicationCI: {appci[:3]}%'},
                {'column': 'boundaries', 'operator': 'LIKE', 'value': f'%All OT Boundaries%'},
                {'column': 'customproperties', 'operator': 'LIKE', 'value': f'%Compliant%'},
                {'column': 'partition_0', 'operator': '>=', 'value': one_year_ago_str}\
            ]

            order_by_clauses = [
                {'column': 'partition_0', 'ascending': False}
            ]

            #Because the same appci has multiple entries, pull all
            sql_query = self.database.construct_secure_query(safe_table_name,
                                                    columns,
                                                    where_clauses,
                                                    order_by_clauses)
            
            query_results = self.database.execute_athena_query(safe_database, sql_query)

            #Contains list of ALL results; need to dedupe by pulling most recent
            #record of each unique device id.
            # Query results are ordered with newest first; if a new id is seen, add.
            def dedupe(query_results):
                seen = set()
                deduped = []

                for result in query_results:
                    res_id = result["id"]
                    if res_id not in seen:
                        deduped.append(result)
                        seen.add(res_id)
                return deduped

            deduped_res = dedupe(query_results)
            return deduped_res

        except Exception as error:
            logger.error(error)
            raise Exception(
                f"Could not get findings for appci: {appci}. Error={error}")
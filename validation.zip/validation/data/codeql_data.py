import requests
import jwt
import time
import boto3
from botocore.exceptions import ClientError
import urllib.parse
import json
import re
from .logger import logger


class CodeqlData:

    def __init__(self):
        self.api_base = "https://api.github.com"
        self.search_api_base = "https://api.github.com/search/"
        self.token = None
        self.token_expires_at = 0
        self.evidence_secrets = self._get_secret()
        self.key = self.evidence_secrets["Git-App-Key"].replace('\\n', '\n')
        self.clientid = self.evidence_secrets["Git-App-ClientID"]
        self.installid = self.evidence_secrets["Git-App-InstallID"]
        self._gen_new_gitaccess()

    def _get_secret(self, secret_id="eqa-evidence-integrations"):
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name='us-east-1'
        )
        try:
            response = client.get_secret_value(SecretId=secret_id)
        except ClientError as e:
            logger.error(f"Error fetching secret: {e}")
            raise e
        return json.loads(response['SecretString'])

    def _gen_new_gitaccess(self):
        self._generate_jwt()
        self._get_installation_token()
        self._get_headers()

    def _generate_jwt(self):
        payload = {
            'iat': int(time.time()),
            'exp': int(time.time()) + 590,
            'iss': self.clientid
        }
        self.jwt_token = jwt.encode(payload, self.key, algorithm='RS256')

    def _get_installation_token(self):
        headers = {
            'Authorization': f'Bearer {self.jwt_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        url = f"{self.api_base}/app/installations/{self.installid}/access_tokens"
        response = requests.post(url, headers=headers)
        data = response.json()
        self.token = data['token']
        # Tokens typically expire in 1 hour, but we'll set it conservatively
        self.token_expires_at = int(time.time()) + 3300  # 55 minutes
        logger.info(f"GitHub token refreshed, expires at {self.token_expires_at}")

    def _ensure_valid_token(self):
        """Check if token is expired and refresh if needed"""
        if int(time.time()) >= self.token_expires_at - 60:  # Refresh 1 min before expiry
            logger.info("GitHub token expired or expiring soon, refreshing...")
            self._gen_new_gitaccess()

    def _get_headers(self):
        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        }

    def _get_repos_by_appci(self, appci):
        """
        Search GitHub org for all repos tagged with given AppCI.
        Returns list of full repo names e.g. ['United-Airlines-Org/repo-name']
        """
        self._ensure_valid_token()
        query_string = f"props.AppCI:{appci} org:United-Airlines-Org archived:false"
        url = f"{self.search_api_base}repositories?q={urllib.parse.quote(query_string)}&per_page=100"
        repos = []

        try:
            response = requests.get(url, headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                for repo in data.get('items', []):
                    repo_full_name = repo['full_name']
                    if repo_full_name not in repos:
                        repos.append(repo_full_name)
                logger.info(f"Found {len(repos)} repositories for AppCI: {appci}")
            else:
                logger.warning(f"Error fetching repos for AppCI {appci}: {response.status_code} - {response.text}")

        except Exception as e:
            logger.error(f"Exception fetching repos for AppCI {appci}: {e}")
            return []

        return repos

    def _get_code_scanning_alerts(self, repo_owner, repo_name):
        """
        Fetch all open code scanning alerts for a given repo.
        Handles pagination automatically.
        """
        self._ensure_valid_token()
        url = f"{self.api_base}/repos/{repo_owner}/{repo_name}/code-scanning/alerts"
        params = {
            'state': 'open',
            'per_page': 100
        }
        all_alerts = []

        try:
            while url:
                response = requests.get(url, headers=self.headers, params=params)

                if response.status_code == 200:
                    alerts = response.json()
                    all_alerts.extend(alerts)

                    # Handle pagination
                    if 'Link' in response.headers:
                        links = response.headers['Link'].split(',')
                        url = None
                        for link in links:
                            if 'rel="next"' in link:
                                url = link[link.find('<')+1:link.find('>')]
                                params = None
                                break
                    else:
                        url = None

                elif response.status_code == 404:
                    logger.warning(f"Code scanning not enabled or accessible for {repo_owner}/{repo_name}")
                    logger.debug(f"404 Response body: {response.text}")
                    break
                elif response.status_code == 401:
                    logger.error(f"Authentication failed for {repo_owner}/{repo_name} - token may be invalid")
                    logger.debug(f"401 Response body: {response.text}")
                    # Try to refresh token and retry once
                    self._gen_new_gitaccess()
                    logger.info("Refreshed token after 401, retrying...")
                    continue
                else:
                    logger.warning(f"Error fetching code scanning alerts for {repo_owner}/{repo_name}: {response.status_code} - {response.text}")
                    break

        except Exception as e:
            logger.error(f"Exception fetching code scanning alerts for {repo_owner}/{repo_name}: {e}")
            return []

        return all_alerts

    # -------------------------
    # Core public method
    # -------------------------

    def get_codeql_findings(self, appci):
        """
        Given an AppCI, fetch all open CodeQL alerts across all its repos.
        Returns a flat normalized list of alerts for codeql_validator to consume.
        """
        try:
            if appci is None:
                raise Exception('Parameter appci is mandatory')

            repos = self._get_repos_by_appci(appci)

            if not repos:
                logger.info(f"No repositories found for AppCI: {appci}")
                return []

            all_vulns = []

            for repo_full_name in repos:
                parts = repo_full_name.split('/')
                if len(parts) != 2:
                    logger.warning(f"Skipping invalid repo name: {repo_full_name}")
                    continue

                repo_owner = parts[0]
                repo_name = parts[1]

                try:
                    alerts = self._get_code_scanning_alerts(repo_owner, repo_name)

                    for alert in alerts:
                        # Use full_description for detailed text, fallback to description if not available
                        rule = alert.get("rule", {})
                        description = rule.get("full_description") or rule.get("description", "")
                        
                        normalized = {
                            "display_name": str(alert.get("number", "")),
                            "remediation_description": description,
                            "rule_id": alert.get("rule", {}).get("id", ""),
                            "cwes": self._extract_cwes(alert),
                            "severity": alert.get("rule", {}).get("security_severity_level", "").upper(),
                            "scan_type": "CODEQL",
                            "repository": repo_full_name,
                            "path": alert.get("most_recent_instance", {}).get("location", {}).get("path", ""),
                            "state": alert.get("state", ""),
                            "html_url": alert.get("html_url", "")
                        }
                        all_vulns.append(normalized)

                except Exception as e:
                    logger.warning(f"Error processing alerts for {repo_full_name}: {e}")
                    continue

            logger.info(f"Total CodeQL findings for AppCI {appci}: {len(all_vulns)}")
            return all_vulns

        except Exception as error:
            logger.error(error)
            raise Exception(f"Could not get CodeQL findings for appci: {appci}. Error={error}")

    # -------------------------
    # Helper methods
    # -------------------------

    def _extract_cwes(self, alert):
        """
        Extract CWE tags from CodeQL alert rule tags.
        GitHub CodeQL rules have tags like ['external/cwe/cwe-119', 'external/cwe/cwe-131'].
        Returns string like "['CWE-119', 'CWE-131']" to match findings format.
        Falls back to rule_id if no CWE tags found.
        """
        try:
            tags = alert.get("rule", {}).get("tags", [])
            cwe_tags = []
            for tag in tags:
                # Match pattern: external/cwe/cwe-XXX or cwe-XXX
                match = re.search(r'cwe-(\d+)', str(tag).lower())
                if match:
                    cwe_num = match.group(1)
                    cwe_tags.append(f"CWE-{cwe_num}")
            if cwe_tags:
                return str(cwe_tags)
            # Fallback to rule_id if no CWE tags
            rule_id = alert.get("rule", {}).get("id", "")
            return str([rule_id]) if rule_id else "[]"

        except Exception as e:
            logger.warning(f"Error extracting CWEs from alert: {e}")
            return "[]"
            
# For testing purpose
# if __name__ == "__main__":
#     APPCI = "EQA"  # Replace with your test AppCI
    
#     print("CodeQL Data - Test")
#     print("=" * 60)
#     print(f"AppCI: {APPCI}")
#     print("=" * 60)

#     codeql = CodeqlData()

#     # Test 1 - get repos
#     print(f"\nFetching repositories for AppCI: {APPCI}...")
#     repos = codeql._get_repos_by_appci(APPCI)
#     for repo in repos:
#         print(f"  - {repo}")

#     # Test 2 - get alerts for first repo only (to keep test quick)
#     print(f"\nFetching CodeQL alerts for first repo: {repos[0]}...")
#     parts = repos[0].split('/')
#     alerts = codeql._get_code_scanning_alerts(parts[0], parts[1])
#     print(f"Found {len(alerts)} alerts in {repos[0]}")
#     vulns = codeql.get_codeql_findings(APPCI)
#     print("vulnerabilities",vulns)


import requests
import json
import sys
import os
import re
from urllib.parse import quote

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from shared.secrets_manager import get_secret
from shared.ssm import get_ssm_parameter

class KongIntegration:
    '''Class to integrate with Kong'''
    def __init__(self):
        evidence_secrets = get_secret()
        self.api_base = "https://us.api.konghq.com/v2"
        self.size = 200
        self.api_key = evidence_secrets["KONG_KEY"]
        access = f'Bearer {self.api_key}'
        self.HEADERS = {'Authorization': access, 'Content-Type': 'application/json'}
        self._plane_id_pattern = re.compile(r"^[0-9a-fA-F-]{36}$")

    def _sanitize_plane_id(self, plane_id):
        # Validate and safely encode a control-plane id to mitigate resource injection.
        if not isinstance(plane_id, str):
            raise ValueError("Invalid plane id type")
        if not self._plane_id_pattern.fullmatch(plane_id):
            raise ValueError("Plane id failed validation")

        return quote(plane_id, safe='')
    
    def is_active(self, planeids):
        results = []
        for pid in planeids:
            try:
                safe_pid = self._sanitize_plane_id(pid)
                serviceurl = f"{self.api_base}/control-planes/{safe_pid}/core-entities/services"
                response = requests.get(serviceurl, headers=self.HEADERS, timeout=10)
                response.raise_for_status()
                data = response.json()
                for item in data.get('data', []):
                    results.append(item.get('enabled'))
            except ValueError as ve:
                return {"error": "Invalid control-plane id", "details": str(ve)}
            except requests.exceptions.HTTPError as http_err:
                return {"error": "HTTP error occurred", "details": str(http_err)}
            except requests.exceptions.RequestException as req_err:
                return {"error": "Request error occurred", "details": str(req_err)}
            except json.JSONDecodeError:
                return {"error": "Invalid JSON returned from Kong"}
            except Exception as e:
                return {"error": "Unexpected error during request", "details": str(e)}
        return results

    def get_kong_status(self, appci):
        url = f"{self.api_base}/control-planes"
        planeids = []
        result = []
        try:
            response = requests.get(url, headers=self.HEADERS, timeout=10)
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.HTTPError as http_err:
            return {"error": "HTTP error occurred", "details": str(http_err)}
        except requests.exceptions.RequestException as req_err:
            return {"error": "Request error occurred", "details": str(req_err)}
        except json.JSONDecodeError:
            return {"error": "Invalid JSON returned from Kong"}
        except Exception as e:
            return {"error": "Unexpected error during request", "details": str(e)}
        for item in data.get('data', []):
            if item.get('labels', {}).get('ApplicationCI') == appci.lower():
                planeids.append(item.get('id', ''))
        if planeids:
            result = self.is_active(planeids)
        return result
    
  

import requests
import urllib.parse
from shared.secrets_manager import get_secret
from github import Github
import re
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
import jwt
import time
import secrets
import threading
from integrations.asvs.input_validation.input_validation import validate_github_search_payload
from .logger import logger




class GithubIntegration:

    def __init__(self):
        self.api_base = "https://api.github.com/search/"
        self.token = None
        self.evidence_secrets = get_secret()
        self.key = self.evidence_secrets["Git-App-Key"].replace('\\n', '\n')
        self.clientid = self.evidence_secrets["Git-App-ClientID"]
        self.installid = self.evidence_secrets["Git-App-InstallID"]
        self.gen_new_gitaccess()
           

    def gen_new_gitaccess(self):
        self.generate_jwt()
        self.get_installation_token()
        self.get_headers()

    def generate_jwt(self):         

        payload = {
            'iat': int(time.time()),
            # JWT expiration time (10 minutes maximum)
            'exp': int(time.time()) + 590,
            'iss': self.clientid
        }

        encoded_jwt = jwt.encode(payload, self.key, algorithm='RS256')


        self.jwt_token = encoded_jwt
    
    def get_installation_token(self):
        headers = {
            'Authorization': f'Bearer {self.jwt_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        url = f"https://api.github.com/app/installations/{self.installid}/access_tokens"
        response = requests.post(url, headers=headers)
        data = response.json()
        self.token = data['token']
        
        

    def get_headers(self):
        self.headers = { 
            "Authorization" : "token {}".format(self.token),
            "Accept": "application/vnd.github+json"
        }

    def get_repos_by_appci(self, appci):
        # Only fetch active (non-archived) repos
        query_string = f"props.AppCI:{appci} org:United-Airlines-Org archived:false"
        url = f"{self.api_base}repositories?q={urllib.parse.quote(query_string)}&per_page=100"
        try:
            response = requests.request("GET", url, headers=self.headers)
            repos = []
            raw_repos = response.json()['items']
            for repo in raw_repos:
                if repo not in repos:
                    repos.append(repo['full_name'])

            if len(repos) > 0:
                return response.json()
            else:
                return repos
        except Exception as e:
            return {}
    
    def search_code_by_repo_api(self, query, repos):
        response = None
        retry_count = 0
        while response is None or 'API rate limit exceeded' in response.json().get("message", "No message found") :
            retry_count += 1
            if retry_count > 30:
                break
            self.gen_new_gitaccess()
            query_string = f"{query} {repos}"
            url = f"{self.api_base}code?q={urllib.parse.quote(query_string)}"
            try:
                response = requests.request("GET", url, headers=self.headers)
                data = response.json()
            except requests.exceptions.HTTPError as http_err:
                return {"error": "HTTP error occurred", "details": str(http_err)}
            except ValueError as value_err:
                return {"error": "Invalid JSON returned from Github", "details": str(value_err)}
            except Exception as e:
                return {"error": "Unexpected error during request", "details": str(e)}
            if 'API rate limit exceeded' in data.get("message", "No message found"):
                sleep_time = secrets.SystemRandom().uniform(0, 5)
                time.sleep(sleep_time)
            else:
                return data
        logger.warning(f"Failed to process API search request after maximum retries.")
        return {"error": "Exceeded retry attempts for API call."}

    
    def search_code_by_repo_txt(self, query, repoURL, language):     
        results_repos = []
        raw_evidence = []
        count = 0
        retry_count = 0
        repo = None 
        result = [] 

        URL = str(repoURL).replace("repo:", "").strip()
        token = self.token
        G = Github(token)
        
        try:
            re.compile(query)
        except re.error:
            raise ValueError(f"Invalid regex pattern: {query}")    
    
        while repo is None:
            retry_count += 1
            if retry_count > 30:
                logger.warning(f"Failed to process txt search request after maximum retries.")
                break
            try:
                self.gen_new_gitaccess()
                repo = G.get_repo(URL)
            except Exception as e:
                # Check for 403 Forbidden
                if hasattr(e, 'status') and e.status == 403:
                    logger.warning(f"403 Forbidden error for repo {URL}. Ending attempts.")
                    return count, raw_evidence, results_repos  # Immediately return
                elif "403" in str(e):
                    logger.warning(f"403 Forbidden error for repo {URL}. Ending attempts.")
                    return count, raw_evidence, results_repos  # Immediately return
                else:
                    sleep_time = secrets.SystemRandom().uniform(0, 5)
                    time.sleep(sleep_time)
        
        # Add here to support more languages
        language_extensions = {
            "python": [".py"],
            "c#": [".cs"],
            "hcl": [".hcl"],
            "java": [".java"],
            "typescript": [".ts"],
            "c++": [".cpp", ".hpp", ".cc", ".cxx", ".h"],
            "javascript": [".js"],
            "shell": [".sh"],
            "php": [".php"],
            "golang": [".go"]
        }

        extensions = []
        if isinstance(language, list):
            if any(lang.lower() == 'all' for lang in language):
                for exts in language_extensions.values():
                    extensions.extend(exts)
            else:
                for lang in language:
                    lang_key = lang.lower()
                    if lang_key in language_extensions:
                        extensions.extend(language_extensions[lang_key])
        elif isinstance(language, str):
            if language.lower() == 'all':
                for exts in language_extensions.values():
                    extensions.extend(exts)
            else:
                lang_key = language.lower()
                if lang_key in language_extensions:
                    extensions.extend(language_extensions[lang_key])
        if not extensions:
            for exts in language_extensions.values():
                extensions.extend(exts)

        try:
            tree = repo.get_git_tree("HEAD", recursive=True).tree
        except Exception as e:
            logger.warning(f"Fetching git tree: {e}")
            return count, raw_evidence, results_repos

        code_files = [item.path for item in tree if item.type == "blob" and any(item.path.lower().endswith(ext) for ext in extensions)]

        # Organize code_files: prioritize main/handler files and dependency files
        main_filenames = [
            # Python
            "main.py", "app.py", "wsgi.py", "asgi.py", "manage.py", "handler.py",
            # Java
            "Main.java", "Application.java",
            # C#
            "Program.cs", "Startup.cs",
            # TypeScript/JavaScript
            "main.ts", "main.js", "index.ts", "index.js", "app.ts", "app.js",
        ]
        dependency_filenames = [
            # Python
            "requirements.txt", "Pipfile", "pyproject.toml",
            # Java
            "pom.xml", "build.gradle", "build.gradle.kts",
            # C#
            "packages.config", "project.json", "*.csproj",
            # TypeScript/JavaScript
            "package.json", "yarn.lock", "pnpm-lock.yaml",
            # Golang
            "go.mod", "go.sum",
            # PHP
            "composer.json", "composer.lock",
            # HCL/Terraform
            "main.tf", "variables.tf", "outputs.tf", "terraform.tfvars",
        ]

        def is_main_file(path):
            return any(path.lower().endswith("/" + name.lower()) or path.lower() == name.lower() for name in main_filenames)

        def is_dependency_file(path):
            if path.lower().endswith(".csproj"):
                return True
            return any(path.lower().endswith("/" + name.lower()) or path.lower() == name.lower() for name in dependency_filenames)

        code_files_sorted = (
            [f for f in code_files if is_main_file(f)] +
            [f for f in code_files if is_dependency_file(f) and not is_main_file(f)] +
            [f for f in code_files if not is_main_file(f) and not is_dependency_file(f)]
        )


        for file_path in code_files_sorted[:10]:
            try:
                file_content = repo.get_contents(file_path)
                content = file_content.decoded_content.decode("utf-8")
                match = re.search(query, content, re.IGNORECASE)
                if match:
                    logger.debug(f"Match found in file: {file_path}")
                    count = 1
                    result = {
                        "file": file_path,
                        "match": match.group(0),
                        "repo": URL
                    }
                    break
            except UnicodeDecodeError:
                logger.warning(f"Skipping file {file_path} due to decoding error.")
            except Exception as e:
                logger.warning(f"Processing file {file_path}: {e}")

        if result != []:
            raw_evidence.append({
                "file": result["file"],
                "match": result["match"]
            })
            results_repos.append(result["repo"]) 

        return count, raw_evidence, results_repos
    
    def search_code_by_repo(self, query, repoURL):
        results = []
        results_repos = []
        raw_evidence = []
        count = 0
        items_data_points = [
            "name",
            "path",
            "html_url",
            "repository"
        ]
        repository_data_points = [
            "name",
            "description"
        ]

        results = self.search_code_by_repo_api(query, str(repoURL).replace("repo:", "").strip())
        validation = validate_github_search_payload(results)
        if not validation["ok"]:
            return {"error": "GitHub payload validation failed", "details": validation["errors"]}
        if len(results) > 0:
            if "total_count" in results:
                count += results["total_count"]
                # Add count to raw evidence
                raw_evidence.append({
                    "count": results["total_count"]
                })
            if "items" in results:
                if len(results["items"]) > 0:
                    for item in results["items"]:
                        item_metadata = {}
                        repo_metadata = {}
                        # pare down the size of the returned metadata, to the data points specified before
                        for item_data in items_data_points:
                            if item_data in item:
                                if item_data == "repository":
                                    for repo_data in repository_data_points:
                                        if repo_data in item[item_data]:
                                            if repo_data == "name":
                                                # get a unique list of repos where results are found, for evidence message
                                                if item[item_data][repo_data] not in results_repos:
                                                    results_repos.append(item[item_data][repo_data])
                                            repo_metadata[repo_data] = item[item_data][repo_data]
                                    item_metadata[item_data] = repo_metadata
                                else:
                                    item_metadata[item_data] = item[item_data]

                        raw_evidence.append(item_metadata)

        return count, raw_evidence, results_repos 
            
    
    def search_code(self, query, repos, language=None, return_repos=None):
        repo_list = []
        results_repos = []
        raw_evidence = []
        count = 0
        raw_evidence = []

        stop_event = threading.Event()

        try:
            if len(repos) > 0 and "items" in repos:
                for item in repos["items"]:
                    repo = item["full_name"]
                    repo_string = f"repo:{repo}"
                    repo_list.append(repo_string)

                def repo_list_worker(repoURL):
                    if stop_event.is_set():
                        return 0, [], []
                    c, raw, repos_found = self.search_code_by_repo(query, repoURL)
                    if c > 0:
                        stop_event.set()
                    return c, raw, repos_found

                with ThreadPoolExecutor(max_workers=3) as executor:
                    futures = {executor.submit(repo_list_worker, repoURL): repoURL for repoURL in repo_list}
                    for future in as_completed(futures):
                        c, raw, repos_found = future.result()
                        if c > 0:
                            count = c
                            raw_evidence = raw
                            results_repos = repos_found
                            break  # Stop processing further as soon as count > 0
                
                if count == 0: 
                    stop_event.clear()
                    # def txt_worker(repoURL):
                    #     if stop_event.is_set():
                    #         return 0, [], []
                    #     try:
                    #         txtcount, txtraw_evidence, txtresults_repos = self.search_code_by_repo_txt(query, repoURL,language)
                    #         if txtcount > 0:
                    #             stop_event.set()
                    #         return txtcount, txtraw_evidence, txtresults_repos
                    #     except Exception as e:
                    #         stop_event.set()
                    #         print(f"Error processing repository {repoURL}: {e}")
                    #         # Return a special value to indicate an exception
                    #         return -1, [], []

                    # with ThreadPoolExecutor(max_workers=5) as executor:
                    #     futures = {executor.submit(txt_worker, repoURL): repoURL for repoURL in repo_list}
                    #     for future in as_completed(futures):
                    #         txtcount, txtraw_evidence, txtresults_repos = future.result()
                    #         if txtcount == -1:
                    #             # Exception occurred, stop all workers
                    #             break
                    #         count += txtcount
                    #         raw_evidence.append(txtraw_evidence)
                    #         results_repos.append(txtresults_repos)
                    #         if count > 0:
                    #             break
                    
        except:
            logger.warning("Could not find results for the query {query}".format(query=query))

        # returns repos where results were found as evidence to the source validator
        if return_repos is not None:
            return count, raw_evidence, results_repos
        else:
            return count, raw_evidence
    
    def get_request(self, query, repo):
        request = {}
        updated_query = query + f" repo:{repo} org:United-Airlines-Org"
        url = f"{self.api_base}code?q={urllib.parse.quote(updated_query)}"
        headers = self.headers
        request['url'] = url
        request['headers'] = headers
        return request

    # Pull repo name & language field from repo object
    def get_repo_languages(self, repos):
        if "items" in repos:
            languages_per_repo = [{"name":res["name"], "language":res["language"]} for res in repos["items"]]
            return languages_per_repo
        else: 
            logger.info(f"'items' not found in variable repos. Found {repos.keys()}")
            return None

    # For every repo, search for a given language
    def filter_by_language(self, languages_by_repo, language):
        if languages_by_repo != None:
            repo_names = [
                repo["name"] for repo in languages_by_repo
                if isinstance(repo["language"], str) and repo["language"] == language
                or isinstance(repo["language"], list) and language in repo["language"]
            ]
            return repo_names
        else:
            logger.warning(f"Invalid languages_by_repo variable: {languages_by_repo}")

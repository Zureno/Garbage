import requests, json, time
import urllib3

from shared.secrets_manager import get_secret
from shared.ssm import get_ssm_parameter

class NetworkIntegration:
    '''Class to integrate with SKYNET for Network Automation'''

    def __init__(self):
        evidence_secrets = get_secret()
        urllib3.disable_warnings()
        self.api_base = "https://vndcdfgdervap01.global.ual.com:8443/oo/rest/v2/executions"
        self.api_key = evidence_secrets["SKYNET_KEY"]

    def get_policies(self, policy_json, controls):
        applicable = set()
        for policy in policy_json:
            for control in policy.get("controls"):
                if any(c.get("control", {}).get("S", "") == control for c in controls):
                    applicable.add(policy.get("configPolicyID"))
                    break
        return list(applicable)

    # First API Call: Kickoff the workflow
    def kickoff(self, policy):
        url = self.api_base
        headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Basic {self.api_key}',
        'Accept': 'application/json'
        }

        payload = {
        "flowUuid": "NonCompliantNodes.Policy_Check",
        "inputs": {
            "Policy_Id": f"{policy}",
            # Temporary - network team working to disable email generation. 
            # do not remove - removing doesn't turn off emails, it spams NSS's email inbox lol
            "Email_Id": "nathaniel.martinez1@united.com",
            "NA_Server": "na.ual.com"
        }}

        payload = json.dumps(payload)
        try:
            response = requests.post(url, headers=headers, data=payload, verify=False)
        except Exception as e:
            return str(e)
        executionID = response.json()
        if not executionID:
            return None
        else:
            return executionID

    def monitor_and_extract(self, executionId):
        url = f"{self.api_base}/{executionId}/execution-log"
        
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f"Basic {self.api_key}"
        }
        
        flow_status = "NA"
        flowOutput_str = "NA"
        while True:
            if flow_status == "complete":
                break
            else:
                response = requests.get(url, headers=headers, verify=False)
                resp_dict = json.loads(response.text)
                if resp_dict["executionSummary"]["endTime"] != None:
                    flow_status = "complete"
                    flowOutput_str = resp_dict["flowOutput"]
                time.sleep(5)
                
        return flowOutput_str
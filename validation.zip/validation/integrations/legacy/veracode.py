import requests
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC
from datetime import datetime, timezone
from shared.secrets_manager import get_secret
from ..asvs.logger import logger

API_BASE = "https://api.veracode.com/appsec/v1"
SBOM_BASE = "https://api.veracode.com/srcclr/sbom/v1"
FINDINGS_BASE = "https://api.veracode.com/appsec/v2/applications/"
HEADERS = {'Content-Type': 'application/json'}


class LegacyVeracodeIntegration:

    def __init__(self):
        evidence_secrets = get_secret()
        self.vid = evidence_secrets["VERACODE_VID"]
        self.vkey = evidence_secrets["VERACODE_VKEY"]


    def get_profiles_by_appci(self, appCi, vid, vkey):
        url = f"{API_BASE}/applications?custom_field_names=Application Key&custom_field_values={appCi}&size=200"
        try:
            response = requests.request("GET", url, auth=RequestsAuthPluginVeracodeHMAC(
                api_key_id=vid, api_key_secret=vkey), headers=HEADERS)
            
        except Exception as e:
            return (e)
        return response.json()

    def get_sbom(self, appUUID, vid, vkey):
        url = f"{SBOM_BASE}/targets/{appUUID}/cyclonedx?type=application"
        try:
            response = requests.request("GET", url, auth=RequestsAuthPluginVeracodeHMAC(
                api_key_id=vid, api_key_secret=vkey), headers=HEADERS)
        except Exception as e:
            return (e)
        return response.json()

    def get_cwe_findings(self, appUUID, vid, vkey):
        url = f"{FINDINGS_BASE}{appUUID}/findings"
        try:
            response = requests.request("GET", url, auth=RequestsAuthPluginVeracodeHMAC(
                api_key_id=vid, api_key_secret=vkey), headers=HEADERS)
        except Exception as e:
            return (e)
        return response.json()

    def get_findings_by_cwe(self, appci):
        findings = []
        raw_findings = {}
        valid_profiles = 0
        try:
            profiles = self.get_profiles_by_appci(appci, self.vid, self.vkey)
            for profile in profiles['_embedded']['applications']:
                retired = 'N'
                date_to_check = datetime.strptime(profile['scans'][0]['modified_date'], '%Y-%m-%dT%H:%M:%S.%f%z')
                time_between_scan = datetime.now(timezone.utc) - date_to_check
                for custom_field in profile['profile']['custom_fields']:
                    if custom_field['name'] == 'Retired':
                        retired = custom_field['value']
                # only check on non-retired profiles that have been scanned in the last year
                if retired == 'N' and time_between_scan.days < 365:
                    valid_profiles = valid_profiles + 1
                    guid = profile['guid']
                    raw_findings = self.get_cwe_findings(guid, self.vid, self.vkey)
                    for finding in raw_findings['_embedded']['findings']:
                        if finding['finding_status']['status'] == "OPEN":
                            if finding['finding_details']['cwe']['name'] not in [record["Vulnerability Name"] for record in findings]:
                                findings.append({
                                    "Vulnerability Name":finding['finding_details']['cwe']['name']
                                })
 
        except Exception as error:
            logger.warning(f"Getting findings: {error}")
            logger.warning("Could not find findings for appci: {appci}".format( appci=appci))

        return findings

    def get_libraries(self, appci):
        libraries = []
        try:
            profiles = self.get_profiles_by_appci(appci, self.vid, self.vkey)
            for profile in profiles['_embedded']['applications']:
                guid = profile['guid']
                sbom = self.get_sbom(guid, self.vid, self.vkey)
                if "components" in sbom:
                    for component in sbom["components"]:
                        libraries.append(component["bom-ref"])
        except:
            logger.error("Unable to get sbom for {appci}".format(appci=appci))
        return libraries

'''
if __name__ == '__main__':
    veracode = LegacyVeracodeIntegration()
    all_controls = veracode.get_findings_by_cwe("BFM")
    '''
import os
import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime
from shared.secrets_manager import get_secret
from ..asvs.logger import logger

API_BASE =  "https://www.netsparkercloud.com/api/1.0"
HEADERS = {'Content-Type': 'application/json'}

class NetsparkerIntegration:

    def __init__(self):
        evidence_secrets = get_secret()
        self.userid = evidence_secrets["NETSPARKER_USERID"]
        self.token = evidence_secrets["NETSPARKER_TOKEN"]

    def get_scan_profiles(self, page):
        url = "https://www.netsparkercloud.com/api/1.0/scanprofiles/list?page={page}&pageSize=200".format(page=page)
        try:
            result = requests.get(url=url, auth=HTTPBasicAuth(self.userid, self.token))
        except Exception as e:
            return 0
        
        return result.json()
    
    def get_results_titles(self, website):
        website_name = website["Name"]
        page = 1
        hasnext = True
        titles = []
        while (hasnext):
            url = "https://www.netsparkercloud.com/api/1.0/issues/allissues?webSiteName={website}&page={page}&pageSize=200".format(website=website_name, page=page)
            result = requests.get(url=url, auth=HTTPBasicAuth(self.userid, self.token))
            data = result.json()
            for d in data["List"]:
                states = d['State']
                if "Fixed" not in states and "Accepted" not in states:
                    titles.append(d["Title"])
            hasnext = data["HasNextPage"]
            page = page + 1

        return titles
    
    def get_valid_scans_by_website(self, website):
        url = "https://www.netsparkercloud.com/api/1.0/scans/listbywebsite?websiteUrl={website}&pageSize=200".format(website=website)
        result = requests.get(url=url, auth=HTTPBasicAuth(self.userid, self.token))
        data = result.json()
        scans = data['List']
        valid_scan = False

        if len(scans) > 0:
            latest_scan_date = scans[0]['InitiatedTime']
            latest_scan_date = latest_scan_date[:-9]
            local_datetime = datetime.strptime(latest_scan_date, "%d/%m/%Y")
            time_between_scans = datetime.now() - local_datetime
            if time_between_scans.days < 365:
                valid_scan = True

        return valid_scan

    
    def get_website_by_id(self, id):
        url = "https://www.netsparkercloud.com/api/1.0/websites/get/{id}".format(id=id)
        try:
            result = requests.get(url=url, auth=HTTPBasicAuth(self.userid, self.token))
        except Exception as e:
            return 0
        return result.json()
    
    def get_findings(self, appci):
        website_ids = self.get_website_ids_by_appci(appci.upper())
        findings = []
        websites = []
        valid_websites = 0
        try:
            for id in website_ids:
                website = self.get_website_by_id(id)
                if website not in websites:
                    websites.append(website)

            for website in websites:
                valid = self.get_valid_scans_by_website(website['RootUrl'])
                if valid:
                    valid_websites += 1
                    results = self.get_results_titles(website)
                    for result in results:
                        if result not in [record["Vulnerability Name"] for record in findings]:
                                findings.append({
                                    "Vulnerability Name":result
                                })
        except:
            logger.error("Can't get netsparker scan results for {appci}".format(appci=appci))

        return findings

    def get_website_ids_by_appci(self, appci):
        page = 1
        hasnext = True
        website_ids = []
        while (hasnext):
            profiles = self.get_scan_profiles(page)
            for profile in profiles["List"]:
                app_ci_split = profile["ProfileName"].split(".")[0]
                if appci == app_ci_split:
                    website_ids.append(profile['WebsiteId'])
            page = page + 1
            hasnext = profiles["HasNextPage"]

        return website_ids

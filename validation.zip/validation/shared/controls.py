import boto3
import json
import os
from .logger import logger

class Control:
    def __init__(self):  
        self.dynamodb = boto3.client('dynamodb')

    def get_all_validation_types(self,controls):
        types = []
        for control in controls:
            validators = json.loads(control['validators']["S"])
            for details in validators:
                if details["type"] not in types:
                    types.append(details["type"])
        return types

    def get_all_tool_types(self,controls):
        tools = []
        for control in controls:
            validators = json.loads(control['validators']["S"])
            for details in validators:
                if "tool" in details:
                    if details["tool"] not in tools:
                        tools.append(details["tool"])
        return tools

    def get_control_confidence(self,num_validation_types):
        confidence_mapping = {1:"low", 2:"medium"}
        confidence = confidence_mapping.get(num_validation_types, 
                                            "high" if num_validation_types >= 3
                                            else "NA")
        
        return confidence

    def get_num_validators_tools(self,control):
        num_validations = len(self.get_all_validation_types([control]))
        num_tools = len(self.get_all_tool_types([control]))
        return num_validations+num_tools

    def get_definition_pass(self,definition, passed, validations, skipped = 0):
        
        # default to None in the event all validators are skipped, we can set the
        # control to NA in the processing function
        success = None

        # pass if all minus any skipped passed
        total_validations = len(validations) - skipped
        if definition == "all":
            if passed >= total_validations:
                success = True
            else:
                success = False

        # pass if any pass
        if definition == "any":
            if passed >= 1:
                success = True
            else:
                success = False

        return success

    def get_enabled_controls(self,controls_needed):
        response = self.dynamodb.scan(
            TableName='eqa-control-table',
            FilterExpression='enabled = :enabled',
            ExpressionAttributeValues= {
                ":enabled": {
                    "BOOL": True
                }
            },
        )
        items = response['Items']
        while 'LastEvaluatedKey' in response:
            response = self.dynamodb.scan(
                TableName='eqa-control-table',
                FilterExpression='enabled = :enabled',
                ExpressionAttributeValues= {
                    ":enabled": {
                        "BOOL": True
                    }
                },
                ExclusiveStartKey=response['LastEvaluatedKey']
            )

            items.extend(response['Items'])

        enabled_controls = []

        for control in items:
            if control["control"]["S"] in controls_needed:
                enabled_controls.append(control)

        return enabled_controls

    def determine_skipped(self, scannable):
        # default skipped to false
        # then check if sast/dast scannable
        skip = False

        if scannable is False:
            skip = True

        return skip

    def get_all_controls(self):
        standards = ["API", "ASTS", "BOTS", "CMS", "DS", "EKM", "IAM", "NSS", "SAM", "SCCH", "SLM", "SSDF", "TVM"]
        control_list = []
    
        for standard in standards:
            controls_path = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../../control/cdr/{standard}.json"))
            try:
                with open(controls_path, 'r', encoding='utf-8') as json_data:
                    content = json.load(json_data)

                    control_list.extend(content)
            except FileNotFoundError:
                logger.warning(f"Control file for standard '{standard}' not found at {controls_path}. Skipping.")
            except json.JSONDecodeError:
                logger.warning(f"Failed to parse JSON for standard '{standard}' in file {controls_path}. Skipping.")
            except Exception as e:
                logger.warning(f"Unexpected error loading {standard} controls: {e}")

        return control_list
    
    def get_shared_validators(self, controls):
        # Returns a dict mapping each validator-spec (as a JSON string) to the list of control names
        # that include it, but only for those validators that appear in more than one control.
        validator_map = {}
        for ctrl in controls:
            name = ctrl['control']
            for v in ctrl.get('validators', []):
                key = json.dumps(v, sort_keys=True)
                validator_map.setdefault(key, set()).add(name)
 
        # only keep those seen in multiple controls
        return {
            key: sorted(names)
            for key, names in validator_map.items()
            if len(names) > 1
        }
    
    def get_validators_duplicates(self, controls):
        duplicated = []
        for control_a in controls:
            duped_validators = []
            name = control_a['control']['S']
            validators = control_a['validators']
            for control_b in controls:
                other_name = control_b['control']['S']
                if name != other_name:
                    if validators == control_b['validators']:
                        if other_name not in duped_validators:
                            duped_validators.append(other_name)

            if duped_validators:
                # Add the current control name as well (if not already present)
                if name not in duped_validators:
                    duped_validators.append(name)

                this_set = set(duped_validators)
                if not any(this_set == set(group) for group in duplicated):
                    duplicated.append(duped_validators)

        return duplicated

# To test a specific set of controls, uncomment this and import it into the process.py
# Create a variable in process.py, controls_list, and make it a list of controls to test
# e.g. controls_list = ["OWASP-V14.2.5", "OWASP-V5.2.1", "OWASP-V5.2.5"]
# Then replace controls = get_enabled_controls(controls_needed) with controls = get_test_controls(controls_list)
# def get_test_controls(controls_list):
#     test_controls = []
#     dynamodb = boto3.client('dynamodb')

#     for control in controls_list:
#         response = dynamodb.scan(
#             TableName='eqa-control-table',
#             FilterExpression='control = :control',
#             ExpressionAttributeValues= {
#                 ":control": {
#                     "S": control # Set to individual control
#                 }
#             },
#         )
        
#         items = response['Items'][0]
#         test_controls.append(items)
 

#     return test_controls

'''
if __name__ == '__main__':
    control = Control()
    all_controls = control.get_all_controls()
    
    duplicates = control.get_validators_duplicates(all_controls)
    with open (f'duplicates_results_output.json', 'w') as file:
        json.dump(duplicates, file, indent=4)  # Format JSON output
    
    duplicates = control.get_shared_validators(all_controls)
    for validator_def, ctrls in duplicates.items():
        print("Validator:", validator_def)
        print("  shared by:", ctrls)
    '''

    
 

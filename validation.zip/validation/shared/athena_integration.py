import logging
import os
import re
import time
from shared.ssm import get_ssm_parameter
from typing import List, Optional
from shared.config import CONFIG
import json

import boto3
from sqlalchemy import Table, Column, MetaData, String, select, and_, func
from .logger import logger

env = get_ssm_parameter('/eqa/udcrm-control-automation/config/env')

if CONFIG["ENV"] == "dev":
    REGION = os.environ['AWS_REGION']
else:
    REGION = "us-east-1"

if REGION == "us-east-1":
    S3_BUCKET = f's3://eqa-udcrm-datalake-bucket-{env}'
else:
    S3_BUCKET = s3_output = f's3://eqa-udcrm-datalake-bucket-{env}-{REGION}'


class AthenaIntegration:
    def __init__(self):
        self.athena_client = boto3.client('athena')

    def sanitize_identifier(self, identifier):
        # Let's remove any characters that aren't alphanumeric or underscores
        sanitized = re.sub(r'[^\w]', '', identifier)
        if sanitized and sanitized[0].isdigit():
            # Let's ensure the identifier doesn't start with a number
            sanitized = "_" + sanitized
        return sanitized

    def execute_athena_query(self, database, query, blocking=True, workgroup=None):
        query_params = {
            'QueryString': query,
            'QueryExecutionContext': {'Database': database},
            'ResultConfiguration': {'OutputLocation': S3_BUCKET}
        }
        
        # Add workgroup if specified (required for Lake Formation resource links)
        if workgroup:
            query_params['WorkGroup'] = workgroup
        
        response = self.athena_client.start_query_execution(**query_params)
        query_execution_id = response['QueryExecutionId']

        if blocking is False:
            return query_execution_id
        else:
            time.sleep(60)

            while True:
                response = self.athena_client.get_query_execution(QueryExecutionId=query_execution_id)
                state = response['QueryExecution']['Status']['State']
                if state in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
                    break
                time.sleep(30)

            if state != 'SUCCEEDED':
                if CONFIG["ENV"] == "local":
                    logger.debug(f"Athena query failed: {response}")
                return False

            return self.get_query_results(query_execution_id)

    def get_query_results(self, query_execution_id):
        json_results = []
        next_token = None # pagination
        athena_client = self.athena_client

        while True:
            # Get query results by fetching paginated data
            if next_token:
                response = athena_client.get_query_results(QueryExecutionId = query_execution_id, NextToken = next_token)
            else:
                response = athena_client.get_query_results(QueryExecutionId = query_execution_id)

            columns = [col['Name'] for col in response['ResultSet']['ResultSetMetadata']['ColumnInfo']]
            rows = response['ResultSet']['Rows'][1:] if not json_results else response['ResultSet']['Rows']
            for row in rows:
                #logger.debug(f"Printing row: {row}")
                items = []
                for data in row['Data']:
                    if 'VarCharValue' in data:
                        items.append(data['VarCharValue'])
                json_results.append(dict(zip(columns, items)))
            
            #Check if more pages exist
            next_token = response.get("NextToken")
            if not next_token:
                break
            
            # with open("json_results.json", "w", encoding="utf-8") as file:
            #     json.dump(json_results, file, indent=2, ensure_ascii=False)

        return json_results
    
    def wait_for_query_to_finish(self, query_execution_id, max_wait=300, poll_interval=5):
        athena_client = self.athena_client
        elapsed = 0
        while elapsed < max_wait:
            response = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
            state = response['QueryExecution']['Status']['State']
            if state == 'SUCCEEDED':
                return True
            elif state in ('FAILED', 'CANCELLED'):
                reason = response['QueryExecution']['Status'].get('StateChangeReason', 'Unknown')
                raise Exception(f"Athena query {query_execution_id} failed: {reason}")
            time.sleep(poll_interval)
            elapsed += poll_interval
        raise TimeoutError(f"Athena query {query_execution_id} did not complete in {max_wait} seconds")

    @classmethod
    def construct_secure_query(cls,
                               table_name: str,
                               columns: List[str],
                               where_clauses: Optional[List[dict]] = None,
                               order_by_clauses: Optional[List[dict]] = None,
                               limit: Optional[int] = None,
                               distinct : Optional[bool] = False) -> str:
        metadata = MetaData()
        table = Table(table_name,
                      metadata,
                      *(Column(col, String) for col in columns))

        query = select(*[table.c[col] for col in columns])
        
        if distinct:
            query = query.distinct()

        # Support for custom/raw SQL in where_clauses
        custom_conditions = []
        conditions = []
        if where_clauses:
            for clause in where_clauses:
                if 'custom' in clause:
                    custom_conditions.append(clause['custom'])
                else:
                    column = clause['column']
                    operator = clause['operator']
                    value = clause['value']
                    if operator == '=':
                        conditions.append(table.c[column] == value)
                    elif operator == '>':
                        conditions.append(table.c[column] > value)
                    elif operator == '<':
                        conditions.append(table.c[column] < value)
                    elif operator.lower() == 'in':
                        conditions.append(table.c[column].in_(value))
                    elif operator.lower() == 'like':
                        conditions.append(table.c[column].like(value))
                    elif operator == '>=':
                        conditions.append(table.c[column] >= value)
                    elif operator.lower() == 'regexp':
                        conditions.append(func.REGEXP_LIKE(table.c[column], value))
        # Build the SQL string
        sql_string = str(query.compile(compile_kwargs={"literal_binds": True}))
        # Inject custom conditions if present
        if conditions or custom_conditions:
            where_parts = []
            if conditions:
                # Extract the WHERE clause from the compiled SQL
                compiled_where = str(and_(*conditions).compile(compile_kwargs={"literal_binds": True}))
                # Remove the leading 'AND ' if present
                if compiled_where.startswith('AND '):
                    compiled_where = compiled_where[4:]
                where_parts.append(compiled_where)
            if custom_conditions:
                where_parts.append(' AND '.join(custom_conditions))
            # Combine all conditions
            full_where = ' AND '.join([wp for wp in where_parts if wp])
            # Insert WHERE clause into SQL string
            if 'WHERE' in sql_string:
                # Already has a WHERE, append with AND
                # Find the WHERE clause and append
                parts = sql_string.split('WHERE', 1)
                sql_string = f"{parts[0]}WHERE {full_where} AND ({parts[1].strip()})"
            else:
                # Add WHERE clause
                sql_string += f" WHERE {full_where}"

        if order_by_clauses:
            for clause in order_by_clauses:
                column = clause['column']
                ascending = clause.get('ascending', True)
                if ascending:
                    sql_string += f" ORDER BY {column} ASC"
                else:
                    sql_string += f" ORDER BY {column} DESC"

        if limit is not None:
            sql_string += f" LIMIT {limit}"

        logger.info(f"Constructed SQL Query: {sql_string}")

        return sql_string

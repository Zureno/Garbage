import copy
import json
from time import sleep
import boto3

import sys, os
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..', 'src')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..','validation')))
# from SourceDataLayer.snow import NewSnowIntegration

from shared.controls import Control as Controlclass
from shared.check_size_limits import check_snow_limit, check_dynamo_limit
from shared.validator_generator import ValidatorGenerator
from shared.entity_handling import process_identifier, get_validator_entity_classes, determine_skipped_entity
from integrations.asvs.github import GithubIntegration
from data.findings_data import FindingsData
from shared.config import CONFIG
from concurrent.futures import ThreadPoolExecutor, as_completed
from .logger import logger

class ControlProcessor:
    # Registry of per-validator message builders for easy customization
    # If evidence is not to be customized, the builder returns and defults to defult pass message
    VALIDATOR_MESSAGE_BUILDERS = {
        "findings": None,  # set after function definition below
        "source": None, # set after function definition below
        "sbom": lambda v: (
            (
                f"Sbom-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Sbom-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "pipeline": lambda v: (
            (
                f"Pipeline-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Pipeline-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "salt": lambda v: (
            (
                f"Salt-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Salt-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "saltonboard": lambda v: (
            (
                f"Saltonboard-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Saltonboard-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "wiz": lambda v: (
            (
                f"Wiz-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Wiz-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "splunk": lambda v: (
            (
                f"Splunk-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Splunk-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "gitleaks": lambda v: (
            (
                f"Gitleaks-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}"
                if any(str(c).strip() for c in v.get('criteria', []))
                else "Gitleaks-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "ghas": lambda v: (
            (
                f"GHAS-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}"
                if any(str(c).strip() for c in v.get('criteria', []))
                else "GHAS-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "kong": lambda v: (
            (
                f"Kong-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Kong-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "ot": lambda v: (
            (
                f"OT-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "OT-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "network": lambda v: (
            (
                f"Network-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Network-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "splunkot": lambda v: (
            (
                f"SplunkOT-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "SplunkOT-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        ),
        "codeql": None,  # set after function definition below
        "akamai": None, # set after function definition below
        "onboarded": lambda v: (
            (
                f"Onboarded-fail: {', '.join([c for c in v.get('criteria', []) if str(c).strip()])}" 
                if any(str(c).strip() for c in v.get('criteria', [])) 
                else "Onboarded-fail: This control has not been implemented yet"
            ) if v.get('status') in ('FAIL', 'NA') else ""
        )
    }

    @staticmethod
    def findings_message_builder(v):
        status_v = v.get("status")
        # Treat NA as a failure-equivalent. If NA, emit default not-implemented message.
        if status_v not in ("FAIL", "NA"):
            return ""
        if status_v == "NA":
            return "Findings-fail: This control has not been implemented yet"
        internal = v.get("_evidence_internal")
        if not isinstance(internal, dict):
            return ""
        cwe_details = internal.get("cwe_details", [])
        cwe_ids = sorted({str(d.get("id", "")).strip() for d in cwe_details if str(d.get("id", "")).strip()}, key=lambda x: int(x) if x.isdigit() else x)
        finding_names = sorted({str(d.get("description", "")).strip() for d in cwe_details if str(d.get("description", "")).strip()})
        cwe_ids_str = ", ".join(cwe_ids)
        finding_names_str = ", ".join(finding_names)
        if not cwe_ids_str and not finding_names_str:
            return ""
        return (
            "This requirement has failed due to findings detected in the following CWE(s) and Finding Name(s) combinations: "
            f"{cwe_ids_str} - {finding_names_str}."
            " To pass this requirement, please remediate the findings in the Finding IDs column."
        )

    # Initialize findings builder
    VALIDATOR_MESSAGE_BUILDERS["findings"] = findings_message_builder.__func__

    @staticmethod
    def source_message_builder(v):
        status_v = v.get("status")
        name_v = v.get("name")
        identifier = v.get("identifier")

        if name_v == "CDR-SSDF2.3.4":
            if status_v == "PASS":
                return f"Passed. There were one or more repositories found under AppCI {identifier} in the United Airlines GitHub organization."
            elif status_v == "NA":
                return "Source-fail: This control has not been implemented yet"
            else:
                return (f"Failed. There were no repositories found under AppCI {identifier} in the United Airlines GitHub organization.")

        # Generic source validator messages
        if status_v == "PASS":
            return ""
        if status_v == "NA":
            return "This control has not been implemented yet"
        if status_v == "FAIL":
            return "This control has failed."
        return ""
        

    # Initialize findings builder
    VALIDATOR_MESSAGE_BUILDERS["source"] = source_message_builder.__func__

    @staticmethod
    def akamai_message_builder(v):
        status_v = v.get("status")
        criteria = v.get("criteria")
        identifier = v.get("identifier")
        logger.info(f"akamai_message_builder - criteria: {criteria}")

        if criteria == ["waf"]:
            if status_v == "PASS":
                logger.info("akamai waf pass case")
                return f"This requirement has passed because AppCI {identifier} has been onboarded to Akamai."
            elif status_v == "NA":
                return "Akamai-fail: This control has not been implemented yet"
            else:
                logger.info("akamai waf fail case")
                return f"This requirement has failed because AppCI {identifier} has not been onboarded to Akamai. To pass this requirement, please complete the HelpHub Akamai Support Request form for onboarding support: https://united.service-now.com/hrportal?id=sc_cat_item_guide&table=sc_cat_item&sys_id=2e3d3cf487893ad4a912eacd8bbb3528&searchTerm=akamai"
        elif criteria == ["bot_manager"]:
            if status_v == "PASS":
                logger.info("akamai bot_manager pass case")
                return f"This requirement has passed because AppCI {identifier} is covered by Akamai Bot Manager."
            elif status_v == "NA":
                return "Akamai-fail: This control has not been implemented yet"
            else:
                logger.info("akamai bot_manager fail case")
                return  f"This requirement has failed because AppCI {identifier} is not covered by Akamai Bot Manager."
        else:
            "Invalid criteria"
        

    # Initialize akamai builder
    VALIDATOR_MESSAGE_BUILDERS["akamai"] = akamai_message_builder.__func__

    @staticmethod
    def codeql_message_builder(v):
        status_v = v.get("status")
        # Treat NA as a failure-equivalent. If NA, emit default not-implemented message.
        if status_v not in ("FAIL", "NA"):
            return ""
        if status_v == "NA":
            return "CodeQL-fail: This control has not been implemented yet"
        internal = v.get("_evidence_internal")
        if not isinstance(internal, dict):
            return ""
        cwe_details = internal.get("cwe_details", [])
        cwe_ids = sorted({str(d.get("id", "")).strip() for d in cwe_details if str(d.get("id", "")).strip()}, key=lambda x: int(x) if x.isdigit() else x)
        finding_names = sorted({str(d.get("description", "")).strip() for d in cwe_details if str(d.get("description", "")).strip()})
        cwe_ids_str = ", ".join(cwe_ids)
        finding_names_str = ", ".join(finding_names)
        if not cwe_ids_str and not finding_names_str:
            return ""
        return (
            "This requirement has failed due to CodeQL findings detected in the following CWE(s) and Finding Name(s) combinations: "
            f"{cwe_ids_str} - {finding_names_str}."
            " To pass this requirement, please remediate the findings in the Finding IDs column."
        )

    # Initialize codeql builder
    VALIDATOR_MESSAGE_BUILDERS["codeql"] = codeql_message_builder.__func__

    @staticmethod
    def compose_validator_message(v):
        vtype = v.get("type")
        status_v = v.get("status")
        if status_v not in ("PASS", "FAIL", "NA"):
            return ""
        builder = ControlProcessor.VALIDATOR_MESSAGE_BUILDERS.get(vtype)
        if builder is None:
            return f"{vtype}-{status_v.lower()}"
        try:
            return builder(v) or ""
        except Exception:
            return f"{vtype}-{status_v.lower()}"
        
    def process_single_validation(
        self, details, controlclass, identifier, entity_classes, validation_generator,
        sast_compliant, dast_compliant, sast_metadata, dast_metadata, vulns, libraries, sbom,
        posture_gaps,  saltonboard_results, wiz_vulns, splunk_status, kong_results, sast_invaracode, dast_isonboarded, sast_scannable,
        dast_scannable, definition, name, repos, ot_vulns, splunkot_data, network_compliance, akamai_data, codeql_vulns, gitleaks_findings, ghas_findings):
        skipped = False
        success = None
        validation_type = details["type"]
        avit = []
        validator_entity_classes = []

        validator_entity_classes = get_validator_entity_classes(details)
        if validator_entity_classes != []:
            skipped = determine_skipped_entity(validator_entity_classes, entity_classes)

        if validation_type == "findings":
            tool = details["tool"]
            if tool == "sast":
                compliance = sast_compliant
                compliance_metadata = sast_metadata
                skipped = controlclass.determine_skipped(sast_scannable)
            elif tool == "dast":
                compliance = dast_compliant
                compliance_metadata = dast_metadata
                skipped = controlclass.determine_skipped(dast_scannable)
            findings_validator = validation_generator.get_validator("findings")

        if validation_type == "sbom":
            skipped = controlclass.determine_skipped(sast_scannable)
            sbom_validator = validation_generator.get_validator("sbom")

        if validation_type == "onboarded":
            # Check both SAST and DAST scannability based on criteria
            criteria = details.get("criteria", [])
            if "sast" in criteria and "dast" in criteria:
                # Both apply: skip only if both are not scannable
                skipped = controlclass.determine_skipped(sast_scannable) and controlclass.determine_skipped(dast_scannable)
            elif "sast" in criteria:
                # SAST only: skip if SAST not scannable
                skipped = controlclass.determine_skipped(sast_scannable)
            elif "dast" in criteria:
                # DAST only: skip if DAST not scannable
                skipped = controlclass.determine_skipped(dast_scannable)
            onboarded_validator = validation_generator.get_validator("onboarded")

        if skipped is False:
            # print(validation_type)
            # Validation step
            match validation_type:
                case "findings":
                    success, avit, exception, evidence = findings_validator.validate(details, vulns)
                    if exception is True:
                        return {"skipped": True, "avit": avit, "success": None, "details": details, "evidence": evidence}
                #SSDF2.3.4 validation happens here. Once re-implementing the source validator, remove the if statement.
                case "codeql":
                    codeql_validator = validation_generator.get_validator("codeql")
                    success, avit, exception, evidence = codeql_validator.validate(details, codeql_vulns)
                    if exception is True:
                        return {"skipped": True, "avit": avit, "success": None, "details": details, "evidence": evidence}
                case "source":
                    if name == "CDR-SSDF2.3.4":
                        source_validator = validation_generator.get_validator("source")
                        success = source_validator.validate(details, definition, repos)
                case "sbom":
                    success = sbom_validator.validate(
                    identifier, details, libraries, sbom, sast_compliant, sast_metadata)
                case "pipeline":
                    pipeline_validator = validation_generator.get_validator("pipeline")
                    success = pipeline_validator.validate(details, identifier, repos)
                case "salt":
                    salt_validator = validation_generator.get_validator("salt")
                    success = salt_validator.validate(details, posture_gaps)
                case "saltonboard":
                    salt_validator = validation_generator.get_validator("saltonboard")
                    success = salt_validator.validate(details, saltonboard_results)
                case "wiz":
                    wiz_validator = validation_generator.get_validator("wiz")
                    success = wiz_validator.validate(details, wiz_vulns)
                case "splunk":
                    splunk_validator = validation_generator.get_validator("splunk")
                    success = splunk_validator.validate(details, splunk_status)
                case "kong":
                    kong_validator = validation_generator.get_validator("kong")
                    success = kong_validator.validate(kong_results)
                case "ot":
                    ot_validator = validation_generator.get_validator("ot")
                    success = ot_validator.validate(details, ot_vulns)          
                case "network":
                    network_validator = validation_generator.get_validator("network")
                    success = network_validator.validate(details, network_compliance, identifier)
                case "splunkot":
                    splunkot_validator = validation_generator.get_validator("splunkot")
                    success = splunkot_validator.validate(details, splunkot_data)   
                case "akamai":
                    akamai_validator = validation_generator.get_validator("akamai")
                    success = akamai_validator.validate(details, akamai_data)
                case "gitleaks":
                    gitleaks_validator = validation_generator.get_validator("gitleaks")
                    success = gitleaks_validator.validate(details, gitleaks_findings)
                case "ghas":
                    ghas_validator = validation_generator.get_validator("ghas")
                    success = ghas_validator.validate(details, ghas_findings)
                case "onboarded":
                    success = onboarded_validator.validate(details, sast_compliant, dast_compliant)
                case _:
                    logger.warning(f"Invalid validation type in {name}: {validation_type}")
    
        else:
            return {"skipped": True, "avit": avit, "success": None, "details": details, "evidence": {}}

        # Include evidence when produced by the validator (e.g., findings)
        # For findings, keep evidence internal for control-level roll-up
        extra = {}
        if validation_type == "findings":
            extra["_evidence_internal"] = evidence
        if validation_type == "codeql":
            extra["_evidence_internal"] = evidence
        return {"skipped": False, "avit": avit, "success": success, "details": details, **extra}
    
    def process_control(self, control, identifier, qa_control, entity_classes, validation_generator, sast_compliant, dast_compliant, sast_metadata, dast_metadata, vulns, libraries, sbom, posture_gaps, saltonboard_results,  wiz_vulns, splunk_status, kong_results, sast_invaracode, dast_isonboarded, sast_scannable, dast_scannable, repos, ot_vulns, splunkot_data, network_compliance, akamai_data, codeql_vulns, gitleaks_findings, ghas_findings):
        import concurrent.futures

        total_pass = 0
        total_skipped = 0
        list_avits = []
        status = {}
        controlclass = Controlclass()

        if qa_control is not None:
            control = qa_control

        definition = control['definition']['S']
        name = control['control']['S']

        validators = json.loads(control['validators']["S"])
        num_validations = len(validators)
        updated_validations = []
        num_validation_types = controlclass.get_num_validators_tools(control)

        # Multithread the validations
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future_to_details = {
                executor.submit(
                    self.process_single_validation,
                    details, controlclass, identifier, entity_classes, validation_generator,
                    sast_compliant, dast_compliant, sast_metadata, dast_metadata, vulns, libraries, sbom,
                    posture_gaps, saltonboard_results, wiz_vulns, splunk_status, kong_results, sast_invaracode, dast_isonboarded, sast_scannable,
                    dast_scannable, definition, name, repos, ot_vulns, splunkot_data, network_compliance, akamai_data, codeql_vulns, gitleaks_findings, ghas_findings
                ): details for details in validators
            }
            done_futures = set()
            for future in concurrent.futures.as_completed(future_to_details):
                result = future.result()
                done_futures.add(future)
                details = result["details"]
                avit = result["avit"]
                skipped = result["skipped"]
                success = result["success"]
                evidence = result.get("_evidence_internal")

                if avit:
                    list_avits.append(avit)

                updated_validation = copy.deepcopy(details)
                updated_validation["identifier"] = identifier
                updated_validation["name"] = name
                if success is True:
                    updated_validation["status"] = "PASS"
                    total_pass += 1
                elif success is False:
                    updated_validation["status"] = "FAIL"
                else:
                    updated_validation["status"] = "NA"

                # Keep internal evidence for control-level aggregation
                if evidence is not None and details.get("type") in ("findings", "codeql"):
                    updated_validation["_evidence_internal"] = evidence

                updated_validations.append(updated_validation)

                if skipped:
                    total_skipped += 1

                # If any pass and definition is "any", cancel remaining
                if (definition == "any") and (total_pass >= 1):
                    # Cancel all not-yet-done futures
                    for f in future_to_details:
                        if f not in done_futures:
                            f.cancel()
                    break

        all_pass = all(v.get("status") == "PASS" for v in updated_validations)
        any_fail_or_na = any(v.get("status") in ("FAIL", "NA") for v in updated_validations)
        success = bool(all_pass and not any_fail_or_na)

        evidence = ""
        # Collect Finding IDs (formerly VIPR Silk IDs) for status
        vipr_silk_ids = set()
        for v in updated_validations:
            internal = v.get("_evidence_internal")
            if isinstance(internal, dict):
                for sid in internal.get("FindingIDs", []):
                    sid_str = str(sid).strip()
                    if sid_str:
                        vipr_silk_ids.add(sid_str)

        # Build additive messages for validators in execution order (including findings)
        validator_order = [
            "findings", "source", "sbom", "pipeline", "salt", "saltonboard",
            "wiz", "splunk", "kong", "ot", "network", "splunkot", "akamai", "onboarded", "codeql", "gitleaks", "ghas"
        ]
        any_fail = any_fail_or_na
        additive_msgs = []
        if any_fail:
            for vtype in validator_order:
                for v in updated_validations:
                    if v.get("type") == vtype:
                        msg = ControlProcessor.compose_validator_message(v)
                        if msg:
                            additive_msgs.append(str(msg).strip())
        # Deduplicate while preserving order to avoid repeated messages
        unique_additive_msgs = list(dict.fromkeys(additive_msgs))
        if num_validations == total_skipped:
            raw_evidence = (f"{name} validation has been skipped because all control validations were skipped.  ")
        else:
            # Build criteria lists based on pass/fail per validator
            failed_criteria = list({c for v in updated_validations if v.get("status") in ("FAIL", "NA") for c in v.get("criteria", [])})
            passed_criteria = list({c for v in updated_validations if v.get("status") == "PASS" for c in v.get("criteria", [])})
            if success:
                raw_evidence = (
                    f"Validation of requirement {name} for AppCI {identifier} has passed because the following criteria passed: {passed_criteria}"
                )
            else:
                raw_evidence = (
                    f"Validation of requirement {name} for AppCI {identifier} has failed because the following criteria failed: {failed_criteria}"
                )
        if unique_additive_msgs:
            evidence = ' '.join(unique_additive_msgs)
        else:
            evidence = "This requirement has passed; no action is required."

        if name == "CDR-SSDF2.4.9":
            raw_evidence = (
                f"Results are pending, check back tomorrow."
            )
            evidence = "Results are pending, check back tomorrow."

        logger.info(f"Generated evidence: {evidence}")
        # Truncate evidence if it exceeds SNOW limit; keep first 3997 chars and append ellipsis
        if isinstance(evidence, str) and len(evidence) > 4000:
            evidence = evidence[:4000 - 3] + "..."

        # Build and truncate FindingIDs 
        finding_ids_sorted = sorted(list(vipr_silk_ids))
        finding_ids_joined = ", ".join(finding_ids_sorted)
        if len(finding_ids_joined) > 4000:
            finding_ids_joined = finding_ids_joined[:4000 - 3] + "..."
        #else:
        #    #expected wait time for score results less than 15 minutes
        #    raw_evidence += ("Waiting for score results or an error occured...")
            
        avits_flat = [avit for avits in list_avits for avit in avits]

        confidence = controlclass.get_control_confidence(num_validation_types)

        status["control"] = name
        status['passed'] = success
        status['avit'] = avits_flat
        status['number'] = total_pass
        status['confidence'] = confidence
        cleaned_validations = []
        for v in updated_validations:
            v.pop("_evidence_internal", None)
            cleaned_validations.append(v)
        status['validations'] = cleaned_validations
        status['raw_evidence'] = raw_evidence
        status['evidence'] = evidence
        status['finding_ids'] = finding_ids_joined
        status['review_required'] = 'No'

        if "skip_failure" in control:
            skip_failure = control["skip_failure"]["BOOL"]
            if skip_failure and success is False:
                status['passed'] = False
                status['review_required'] = 'Yes'

        if "skip_pass" in control:
            skip_pass = control["skip_pass"]["BOOL"]
            if skip_pass and success is True:
                status['passed'] = True
                status['review_required'] = 'Yes'

        status = check_snow_limit(status)
        return status

def process_validation(identifier, sast_scannable, dast_scannable, qa_control=None, controls=None):
    control_status = []
    controls_needed = []
    validation_res = []
    entity_classes = []
    sast_compliant = False
    dast_compliant = False
    sast_metadata = []
    dast_metadata = []
    vulns = []
    libraries = []
    sbom = []
    posture_gaps = None
    saltonboard_results = False
    wiz_vulns = []
    splunk_status = []
    kong_results = []
    sast_invaracode = None
    dast_isonboarded = None
    repos = []
    ot_vulns = []
    splunkot_data =[]
    network_compliance = []
    akamai_data = []
    USE_API = CONFIG["USE_API"]
    controlclass = Controlclass()
    codeql_vulns = []
    gitleaks_findings = []
    ghas_findings = []

    # Retrieve indicators for 1 entity to be processed (e.g. appci, infrastructure)
    dynamo = boto3.client('dynamodb')
    dynamo_results = dynamo.get_item(TableName='eqa-cdr-processing-table', Key={"identifier": {"S": identifier}})

    # Use controls from SNS message if provided, otherwise fall back to DynamoDB validation_queue
    if controls:
        # Controls passed from SNS message (from dispatch lambda)
        if isinstance(controls, str):
            try:
                validation_queue = json.loads(controls)
            except Exception:
                validation_queue = []
        else:
            validation_queue = controls
        logger.info(f"Using controls from SNS message for identifier {identifier}")
    else:
        # Fall back to DynamoDB validation_queue
        try:
            validation_queue = json.loads(dynamo_results['Item']['validation_queue']['S'])
        except Exception:
            validation_queue = []
    
    if validation_queue:
        # Use the queue of controls found in prior control results
        for item in validation_queue:
            if isinstance(item, dict) and "control" in item:
                controls_needed.append(item["control"])
    else:
        # When no queue exists
        logger.warning(f"Validation queue is empty for identifier {identifier}")
        control_status = {'error': f'Validation queue is empty for identifier {identifier}'}
        return control_status

    identifier = process_identifier(identifier, entity_classes)   
 
    if qa_control is None:
        controls = controlclass.get_enabled_controls(controls_needed)
    else:
        controls = [qa_control]
        
    name_to_control = {
        control["control"]["S"]: control
        for control in controls
    }
    
    duplicate_name_groups = controlclass.get_validators_duplicates(controls)
    duplicated_names = {
        name for group in duplicate_name_groups for name in group
    }
    control_groups = [
        [ name_to_control[name] for name in name_group ]
        for name_group in duplicate_name_groups
    ]

    for control in controls:
        name = control["control"]["S"]
        if name not in duplicated_names:
            control_groups.append([control])

    validation_types = controlclass.get_all_validation_types(controls)
    validation_generator = ValidatorGenerator()
    findings_data = FindingsData()
    github = GithubIntegration()

    # Initialize variables based on validation types
    if "findings" in validation_types or "sbom" in validation_types or "onboarded" in validation_types: 
        if sast_scannable or dast_scannable:
            if USE_API:
                sast_compliant, dast_compliant, sast_metadata, dast_metadata = findings_data.get_scan_compliance_by_api(
                    identifier, sast_scannable, dast_scannable)
            else:
                sast_compliant, dast_compliant, sast_metadata, dast_metadata, sast_invaracode, dast_isonboarded = findings_data.get_scan_compliance(
                    identifier, sast_scannable, dast_scannable)

    if "validation_results" in dynamo_results['Item']:
        validation_res = json.loads(dynamo_results['Item']['validation_results']['S'])

    if "findings" in validation_types:
        if sast_scannable or dast_scannable:
            vulns = validation_generator.bootstrap_findings_validator(identifier, sast_compliant, dast_compliant, USE_API, sast_scannable, dast_scannable)

    if "pipeline" in validation_types or "source" in validation_types:
        repos = github.get_repos_by_appci(identifier)

    if "wiz" in validation_types:
        if not USE_API:
            wiz_vulns = validation_generator.bootstrap_wiz_validator(identifier)

    if "sbom" in validation_types:
        libraries, sbom = validation_generator.bootstrap_sbom_validator(identifier, sast_compliant)

    if "salt" in validation_types:
        posture_gaps = validation_generator.bootstrap_salt_validator(identifier)

    if "kong" in validation_types:
        kong_results = validation_generator.bootstrap_kong_validator(identifier)

    if "saltonboard" in validation_types:
        saltonboard_results = validation_generator.bootstrap_saltonboard_validator(identifier)

    if "ot" in validation_types:
        ot_vulns = validation_generator.bootstrap_ot_validator(identifier)

    if "splunk" in validation_types:
        splunk_status = validation_generator.bootstrap_splunk_validator(identifier)
    
    if "splunkot" in validation_types:        
        splunkot_data = validation_generator.bootstrap_splunkot_validator(identifier)
        
    if "network" in validation_types:
        #Input: network controls
        #Bootstrap validator will convert controls into associated policies
        #and retreive all data from those policies. We are not able to search by mac address/device.
        network_compliance = validation_generator.bootstrap_network_validator(controls)
    if "akamai" in validation_types:
        sleep(2)
        akamai_data = validation_generator.bootstrap_akamai_validator(identifier)
    if "codeql" in validation_types:
        codeql_vulns = validation_generator.bootstrap_codeql_validator(identifier)

    if "gitleaks" in validation_types:
        gitleaks_findings = validation_generator.bootstrap_gitleaks_validator(identifier)

    if "ghas" in validation_types:
        ghas_findings = validation_generator.bootstrap_ghas_validator(identifier)

    with ThreadPoolExecutor(max_workers=3) as executor:
        future_to_group = {
            executor.submit(
                ControlProcessor().process_control,
                group[0],            # run only the first (representative)
                identifier, qa_control, entity_classes, validation_generator, sast_compliant, dast_compliant, sast_metadata, 
                dast_metadata, vulns, libraries, sbom, posture_gaps, saltonboard_results, wiz_vulns, splunk_status, kong_results, sast_invaracode, 
                dast_isonboarded, sast_scannable, dast_scannable, repos, ot_vulns, splunkot_data, network_compliance, akamai_data, codeql_vulns, gitleaks_findings, ghas_findings
            ): group
            for group in control_groups
        }

        for future in as_completed(future_to_group):
            group = future_to_group[future]
            try:
                status = future.result()
                for control in group:                    
                    if control is group[0]:
                        control_status.append(status)
                    else:
                        duplicate_status = copy.deepcopy(status)
                        duplicate_status["control"] = control["control"]["S"]
                        control_status.append(duplicate_status)
            except Exception as e:
                rep_control = group[0]
                logger.warning(f"Processing control {rep_control['control']['S']}: {e}")
    executor.shutdown(wait=True)

    if qa_control is not None:
        return control_status

    control_status_names = [item["control"] for item in control_status]
    skipped_controls = [
        item for item in validation_res
        if item["control"] not in control_status_names
    ]
    merged_status = control_status + skipped_controls
    merged_status = check_dynamo_limit(merged_status)

    return merged_status

def extract_control_from_json(branch_name):
    # Extract control from branch name
    split_branch_name = branch_name.split("-")
    control_name ="CDR-"+ split_branch_name[1] + split_branch_name[2]
    standard=split_branch_name[1]

    return control_name, standard

def get_qa_control(control):
    # Align control data with dynamodb json format
    return {
        "enabled": {"BOOL": True},
        "control": {"S": control["control"]},
        "definition": {"S": control["definition"]},
        "confidence": {"S": "medium"},
        "description": {"S": control["description"]},
        "validators": {"S": json.dumps(control["validators"])}
    }

def get_accepted_standards():
    # Get safe filenames of all standards in the controls folder so we can validate input
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'control', 'appsecrequirements'))
    valid_standards = set()

    for filename in os.listdir(base_dir):
        if filename.endswith(".json"):
            # Extract standard from filename
            name = os.path.splitext(filename)[0]
            valid_standards.add(name)
    
    return list(valid_standards)

def qa_control(branch_name):
    accepted_standards = get_accepted_standards()

    # If branch name present, extract control from branch name
    control_name, standard = extract_control_from_json(branch_name)

    if not control_name:
        logger.warning(f"Branch name '{branch_name}' does not contain a control. Skipping validation.")
        sys.exit(0)

    # Check if standard name is an acceptable input
    if not standard or standard not in accepted_standards:
        logger.warning(f"No standard found. Skipping validation.")

    # Get control data from controls.json
    controls_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'control', 'appsecrequirements', f"{standard}.json"))
    with open(controls_path, 'r', encoding='utf-8') as json_data:
        content = json.load(json_data)
    for control in content:
        if control_name in control["control"]: # Search for the control specified in branch name
            control_details = get_qa_control(control) # Cast the data to the expected DynamoDB format
    
    return control_details

'''
if __name__ == '__main__':
    process = ControlProcessor()
    # all_controls = process_validation("BDZ", True, True)
    control = qa_control("CDR-SSDF-2.4.1")
    all_controls = process_validation("BDZ", True, True, control)
    print(f'All controls: {all_controls}')
'''

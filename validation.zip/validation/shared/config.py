CONFIG = {
    "ENV": "local", # Change to local for local testing
    "USE_API": False # Change to true for API testing 
}


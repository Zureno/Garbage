import boto3
from .logger import logger
import os
from functools import lru_cache
from botocore.exceptions import ClientError

# Lazy-load SSM client to allow region to be set first
_ssm_client = None

def get_ssm_client():
    """Get or create SSM client (lazy-loaded)"""
    global _ssm_client
    if _ssm_client is None:
        region = os.environ.get('AWS_REGION', 'us-east-1')
        _ssm_client = boto3.client('ssm', region_name=region)
    return _ssm_client

@lru_cache(maxsize=None)
def get_ssm_parameter(param_name):
    try:
        ssm = get_ssm_client()
        response = ssm.get_parameter(Name=param_name, WithDecryption=True)
        return response['Parameter']['Value']
    except ClientError as e:
        logger.warning(f"Fetching parameter {param_name}: {e}")
        raise
    except Exception as e:
        logger.warning(f"Fetching parameter {param_name}: {e}")
        raise
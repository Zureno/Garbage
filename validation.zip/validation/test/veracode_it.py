import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..', 'src')))
import pytest
from datetime import datetime, timedelta
from src.validation.shared.athena_integration import AthenaIntegration


@pytest.fixture(scope="module")
def cleanup():
    yield
    # Add any cleanup code here, e.g., deleting test data from Athena


def test_execute_athena_query_integration(cleanup):
    test_database = 'appsec_database_for_datalake_shared_resources'
    test_table = 'appsec_vuln_shared'
    athena_instance = AthenaIntegration()

    columns = ["Vulnerability Name", "severity", "scan type", "age (days)", "application_name", "status",
               "vulnerability id", "source", "appci", "updated on"]
    query = AthenaIntegration.construct_secure_query(test_table, columns, limit=5)
    results = athena_instance.execute_athena_query(test_database, query)

    assert len(results) > 0
    assert isinstance(results[0], dict)
    assert all(col in results[0] for col in columns)


def test_execute_athena_query_with_where_clause(cleanup):
    test_database = 'appsec_database_for_datalake_shared_resources'
    test_table = 'appsec_vuln_shared'
    athena_instance = AthenaIntegration()

    columns = ["Vulnerability Name", "severity", "scan type", "age (days)", "application_name", "status",
               "vulnerability id", "source", "appci", "updated on"]
    where_clauses = [{'column': 'appci', 'operator': '=', 'value': 'EKA'}]
    query = AthenaIntegration.construct_secure_query(test_table, columns, where_clauses=where_clauses)
    results = athena_instance.execute_athena_query(test_database, query)

    for row in results:
        assert row['appci'] == 'EKA'


def test_execute_athena_query_no_results(cleanup):
    test_database = 'appsec_database_for_datalake_shared_resources'
    test_table = 'appsec_vuln_shared'
    athena_instance = AthenaIntegration()

    columns = ["Vulnerability Name", "severity", "scan type", "age (days)", "application_name", "status",
               "vulnerability id", "source", "appci", "updated on"]
    where_clauses = [{'column': 'appci', 'operator': '=', 'value': 'NOT_AVAIL'}]
    query = AthenaIntegration.construct_secure_query(test_table, columns, where_clauses=where_clauses)
    results = athena_instance.execute_athena_query(test_database, query)

    assert len(results) == 0


def test_execute_athena_query_failure(cleanup):
    test_database = 'appsec_database_for_datalake_shared_resources'
    test_table = 'a_non_existent_table'
    athena_instance = AthenaIntegration()

    columns = ["Vulnerability Name", "severity", "scan type", "age (days)", "application_name", "status",
               "vulnerability id", "source", "appci", "updated on"]
    query = AthenaIntegration.construct_secure_query(test_table, columns)
    with pytest.raises(Exception) as exec_info:
        athena_instance.execute_athena_query(test_database, query)

    error_message = str(exec_info.value)
    assert 'Query failed with state: FAILED' in error_message


def test_construct_secure_query():
    test_table = 'my_test_table'
    columns = ["Vulnerability Name", "severity", "scan type", "age (days)", "application_name", "status",
               "vulnerability id", "source", "appci", "updated on"]
    where_clauses = [
        {'column': 'severity', 'operator': '=', 'value': 'HIGH'},
        {'column': 'age (days)', 'operator': '>', 'value': 30}
    ]
    order_by_clauses = [{'column': 'updated on', 'ascending': False}]
    limit = 10

    query = AthenaIntegration.construct_secure_query(test_table, columns, where_clauses, order_by_clauses, limit)

    assert 'SELECT' in query
    assert f'FROM {test_table}' in query

    for col in columns:
        if ' ' in col:
            assert f'{test_table}."{col}' in query
        else:
            assert f'{test_table}.{col}' in query

    assert f"{test_table}.severity = 'HIGH'" in query
    assert f'{test_table}."age (days)" > 30' in query

    assert f'ORDER BY {test_table}."updated on" DESC' in query

    assert "LIMIT 10" in query


def test_get_datalake_sast_findings():
    athena_instance = AthenaIntegration()
    appci = 'TestApp'
    cwe = 'CWE-79'
    source = 'Veracode'

    results = athena_instance.get_datalake_sast_findings(appci, cwe, source)

    assert isinstance(results, list)


def test_get_datalake_dast_findings():
    athena_instance = AthenaIntegration()
    appci = 'TestApp'
    cwe = 'CWE-89'
    source = 'Netsparker'

    results = athena_instance.get_datalake_dast_findings(appci, cwe, source)

    assert isinstance(results, list)

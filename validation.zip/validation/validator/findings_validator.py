import re
import boto3
from .logger import logger
from shared.config import CONFIG

USE_API = CONFIG["USE_API"]

TABLE_NAME = 'eqa-cwe-mappings-table'

_cwe_desc_cache = {}
_cwe_items_cache = None

def _scan_all(table):
    # Scan all items from a DynamoDB table, handling pagination.
    items = []
    resp = table.scan()
    items.extend(resp.get('Items', []))
    while 'LastEvaluatedKey' in resp:
        resp = table.scan(ExclusiveStartKey=resp['LastEvaluatedKey'])
        items.extend(resp.get('Items', []))
    return items

def _preload_cwe_items_cache():
    # Preload and cache all CWE mapping records to minimize repeated DynamoDB calls.
    global _cwe_items_cache
    if _cwe_items_cache is not None:
        return _cwe_items_cache
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(TABLE_NAME)
        all_items = _scan_all(table)
        # Index by cwe_id for quick lookups
        _cwe_items_cache = {str(it.get('cwe_id')): it for it in all_items if 'cwe_id' in it}
        return _cwe_items_cache
    except Exception:
        _cwe_items_cache = {}
        return _cwe_items_cache

def get_cwe_description_from_table(cwe_id: str, source: str):
    # Return description from DynamoDB when cwe_id matches and source equals the vuln scan type.
    # Uses simple in-memory cache to avoid repeated calls.
    cache_key = (str(cwe_id), str(source).lower())
    if cache_key in _cwe_desc_cache:
        return _cwe_desc_cache[cache_key]

    # Prefer using the preloaded cache of all items; fall back gracefully.
    items_cache = _preload_cwe_items_cache()
    item = items_cache.get(str(cwe_id))
    if not item:
        _cwe_desc_cache[cache_key] = None
        return None
    item_source = str(item.get('source', '')).lower()
    if item_source == str(source).lower():
        # Prefer cwe_name from table as description when source matches
        desc = str(item.get('cwe_name', '')).strip() or None
        _cwe_desc_cache[cache_key] = desc
        return desc
    # Source mismatch: fall back to None
    _cwe_desc_cache[cache_key] = None
    return None

class FindingsValidator:
    def validate(self, mapping, vulns):
        criteria = mapping.get('criteria', [])
        tool = mapping.get('tool', '')
        scope = mapping.get('scope', '')
        exclude_list = mapping.get('exclude', [])
        regex_include_list = mapping.get('regexinclude', [])
        success = True
        exception = False
        avits = []
        evidence = {
            "scan_type": tool.lower(),
            "avit_ids": [],
            "cwe_details": [],
            "FindingIDs": []
        }

        logger.info(f"Starting findings validation with tool: {tool}, criteria count: {len(criteria)}, vulns count: {len(vulns)}")

        # Iterate over every vuln and match based on tool type
        for vuln in vulns:
            try:
                avit = vuln.get("cwes",'')
                remediation = vuln.get("remediation_description", "")
                cwes_raw = vuln.get("cwes", "")
                display_name = vuln.get("display_name", "")
                
                vuln_scan_type_raw = vuln.get("scan_type", "").upper()
                # Convert STATIC, SCA and SAST to veracode and DYNAMIC and DAST to invicti
                if vuln_scan_type_raw == 'STATIC' or vuln_scan_type_raw == 'SAST' or vuln_scan_type_raw == 'SCA':
                    vuln_scan_type = 'veracode'
                elif vuln_scan_type_raw == 'DYNAMIC' or vuln_scan_type_raw == 'DAST':
                    vuln_scan_type = 'invicti'
                else:
                    vuln_scan_type = vuln_scan_type_raw.lower()

                if tool.lower() in ['veracode', 'invicti'] and scope.lower() != 'cwe':
                    # Match against remediation_description for SAST/DAST
                    # Only match if the vuln scan_type matches the tool type
                    
                    
                    # Skip if scan types don't match
                    if vuln_scan_type != tool.lower():
                        logger.debug(f"Skipping vuln {avit}: scan_type mismatch (vuln: {vuln_scan_type}, tool: {tool.lower()})")
                        continue
                    
                    for crit in criteria:
                        crit_norm = str(crit).strip().lower()
                        remediation_norm = str(remediation).strip().lower()
                        if crit_norm in remediation_norm:
                            if avit not in avits:
                                logger.info(f"SAST/DAST/SCA match found - avit: {avit}, criteria: {crit}, remediation: {remediation[:50]}...")
                                avits.append(avit)
                            # Capture Finding ID (VIPR Silk ID) if present and unique
                            silk_id = str(display_name).strip()
                            if silk_id and silk_id not in evidence["FindingIDs"]:
                                evidence["FindingIDs"].append(silk_id)
                            # Extract CWE numbers from the cwes field
                            cwes_str = str(cwes_raw).replace('[', '').replace(']', '').replace("'", '').replace('"', '')
                            cwe_numbers = []
                            for part in cwes_str.split(','):
                                part = part.strip()
                                match = re.search(r'(?:CWE-)?(\d+)', part)
                                if match:
                                    cwe_numbers.append(match.group(1))
                            # Add entries to cwe_details using remediation description
                            for cwe_id in cwe_numbers:
                                # Avoid duplicates
                                if not any(d.get('id') == cwe_id for d in evidence["cwe_details"]):
                                    # Attempt to pull description from DynamoDB when source equals vuln scan type
                                    table_desc = get_cwe_description_from_table(cwe_id, vuln_scan_type)
                                    description_val = table_desc if table_desc else (str(remediation) if remediation is not None else "")
                                    evidence["cwe_details"].append({
                                        "id": cwe_id,
                                        "description": description_val
                                    })
                
                elif tool.lower() in ['veracode', 'invicti', 'both'] and scope.lower() == 'cwe':

                    # Skip if scan types don't match
                    if vuln_scan_type != tool.lower() and tool.lower() != 'both':
                        logger.debug(f"Skipping vuln {avit}: scan_type mismatch (vuln: {vuln_scan_type}, tool: {tool.lower()})")
                        continue

                    # Extract all CWE numbers from the string like "['CWE-79']" or "['CWE-1035, 937']"
                    # Remove brackets and quotes, split by comma
                    cwes_str = str(cwes_raw).replace('[', '').replace(']', '').replace("'", '').replace('"', '')
                    # Extract all numbers that follow "CWE-" or are standalone numbers
                    cwe_numbers = []
                    for part in cwes_str.split(','):
                        part = part.strip()
                        # Match "CWE-XXX" or just "XXX"
                        match = re.search(r'(?:CWE-)?(\d+)', part)
                        if match:
                            cwe_numbers.append(match.group(1))
                    
                    logger.debug(f"Processing CWE for avit {avit}: extracted CWE numbers: {cwe_numbers}")                 
                    
                    for crit in criteria:
                        # Criteria might be just a number or "CWE-XXX"
                        crit_str = str(crit).strip()
                        crit_match = re.search(r'(?:CWE-)?(\d+)', crit_str)
                        if crit_match:
                            crit_num = crit_match.group(1)
                            if crit_num in cwe_numbers:

                                # CWE matched, now check exclusion list
                                is_excluded = False
                                
                                # Exclusion format: [tool, description]
                                for exclusion in exclude_list:
                                    excl_tool = str(exclusion[0]).strip().lower()
                                    excl_desc = str(exclusion[1]).strip().lower()

                                    # Only exclude if both tool matches vuln's scan_type and description matches
                                    if excl_tool == vuln_scan_type:
                                        remediation_norm = str(remediation).strip().lower()
                                        if excl_desc in remediation_norm:
                                            is_excluded = True
                                            logger.debug(f"CWE match excluded - avit: {avit}, CWE: {crit_num}, vuln_scan_type: {vuln_scan_type}, exclusion tool: {excl_tool}, exclusion: {excl_desc}, remediation: {remediation[:50]}...")
                                            break
                                
                                # Only add if CWE matched AND not excluded
                                if not is_excluded:
                                    # Determine if regexinclude gating applies
                                    if regex_include_list:
                                        regex_matched = False
                                        for pattern in regex_include_list:
                                            try:
                                                if re.search(pattern, str(remediation), flags=re.IGNORECASE):
                                                    regex_matched = True
                                                    logger.debug(f"regexinclude match - avit: {avit}, pattern: {pattern}, remediation: {str(remediation)[:50]}...")
                                                    break
                                            except re.error as rex:
                                                logger.error(f"Invalid regex pattern in regexinclude: {pattern} - {rex}")
                                        if not regex_matched:
                                            # Regex list present but none matched: do not add
                                            logger.debug(f"CWE matched but no regexinclude pattern matched - avit: {avit}, CWE: {crit_num}")
                                            continue
                                    # Add when CWE matched, not excluded, and (regex matched or no regex list provided)
                                    if avit not in avits:
                                        if regex_include_list:
                                            logger.info(f"CWE + regex match found - avit: {avit}, criteria CWE: {crit_num}, vuln CWEs: {cwe_numbers}")
                                        else:
                                            logger.info(f"CWE match found - avit: {avit}, criteria CWE: {crit_num}, vuln CWEs: {cwe_numbers}")
                                        avits.append(avit)
                                    # Capture Finding ID (VIPR Silk ID) if present and unique (also for CWE-scope matches)
                                    silk_id = str(display_name).strip()
                                    if silk_id and silk_id not in evidence["FindingIDs"]:
                                        evidence["FindingIDs"].append(silk_id)
                                    # Track evidence of matched CWE id using remediation description
                                    if not any(d.get('id') == crit_num for d in evidence["cwe_details"]):
                                        # Attempt to pull description from DynamoDB when source equals vuln scan type
                                        table_desc = get_cwe_description_from_table(crit_num, vuln_scan_type)
                                        description_val = table_desc if table_desc else (str(remediation) if remediation is not None else "")
                                        evidence["cwe_details"].append({
                                            "id": crit_num,
                                            "description": description_val
                                        })
                
                # Check if there's criticality in the mapping
                criticality = mapping.get('criticality')
                if criticality:
                    # Match against severity field
                    vuln_severity = vuln.get("severity", "").strip().upper()
                    # Handle criticality as list or string
                    if isinstance(criticality, list):
                        crit_values = [str(c).strip().upper() for c in criticality]
                    else:
                        crit_values = [str(criticality).strip().upper()]
                    if vuln_severity in crit_values:
                        if avit not in avits:
                            logger.info(f"Criticality match found - avit: {avit}, severity: {vuln_severity}, required: {crit_values}")
                            avits.append(avit)
                
            except Exception as e:
                logger.error(f"Error processing vuln in findings validator: {e}", exc_info=True)
                exception = True
                success = "NA"
                evidence["avit_ids"] = list(avits)
                if not evidence["cwe_details"]:
                    evidence = "Error during validation"
                return success, avits, exception, evidence

        if avits:
            success = False
            logger.info(f"Validation failed - found {len(avits)} matching avits: {avits}")
        else:
            logger.info(f"Validation passed - no matching vulnerabilities found")
        evidence["avit_ids"] = list(avits)
        return success, avits, exception, evidence

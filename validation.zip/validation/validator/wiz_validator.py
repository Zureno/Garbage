class WizValidator:
    def validate(self, mappings, wiz_vulns):
        success = True
        total = 0
        metadata = []
        criteria = mappings['criteria']

        for vuln in wiz_vulns:
            name = vuln["title"]

            for crit in criteria:
                if crit == name:
                    if vuln not in metadata:
                        metadata.append(vuln)
                    total += 1

        if total > 0:
            success = False

        return success

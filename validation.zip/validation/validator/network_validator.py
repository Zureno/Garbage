class NetworkValidator:
    def validate(self, mappings, network_vulns, identifier):
        criteria = mappings["criteria"]
        noncompliance = network_vulns.get("Non_Compliant_json")
        
        for vuln in noncompliance:
            if vuln.get("name").strip() == identifier.strip():
                #If hostname, then check for matching control name
                for crit in criteria:
                    if crit in vuln.get("reasonForFailure", ""):
                        return False
        return True
import logging

class SaltValidator:

    def validate(self, mapping, posture_gaps):
        success = False # fail by default. prove success
        try:
            salt_records = posture_gaps

            # Validate mapping structure
            if not isinstance(mapping, dict):
                logging.error("Mapping is not a dictionary: %s", mapping)
                return False
            if "criteria" not in mapping or not isinstance(mapping["criteria"], list):
                logging.error("'criteria' key missing or not a list in mapping: %s", mapping)
                return False

            if salt_records == ['NA']:
                success = False # fail if not onboarded
                return success

            if not isinstance(salt_records, list):
                logging.error("posture_gaps is not a list: %s", salt_records)
                return False

            if len(salt_records) == 0:
                success = True # pass if no posture gaps found
                return success
            
            if salt_records != ['NA']:
                for record in salt_records:
                    if not isinstance(record, dict):
                        logging.warning("Record is not a dictionary: %s", record)
                        continue
                    for criteria in mapping["criteria"]:
                        try:
                            if record.get("postureGapName") == criteria:
                                success = False
                        except Exception as e:
                            logging.error("Error processing record %s: %s", record, e)
                            continue
        except Exception as e:
            logging.exception("Exception occurred in SaltValidator.validate: %s", e)
            return False

        return success

import logging

class SaltonboardValidator:

    def validate(self, mapping, results):
        success = False # fail by default. prove success
        try:
            salt_records = results
            # Validate mapping structure
            if not isinstance(mapping, dict):
                logging.error("Mapping is not a dictionary: %s", mapping)
                return False
            if "criteria" not in mapping or not isinstance(mapping["criteria"], list):
                logging.error("'criteria' key missing or not a list in mapping: %s", mapping)
                return False
            if salt_records == True:
                success = True # fail if not onboarded
                return success
        except Exception as e:
            logging.exception("Exception occurred in SaltValidator.validate: %s", e)
            return False

        return success

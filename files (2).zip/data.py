from datetime import datetime, timedelta
from debugger import logger, debug_trace, log_metric
from helpers import execute_athena_query, wait_for_query, get_query_results

# Database and table constants for Akamai onboarding compliance data
DATABASE = "appsec_database_for_datalake_shared_resources"
TABLE = "akamai_onboarding_shared"


def _q(name: str) -> str:
    """Quote an Athena identifier for safe query construction."""
    return f'"{name}"'


@debug_trace("get_akamai_onboarding_compliance")
def get_akamai_onboarding_compliance(appci: str) -> list[str]:
    """
    Query Athena for AppCI compliance data and evaluate onboarding status.
    
    Returns ["akamai"] if compliant, [] if not compliant.
    Raises ValueError on missing appci or RuntimeError on Athena errors.
    """
    if not appci:
        raise ValueError("Parameter appci is mandatory")

    # Escape single quotes in AppCI identifier for SQL injection prevention
    safe_appci = str(appci).replace("'", "''")

    # Build multi-CTE query: filter by AppCI → get latest partition → get latest period
    sql = (
        f"WITH base_filtered AS ( "
        f"  SELECT * "
        f"  FROM {_q(DATABASE)}.{_q(TABLE)} "
        f"  WHERE {_q('appci')} = '{safe_appci}' "
        f"), "
        f"latest_p0 AS ( "
        f"  SELECT max({_q('partition_0')}) AS p0 "
        f"  FROM base_filtered "
        f"), "
        f"latest_period AS ( "
        f"  SELECT date_format( "
        f"           max(date_parse({_q('period')}, '%m-%d-%Y')), "
        f"           '%m-%d-%Y' "
        f"         ) AS per "
        f"  FROM base_filtered "
        f"  WHERE {_q('partition_0')} = (SELECT p0 FROM latest_p0) "
        f"), "
        f"filtered_latest AS ( "
        f"  SELECT * "
        f"  FROM base_filtered "
        f"  WHERE {_q('partition_0')} = (SELECT p0 FROM latest_p0) "
        f"    AND {_q('period')} = (SELECT per FROM latest_period) "
        f") "
        f"SELECT * "
        f"FROM filtered_latest "
        f"ORDER BY {_q('partition_0')} DESC "
    )

    # Execute Athena query (non-blocking start)
    qid = execute_athena_query(DATABASE, sql)
    if not qid:
        raise RuntimeError(f"Athena query failed to start for Akamai validator (appci={appci})")

    # Wait for query to complete
    wait_for_query(qid)
    logger.info(f"Athena query for akamai validator (id={qid}) executed successfully")
    
    # Fetch all result rows as dicts
    rows = get_query_results(qid)
    log_metric("athena_records_retrieved", len(rows), "records")

    # ─────────────────────────────────────────────────────────────────────────────
    # Evaluate each record for compliance against criteria
    # ─────────────────────────────────────────────────────────────────────────────
    pass_records = 0
    fail_records = 0
    special_pass = 0

    for record in rows:
        # Extract all relevant fields from record
        onboarding_candidate = str(record.get("onboarding_canidate", "")).strip().lower()
        covered = str(record.get("covered", "")).strip().lower()
        acronym = str(record.get("acronym", "")).strip()
        operational_status = str(record.get("operational_status", "")).strip()
        hosting_type = str(record.get("hosting_type", "")).strip()
        dns = str(record.get("dns", "")).strip()
        source = str(record.get("source", "")).strip()
        network_exposure = str(record.get("network_exposure", "")).strip()
        third_party = str(record.get("third_party", "")).strip()

        # Records excluded from compliance evaluation (special cases)
        if (
            acronym == "" or acronym.upper() == "RETIRED"
            or operational_status == "" or operational_status == "Retired"
            or hosting_type == "SaaS"
            or hosting_type == "NA"
            or dns == ""
            or "ualaki" in dns.lower()
            or "acme-challenge" in dns.lower()
            or source in ("docker-sidecar", "docker-sidecar,gigamon")
            or network_exposure != "External facing (Available on Internet)"
            or third_party == ""
            or third_party == "Yes"
        ):
            special_pass += 1
            logger.info(f"Record passes special conditions for AppCI {appci}")
            continue

        # Failing combination: candidate yes + not covered, or candidate no + covered
        if (
            (onboarding_candidate == "yes" and covered == "no")
            or (onboarding_candidate == "no" and covered == "yes")
        ):
            fail_records += 1
            logger.info(f"Failing combination found for AppCI {appci}")

        # Passing combination: candidate=covered (both yes or both no)
        elif (
            (onboarding_candidate == "yes" and covered == "yes")
            or (onboarding_candidate == "no" and covered == "no")
        ):
            pass_records += 1

        # Anything else is treated as a failure
        else:
            fail_records += 1

    # ─────────────────────────────────────────────────────────────────────────────
    # Determine overall compliance based on record counts
    # ─────────────────────────────────────────────────────────────────────────────
    if pass_records == 0 and fail_records == 0 and special_pass == 0:
        compliant = False
    elif fail_records == 0:
        compliant = True
    else:
        compliant = False

    # Log all key metrics from evaluation
    log_metric("records_evaluated", len(rows) - special_pass, "records")
    log_metric("records_passed", pass_records, "records")
    log_metric("records_failed", fail_records, "records")
    log_metric("records_special_pass", special_pass, "records")

    status = "PASS" if compliant else "FAIL"
    logger.info(f"Akamai onboarding & coverage compliance for {appci}: {status}")
    log_metric("compliance_status", status)

    return ["akamai"] if compliant else []

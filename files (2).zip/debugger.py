import json
import time
from functools import wraps
from typing import Any, Callable
from aws_lambda_powertools import Logger

# Initialize base logger
logger = Logger(service="akamaivalidator-lambda")


class DebugContext:
    """Track metrics and execution flow for a single invocation."""
    
    def __init__(self):
        self.metrics = {}
        self.execution_trace = []
        self.start_time = time.time()
        self.enabled = True
    
    def log_metric(self, name: str, value: Any, unit: str = ""):
        """Store a metric (count, duration, etc)."""
        self.metrics[name] = {"value": value, "unit": unit}
    
    def log_trace(self, message: str, level: str = "INFO"):
        """Add to execution trace."""
        if self.enabled:
            self.execution_trace.append({
                "timestamp": time.time() - self.start_time,
                "level": level,
                "message": message
            })
    
    def get_summary(self) -> dict:
        """Return metrics and trace summary."""
        return {
            "duration_ms": (time.time() - self.start_time) * 1000,
            "metrics": self.metrics,
            "trace_count": len(self.execution_trace)
        }


# Global debug context for the current invocation
_debug_context = None


def init_debug_context():
    """Initialize debug context for this invocation."""
    global _debug_context
    _debug_context = DebugContext()
    return _debug_context


def get_debug_context() -> DebugContext:
    """Get current debug context."""
    global _debug_context
    if _debug_context is None:
        _debug_context = DebugContext()
    return _debug_context


def debug_trace(name: str = None):
    """
    Decorator to trace function execution with entry/exit logging and metrics.
    
    Usage:
        @debug_trace("validate_records")
        def validate_records(data):
            ...
    """
    def decorator(func: Callable) -> Callable:
        func_name = name or func.__name__
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            ctx = get_debug_context()
            start = time.time()
            
            # Log function entry
            logger.info(f"→ START {func_name}")
            ctx.log_trace(f"Function start: {func_name}")
            
            try:
                result = func(*args, **kwargs)
                elapsed = time.time() - start
                
                # Log function exit with duration
                logger.info(f"← END {func_name} ({elapsed*1000:.1f}ms)")
                ctx.log_trace(f"Function end: {func_name} ({elapsed*1000:.1f}ms)")
                
                return result
            
            except Exception as e:
                elapsed = time.time() - start
                logger.exception(f"✗ FAILED {func_name} ({elapsed*1000:.1f}ms): {e}")
                ctx.log_trace(f"Function failed: {func_name}", "ERROR")
                raise
        
        return wrapper
    
    return decorator


def log_metric(metric_name: str, value: Any, unit: str = ""):
    """Log a key metric to the debug context."""
    ctx = get_debug_context()
    ctx.log_metric(metric_name, value, unit)
    logger.info(f"[METRIC] {metric_name}={value} {unit}".strip())


def log_execution_summary():
    """Log a summary of the execution with all captured metrics."""
    ctx = get_debug_context()
    summary = ctx.get_summary()
    
    logger.info(
        f"═══ EXECUTION SUMMARY ═══\n"
        f"Duration: {summary['duration_ms']:.1f}ms\n"
        f"Metrics collected: {len(summary['metrics'])}\n"
        f"Trace events: {summary['trace_count']}\n"
        f"Metrics: {json.dumps(summary['metrics'], indent=2)}"
    )


# Export base logger for direct use
__all__ = [
    "logger",
    "debug_trace",
    "log_metric",
    "log_execution_summary",
    "get_debug_context",
    "init_debug_context",
]

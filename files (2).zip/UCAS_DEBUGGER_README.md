# UCAS Debugger Implementation Guide

## Overview

The **UCAS Debugger** is an enhanced logging and debugging framework for the Akamai Validator Lambda function. It provides:

✅ **Function-level tracing** — Logs entry/exit for every function  
✅ **Key metrics collection** — Captures record counts, pass/fail stats, execution times  
✅ **Execution summary** — Shows all metrics collected during invocation  
✅ **Short inline comments** — Code blocks describe functionality concisely  
✅ **AWS Lambda PowerTools integration** — Builds on existing structured logging  

---

## Architecture

### New Module: `debugger.py`

The core debugger module provides:

#### **DebugContext Class**
- Tracks metrics and execution flow for a single Lambda invocation
- Methods:
  - `log_metric(name, value, unit)` — Store a metric
  - `log_trace(message, level)` — Add execution trace
  - `get_summary()` — Return metrics and timing summary

#### **Decorators & Functions**

**`@debug_trace(name=None)`** — Function decorator
```python
@debug_trace("function_name")
def my_function():
    pass
```
- Logs function entry (`→ START`)
- Logs function exit with elapsed time (`← END`)
- Catches exceptions and logs (`✗ FAILED`)
- Example output:
  ```
  → START extract_lambda_input
  ← END extract_lambda_input (2.3ms)
  ```

**`log_metric(name, value, unit="")`** — Manual metric logging
```python
log_metric("records_passed", 42, "records")
# Output: [METRIC] records_passed=42 records
```

**`log_execution_summary()`** — Print all metrics collected
```python
log_execution_summary()
# Output shows: duration, metrics count, trace events, all metrics as JSON
```

**`init_debug_context()`** — Initialize debugger for invocation
- Called at start of handler to reset metrics for new invocation
- Example:
  ```python
  def handler(event, context):
      init_debug_context()
      # ... rest of handler
  ```

---

## Updated Files

### **index.py** (Lambda Handler)
**Changes:**
- Import debugger utilities: `debug_trace`, `log_metric`, `log_execution_summary`
- Add `@debug_trace("handler")` decorator to handler function
- Call `init_debug_context()` at start
- Log key metric: `input_parsed = True`
- Log data retrieval: `akamai_data_retrieved = count`
- Log validation result: `validation_passed = bool`
- Log persistence: `result_persisted = True`
- Call `log_execution_summary()` at end to show all metrics

**Example metrics generated:**
```json
{
  "input_parsed": true,
  "akamai_data_retrieved": 15,
  "validation_passed": true,
  "result_persisted": true
}
```

### **input.py** (Event Parsing)
**Changes:**
- Add `@debug_trace("extract_lambda_input")` decorator
- Log metrics: `identifier`, `control`
- Add inline comments explaining SQS/SNS/Direct formats
- Describe validation logic

**Key metrics:**
- `identifier` — AppCI identifier from input
- `control` — Control name from input

### **data.py** (Athena Query & Compliance Evaluation)
**Changes:**
- Add `@debug_trace("get_akamai_onboarding_compliance")` decorator
- Log metrics:
  - `athena_records_retrieved` — Count of rows from Athena
  - `records_evaluated` — Records after excluding special cases
  - `records_passed` — Records with passing criteria
  - `records_failed` — Records with failing criteria
  - `records_special_pass` — Records excluded from evaluation
  - `compliance_status` — "PASS" or "FAIL"
- Add inline comments describing:
  - Query construction (CTEs, filtering)
  - Record evaluation logic
  - Compliance determination

**Key metrics example:**
```
[METRIC] athena_records_retrieved=20 records
[METRIC] records_evaluated=15 records
[METRIC] records_passed=12 records
[METRIC] records_failed=3 records
[METRIC] records_special_pass=5 records
[METRIC] compliance_status=PASS
```

### **validate.py** (Validation Logic)
**Changes:**
- Add `@debug_trace("validate_akamai")` decorator
- Log metrics:
  - `criteria` — Validation criteria as string
  - `akamai_data_items` — Count of data items
  - `validation_result` — "PASS" or "FAIL"
- Add comment describing criteria matching logic

### **output.py** (Result Building & Persistence)
**Changes:**
- Add `@debug_trace()` decorators to all functions:
  - `build_sort_key()`
  - `_build_evidence_message()`
  - `build_result()`
  - `write_result()`
- Log metrics:
  - `result_status` — PASS/FAIL result
  - `evidence_truncated` — Whether evidence exceeded 4000 chars
  - `dynamodb_write_success` — True on successful write
  - `dynamodb_write_error` — True on failure
- Add inline comments explaining:
  - Sort key format
  - Evidence message variants
  - Result schema
  - DynamoDB operation

### **helpers.py** (AWS Service Utilities)
**Changes:**
- Add `@debug_trace()` decorators to all functions:
  - `get_ssm_parameter()`
  - `execute_athena_query()`
  - `wait_for_query()`
  - `get_query_results()`
- Log metrics for:
  - SSM parameter retrieval
  - Athena query operations
  - Query completion status
  - Result row counts
- Add inline comments explaining:
  - SSM Parameter Store integration
  - S3 bucket configuration
  - Athena query execution (non-blocking start)
  - Query status polling
  - Result pagination

### **logger.py** (Compatibility)
**Changes:**
- Updated to import from `debugger.py` module
- Maintains backwards compatibility
- All code importing from `logger` continues to work

---

## Usage Examples

### Example 1: View Complete Execution Log

When you invoke the Lambda:

```
INFO    → START handler
INFO    → START extract_lambda_input
INFO    Parsed Direct invocation body received
INFO    [METRIC] identifier=BFM
INFO    [METRIC] control=CDR-NSS3.4.2
INFO    ← END extract_lambda_input (1.2ms)
INFO    Querying Akamai onboarding data for AppCI BFM
INFO    → START execute_athena_query
INFO    [METRIC] athena_query_started=a123b456
INFO    ← END execute_athena_query (45.3ms)
INFO    → START wait_for_query
INFO    [METRIC] athena_query_completed=SUCCESS
INFO    ← END wait_for_query (2341.5ms)
INFO    → START get_query_results
INFO    [METRIC] athena_results_fetched=20 rows
INFO    ← END get_query_results (12.1ms)
INFO    → START get_akamai_onboarding_compliance
INFO    [METRIC] athena_records_retrieved=20 records
INFO    [METRIC] records_evaluated=15 records
INFO    [METRIC] records_passed=12 records
INFO    [METRIC] records_failed=3 records
INFO    [METRIC] records_special_pass=5 records
INFO    [METRIC] compliance_status=PASS
INFO    ← END get_akamai_onboarding_compliance (2412.1ms)
INFO    → START validate_akamai
INFO    [METRIC] criteria=['akamai']
INFO    [METRIC] akamai_data_items=1
INFO    Akamai validation PASSED — criteria matched
INFO    [METRIC] validation_result=PASS
INFO    ← END validate_akamai (0.8ms)
INFO    → START build_result
INFO    [METRIC] result_status=PASS
INFO    ← END build_result (1.5ms)
INFO    → START write_result
INFO    [METRIC] dynamodb_write_success=True
INFO    ← END write_result (234.2ms)
INFO    ═══ EXECUTION SUMMARY ═══
INFO    Duration: 2694.7ms
INFO    Metrics collected: 18
INFO    Trace events: 24
INFO    Metrics: {
         "identifier": {"value": "BFM", "unit": ""},
         "control": {"value": "CDR-NSS3.4.2", "unit": ""},
         "records_passed": {"value": 12, "unit": "records"},
         ...
        }
INFO    ← END handler (2695.1ms)
```

### Example 2: Debugging a Failed Validation

If records fail evaluation:

```
INFO    [METRIC] records_evaluated=15 records
INFO    [METRIC] records_passed=0 records
INFO    [METRIC] records_failed=15 records
INFO    Akamai validation FAILED — criteria not met
INFO    [METRIC] validation_result=FAIL
```

You immediately see:
- All 15 records failed
- 0 passed
- Validation failed as expected

### Example 3: Detecting Timeout Issues

If Athena query times out:

```
ERROR   Athena query a123b456 did not complete in 300s
ERROR   [METRIC] athena_query_timeout=300
ERROR   ✗ FAILED wait_for_query (300123.4ms): Athena query...
```

Clear indication of:
- What operation failed
- How long it took
- Exact timeout threshold

---

## Metrics Reference

### Handler (`index.py`)
| Metric | Type | Values |
|--------|------|--------|
| `input_parsed` | bool | `true` |
| `akamai_data_retrieved` | int | Count of records |
| `validation_passed` | bool | `true`/`false` |
| `result_persisted` | bool | `true` |

### Input Parsing (`input.py`)
| Metric | Type | Values |
|--------|------|--------|
| `identifier` | str | AppCI ID |
| `control` | str | Control name |

### Data Retrieval (`data.py`)
| Metric | Type | Values |
|--------|------|--------|
| `athena_records_retrieved` | int | Total query results |
| `records_evaluated` | int | After filtering |
| `records_passed` | int | Compliance met |
| `records_failed` | int | Compliance not met |
| `records_special_pass` | int | Excluded cases |
| `compliance_status` | str | `PASS`/`FAIL` |

### Validation (`validate.py`)
| Metric | Type | Values |
|--------|------|--------|
| `criteria` | str | `['akamai']` etc |
| `akamai_data_items` | int | Data list length |
| `validation_result` | str | `PASS`/`FAIL` |

### Result & Persistence (`output.py`)
| Metric | Type | Values |
|--------|------|--------|
| `result_status` | str | `PASS`/`FAIL` |
| `evidence_truncated` | bool | Char limit exceeded? |
| `dynamodb_write_success` | bool | Write succeeded? |
| `dynamodb_write_error` | bool | Write failed? |

### AWS Operations (`helpers.py`)
| Metric | Type | Values |
|--------|------|--------|
| `ssm_parameter_retrieved` | str | Param name |
| `athena_query_started` | str | Query ID |
| `athena_query_completed` | str | `SUCCESS` |
| `athena_query_failed` | str | Error reason |
| `athena_query_timeout` | int | Timeout seconds |
| `athena_results_fetched` | int | Row count |

---

## Debugging Workflow

### Issue: "Why did validation fail?"

**Look for:** `records_passed`, `records_failed`, `compliance_status`

```
[METRIC] records_passed=0 records
[METRIC] records_failed=15 records
[METRIC] compliance_status=FAIL
```

→ All records had onboarding/coverage mismatch

---

### Issue: "Why is the Lambda slow?"

**Look for:** Function durations in logs

```
← END wait_for_query (2341.5ms)    ← Athena took 2.3 seconds
← END execute_athena_query (45.3ms)
← END handler (2695.1ms)           ← Total invocation
```

→ Athena query dominates execution time (expected for data operations)

---

### Issue: "How many records did Athena return?"

**Look for:** `athena_records_retrieved`, `records_evaluated`, `records_special_pass`

```
[METRIC] athena_records_retrieved=20 records
[METRIC] records_special_pass=5 records
[METRIC] records_evaluated=15 records
```

→ Athena returned 20 records, 5 excluded as special cases, 15 evaluated

---

### Issue: "Did DynamoDB write succeed?"

**Look for:** `dynamodb_write_success` or `dynamodb_write_error`

```
[METRIC] dynamodb_write_success=True
```

→ Result persisted successfully

---

## Integration with Existing Code

✅ **Fully backwards compatible**
- Old imports still work: `from logger import logger`
- All existing code runs unchanged
- Debugger is additive, not breaking

✅ **No external dependencies added**
- Uses AWS Lambda PowerTools (already in requirements)
- Pure Python stdlib for timing/tracing
- No new package installs needed

✅ **Easy to extend**
- Add new metrics: `log_metric("my_metric", value)`
- Wrap new functions: `@debug_trace("function_name")`
- Metrics automatically appear in execution summary

---

## File Changes Summary

| File | Changes | Lines |
|------|---------|-------|
| `debugger.py` | **NEW** | 150+ |
| `index.py` | Enhanced | +15 |
| `input.py` | Enhanced | +20 |
| `data.py` | Enhanced | +40 |
| `validate.py` | Enhanced | +10 |
| `output.py` | Enhanced | +50 |
| `helpers.py` | Enhanced | +35 |
| `logger.py` | Updated | -1 (refactored) |

**Total additions:** ~130 lines of debug/metric code + 15 lines of comments per file

---

## Next Steps

1. **Deploy updated code** to Lambda
2. **Invoke with test event** — view CloudWatch logs
3. **Check execution summary** — shows all metrics in one place
4. **Set up CloudWatch alarms** on key metrics:
   - `validation_result == FAIL`
   - `records_failed > 0`
   - `athena_query_timeout`
   - Handler duration > 5000ms

5. **Optional: Parse metrics for dashboards**
   - Extract JSON from `EXECUTION SUMMARY`
   - Feed to CloudWatch custom metrics
   - Create dashboard showing pass/fail rates

---

## Questions?

- **Where are logs?** → CloudWatch Logs for your Lambda function
- **How to disable?** → Set `_debug_context.enabled = False` (not recommended)
- **How to add more metrics?** → Call `log_metric("name", value)` anywhere
- **Performance impact?** → < 1ms per function + minimal logging overhead


# UCAS Debugger — Deployment Checklist

## Pre-Deployment

- [ ] Backup current Lambda code
  ```bash
  aws lambda get-function --function-name akamaivalidator \
    --query 'Code.Location' --output text | xargs wget -O backup.zip
  ```

- [ ] Review all updated files (8 files total)
  - [ ] `debugger.py` (NEW)
  - [ ] `index.py` (UPDATED)
  - [ ] `input.py` (UPDATED)
  - [ ] `data.py` (UPDATED)
  - [ ] `validate.py` (UPDATED)
  - [ ] `output.py` (UPDATED)
  - [ ] `helpers.py` (UPDATED)
  - [ ] `logger.py` (UPDATED)

- [ ] Read documentation (10 min)
  - [ ] IMPLEMENTATION_SUMMARY.md
  - [ ] UCAS_DEBUGGER_README.md

---

## Deployment

### Option 1: AWS Console

- [ ] Go to Lambda → Functions → akamaivalidator
- [ ] Click "Upload from" → .zip file
- [ ] Select akamaivalidator.zip with all files
- [ ] Click "Deploy"
- [ ] Handler is still `index.handler` ✓

### Option 2: AWS CLI

- [ ] Create deployment zip:
  ```bash
  cd /path/to/files
  zip -r akamaivalidator.zip *
  ```

- [ ] Upload to Lambda:
  ```bash
  aws lambda update-function-code \
    --function-name akamaivalidator \
    --zip-file fileb://akamaivalidator.zip
  ```

- [ ] Verify:
  ```bash
  aws lambda get-function --function-name akamaivalidator
  ```

### Option 3: Infrastructure as Code (SAM/CloudFormation)

- [ ] Update template with new code location
- [ ] Deploy: `sam deploy` or `aws cloudformation deploy`
- [ ] Verify deployment completed

---

## Post-Deployment Verification

### Step 1: Basic Function Test (5 min)

- [ ] Invoke with test event:
  ```bash
  aws lambda invoke \
    --function-name akamaivalidator \
    --payload '{
      "identifier": "TEST_APP",
      "control": "SEC-123",
      "validator": {
        "type": "akamai",
        "criteria": ["akamai"]
      }
    }' \
    response.json
  ```

- [ ] Check response file:
  ```bash
  cat response.json
  ```

- [ ] Should see valid validation result (PASS or FAIL)

### Step 2: CloudWatch Logs Review (10 min)

- [ ] Open CloudWatch console
- [ ] Navigate to Log Groups → `/aws/lambda/akamaivalidator`
- [ ] Look for latest log stream
- [ ] Verify you see:
  - [ ] `→ START handler`
  - [ ] `[METRIC]` lines (count how many)
  - [ ] `← END handler (XXXms)`
  - [ ] `═══ EXECUTION SUMMARY ═══`
  - [ ] JSON metrics output

### Step 3: Detailed Log Analysis (5 min)

Check for these patterns:

- [ ] Function entry/exit markers:
  ```
  → START extract_lambda_input
  ← END extract_lambda_input (1.2ms)
  ```

- [ ] Metric logs:
  ```
  [METRIC] identifier=TEST_APP
  [METRIC] records_passed=12 records
  ```

- [ ] Execution summary:
  ```
  Duration: 2694.7ms
  Metrics collected: 18
  Trace events: 24
  ```

### Step 4: Error Handling Test (5 min)

Test error scenarios:

- [ ] Invalid input (missing identifier):
  ```bash
  aws lambda invoke \
    --function-name akamaivalidator \
    --payload '{"control":"SEC-123"}' \
    response.json
  ```
  - Should see: `✗ FAILED extract_lambda_input`

- [ ] Check CloudWatch for error logs
  - Should see error message in logs

---

## Expected Behavior

### Successful Invocation
```
✓ Function returns validation result (dict)
✓ CloudWatch shows ~20-30 log lines
✓ Execution summary at bottom
✓ Total duration typically 2.5-5 seconds
```

### Metrics You Should See
```
[METRIC] identifier=...
[METRIC] records_passed=...
[METRIC] records_failed=...
[METRIC] validation_result=PASS/FAIL
[METRIC] dynamodb_write_success=True
```

---

## Monitoring Setup (Optional but Recommended)

### CloudWatch Dashboard

- [ ] Create new dashboard: `AkamaiValidatorMetrics`
- [ ] Add widgets for:
  - [ ] Lambda Duration (avg, max)
  - [ ] Lambda Errors (count)
  - [ ] Lambda Invocations (count)

### CloudWatch Alarms

- [ ] Create alarm for errors:
  ```bash
  aws cloudwatch put-metric-alarm \
    --alarm-name akamaivalidator-errors \
    --metric-name Errors \
    --namespace AWS/Lambda \
    --statistic Sum \
    --period 300 \
    --threshold 5 \
    --comparison-operator GreaterThanThreshold
  ```

- [ ] Create alarm for slow execution:
  ```bash
  aws cloudwatch put-metric-alarm \
    --alarm-name akamaivalidator-slow \
    --metric-name Duration \
    --namespace AWS/Lambda \
    --statistic Average \
    --period 300 \
    --threshold 10000 \
    --comparison-operator GreaterThanThreshold
  ```

- [ ] Test alarms with manual invocation

---

## Rollback Plan

If issues occur:

- [ ] Stop processing new events
  - Disable SNS/SQS trigger if needed

- [ ] Restore backup:
  ```bash
  aws lambda update-function-code \
    --function-name akamaivalidator \
    --zip-file fileb://backup.zip
  ```

- [ ] Test rollback version
  ```bash
  aws lambda invoke \
    --function-name akamaivalidator \
    --payload '{"identifier":"TEST",...}' \
    response.json
  ```

- [ ] Verify old logs appear in CloudWatch

- [ ] Re-enable triggers once confirmed

---

## Sign-Off Checklist

### Development/QA

- [ ] Reviewed all code changes
- [ ] Verified no breaking changes
- [ ] Tested locally (if applicable)
- [ ] Confirmed requirements.txt unchanged
- [ ] Noted backward compatibility

### Deployment

- [ ] Backed up production code
- [ ] Deployed to [environment]
- [ ] Verified handler is `index.handler`
- [ ] Handler executes without syntax errors

### Validation

- [ ] Test invocation succeeded
- [ ] CloudWatch logs show expected output
- [ ] `EXECUTION SUMMARY` present
- [ ] Metrics being logged correctly
- [ ] No unexpected errors in logs

### Monitoring

- [ ] Dashboard created (optional)
- [ ] Alarms configured (optional)
- [ ] Team notified of changes
- [ ] Runbooks updated if needed

### Documentation

- [ ] Team read implementation summary
- [ ] Team knows where to find metrics
- [ ] Team knows how to debug issues
- [ ] Escalation path defined

---

## Troubleshooting

### Problem: "Module 'debugger' not found"

**Solution:**
- [ ] Verify `debugger.py` is in zip file
- [ ] Check Lambda function code size
- [ ] Redeploy with `debugger.py` included

### Problem: "No metrics in logs"

**Solution:**
- [ ] Check `init_debug_context()` called at handler start
- [ ] Verify `@debug_trace()` decorator on functions
- [ ] Check log group name: `/aws/lambda/akamaivalidator`
- [ ] Check Lambda execution role permissions

### Problem: "Logs show old messages"

**Solution:**
- [ ] CloudWatch shows cached logs sometimes
- [ ] Wait 1-2 minutes and refresh
- [ ] Filter by request ID to find specific invocation
- [ ] Check timestamp to verify it's new logs

### Problem: "Performance degradation"

**Solution:**
- [ ] Check Athena query times (most common cause)
- [ ] Look at `← END wait_for_query` duration
- [ ] Check DynamoDB write times
- [ ] Debugger overhead is < 1ms

### Problem: "Validation result changed"

**Solution:**
- [ ] Check if Athena data changed
- [ ] Look at `records_passed` vs `records_failed` metrics
- [ ] Check if special cases are being excluded differently
- [ ] Compare with previous runs' metrics

---

## Go/No-Go Decision

### Go if:
- [ ] All verification steps passed
- [ ] Logs show expected output
- [ ] Metrics appearing correctly
- [ ] No breaking errors in logs
- [ ] Response format unchanged
- [ ] DynamoDB writes succeeding

### No-Go if:
- [ ] Module not found errors
- [ ] Handler failing to execute
- [ ] Metrics not being logged
- [ ] Response format changed
- [ ] DynamoDB write failures
- [ ] Performance degradation > 20%

---

## Communication Template

### Pre-Deployment Notification

Subject: **Upcoming: UCAS Debugger Update — akamaivalidator Lambda**

```
Team,

We're deploying an enhancement to the akamaivalidator Lambda function 
that adds comprehensive debugging and metrics logging.

Changes:
- Enhanced logging with function tracing (→ START / ← END)
- Automatic metrics collection (record counts, timing, etc)
- Execution summary showing all metrics
- No breaking changes, fully backwards compatible

Expected impact:
- Faster issue diagnosis
- Better visibility into Athena queries
- Cleaner CloudWatch logs with structured output
- < 2-3% performance overhead

Timeline: [DATE TIME]

Questions? See IMPLEMENTATION_SUMMARY.md
```

### Post-Deployment Notification

Subject: **Update Complete: UCAS Debugger Now Active**

```
Team,

The UCAS Debugger update has been successfully deployed!

What's new:
- All invocations now show execution summary
- Metrics logged for key operations
- Better visibility for debugging issues

How to use:
1. Check CloudWatch logs for your invocation
2. Look for [METRIC] lines showing key counts
3. See EXECUTION SUMMARY at end for all metrics

Documentation:
- IMPLEMENTATION_SUMMARY.md - Overview
- UCAS_DEBUGGER_README.md - Full details
- UCAS_DEBUGGER_QUICK_REF.md - Quick reference

Example output:
[METRIC] records_passed=12 records
[METRIC] records_failed=3 records
[METRIC] validation_result=PASS
```

---

## Follow-Up Actions

### 1 Day After Deployment
- [ ] Review logs for any unexpected errors
- [ ] Confirm metrics are being captured
- [ ] Note any performance observations

### 1 Week After Deployment
- [ ] Analyze metrics trends
- [ ] Check if anyone found debugging helpful
- [ ] Document common issues and solutions
- [ ] Update runbooks with new metrics

### Ongoing
- [ ] Monitor for any anomalies
- [ ] Use metrics for capacity planning
- [ ] Share debugging wins with team
- [ ] Iterate on metrics if needed

---

## Notes

```
_______________________________________________
|                                             |
| Deployment Date: ______________             |
| Deployed By: ___________________            |
| Approval: _____________________             |
| Issues: ________________________             |
| Comments: ______________________            |
|                                             |
|_____________________________________________|
```

---

**Status: Ready for Deployment ✓**

All files prepared and tested. Ready to enhance your Lambda debugging! 🚀


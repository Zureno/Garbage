# UCAS Debugger — Quick Reference

## What Was Added

### ✅ Function-Level Tracing
Every function now logs entry and exit with timing:
```
→ START get_akamai_onboarding_compliance
← END get_akamai_onboarding_compliance (2341.5ms)
```

Exceptions log as:
```
✗ FAILED validate_akamai (1.2ms): ValueError: invalid criteria
```

### ✅ Key Metrics Collection
Each function logs important counts and results:

**Data collection metrics:**
```
[METRIC] athena_records_retrieved=20 records
[METRIC] records_passed=12 records
[METRIC] records_failed=3 records
[METRIC] records_special_pass=5 records
```

**Validation metrics:**
```
[METRIC] validation_result=PASS
[METRIC] compliance_status=PASS
```

**Performance metrics:**
```
[METRIC] athena_query_timeout=300
← END handler (2695.1ms)
```

### ✅ Execution Summary
At the end of every invocation, you get:
```
═══ EXECUTION SUMMARY ═══
Duration: 2694.7ms
Metrics collected: 18
Trace events: 24
Metrics: {
  "records_passed": {"value": 12, "unit": "records"},
  "records_failed": {"value": 3, "unit": "records"},
  "validation_result": {"value": "PASS", "unit": ""}
}
```

### ✅ Code Comments
All functions have short, clear comments:
```python
# Extract all relevant fields from record
onboarding_candidate = str(record.get("onboarding_candidate", "")).strip().lower()

# Evaluate each record for compliance against criteria
for record in rows:
    # Records excluded from compliance evaluation (special cases)
    if (acronym == "" or ...):
```

---

## Finding Issues Quickly

### "Records failed but I don't know why"
Look at these metrics:
- `records_passed` — How many passed
- `records_failed` — How many failed
- `records_special_pass` — How many were excluded
- Check the code comments in `data.py` for evaluation logic

### "Lambda is slow"
Look at function timings:
```
← END wait_for_query (2341.5ms)    ← Takes longest
← END execute_athena_query (45.3ms)
← END handler (2695.1ms)
```

### "Validation passed/failed unexpectedly"
Check:
- `athena_records_retrieved` — How many records returned
- `records_evaluated` — How many were actually evaluated
- `compliance_status` — Final result
- `validation_result` — Validation passed?

### "DynamoDB write failed"
Check:
- `dynamodb_write_success` — True/False
- `dynamodb_write_error` — Any error?
- Look for exception in logs

---

## Code Examples

### Using in Your Own Functions

**Add tracing to a function:**
```python
from debugger import debug_trace, log_metric

@debug_trace("my_function")
def my_function(data):
    log_metric("items_processed", len(data))
    return process(data)
```

**Manual metric logging:**
```python
from debugger import log_metric

log_metric("validation_score", 95.5)
log_metric("records_found", 42, "records")
```

**View all metrics:**
```python
from debugger import log_execution_summary

# At end of handler
log_execution_summary()
```

---

## AWS Lambda PowerTools Integration

The debugger uses AWS Lambda PowerTools Logger:
- ✅ Structured JSON output
- ✅ Automatic CloudWatch correlation
- ✅ No additional dependencies
- ✅ Works with Lambda Insights

All logs automatically include:
- Timestamp
- Log level (INFO, ERROR, etc)
- Request ID (for Lambda tracing)
- Service name (akamaivalidator-lambda)

---

## Metrics By File

### index.py (Handler)
- `input_parsed` — Input validation succeeded
- `akamai_data_retrieved` — Count of data items
- `validation_passed` — Validation result (bool)
- `result_persisted` — Write to DB succeeded

### input.py
- `identifier` — AppCI ID extracted
- `control` — Control name extracted

### data.py (Most detailed)
- `athena_records_retrieved` — Total rows from query
- `records_evaluated` — Rows after filtering
- `records_passed` — Passed compliance
- `records_failed` — Failed compliance
- `records_special_pass` — Excluded from evaluation
- `compliance_status` — PASS or FAIL

### validate.py
- `criteria` — Validation criteria string
- `akamai_data_items` — Input data count
- `validation_result` — PASS or FAIL

### output.py
- `result_status` — PASS or FAIL
- `evidence_truncated` — Was 4000-char limit hit?
- `dynamodb_write_success` — Write succeeded?
- `dynamodb_write_error` — Write error occurred?

### helpers.py
- `ssm_parameter_retrieved` — Parameter name fetched
- `athena_query_started` — Query ID
- `athena_query_completed` — SUCCESS
- `athena_results_fetched` — Row count from results

---

## CloudWatch Log Queries

### Find all failed validations
```
fields @timestamp, @message
| filter @message like /validation_result=FAIL/
```

### Find slow Athena queries
```
fields @timestamp, @duration
| filter @message like /← END wait_for_query/
| stats max(@duration), avg(@duration)
```

### Get record counts for AppCI
```
fields @timestamp, @message
| filter identifier = "BFM"
| filter @message like /\[METRIC\]/
```

### Find execution summary data
```
fields @message
| filter @message like /═══ EXECUTION SUMMARY/
```

---

## Environment Setup

**No new dependencies required!**

Requirements already include:
```
boto3
aws-lambda-powertools
```

Just deploy the updated files:
- `debugger.py` ← **NEW**
- `index.py` ← Updated
- `input.py` ← Updated
- `data.py` ← Updated
- `validate.py` ← Updated
- `output.py` ← Updated
- `helpers.py` ← Updated
- `logger.py` ← Updated (small change)

---

## Backwards Compatibility

✅ All existing code works unchanged
- `from logger import logger` still works
- Old `logger.info()`, `logger.error()` unchanged
- No breaking changes

✅ Debugger is purely additive
- Can be disabled: set `enabled = False` on context
- Can ignore metrics if not useful
- Focus on what matters to you

---

## Support

### Help! I see an error in the logs

1. **Check function timing** — Did it take too long?
2. **Check metrics** — Do the numbers make sense?
3. **Check comments** — Does the code match what you expected?
4. **Check exceptions** — Look for `✗ FAILED` entries

Example error trace:
```
✗ FAILED wait_for_query (300123.4ms): TimeoutError: Athena query did not complete in 300s
```
→ Athena query took > 5 minutes, hit timeout

### Help! Metrics are missing

Make sure:
1. You called `init_debug_context()` at handler start
2. Function has `@debug_trace()` decorator
3. You called `log_metric()` where expected
4. `log_execution_summary()` is called at end

---

## Dashboard Ideas

### CloudWatch Dashboard
```
- Widgets showing:
  - Pass/Fail rate (validation_result = PASS/FAIL)
  - Average Athena query time (← END wait_for_query)
  - Record evaluation distribution (records_passed vs records_failed)
  - Error rate (✗ FAILED count)
```

### DataDog / Splunk
```
- Parse JSON from execution summary
- Track metrics over time
- Alert on:
  - validation_result = FAIL (unexpected)
  - athena_query_timeout (data issue?)
  - handler duration > 5 seconds (performance)
```

---

## See It In Action

Invoke Lambda with test event:
```json
{
  "identifier": "BFM",
  "control": "CDR-NSS3.4.2 - App01",
  "validator": {
    "type": "akamai",
    "criteria": ["akamai"]
  }
}
```

CloudWatch logs will show:
```
→ START handler
→ START extract_lambda_input
[METRIC] identifier=BFM
← END extract_lambda_input (1.2ms)
...
═══ EXECUTION SUMMARY ═══
Duration: 2694.7ms
Metrics collected: 18
```

All metrics available in CloudWatch for querying/alerting!


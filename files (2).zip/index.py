import json
from debugger import logger, debug_trace, log_metric, log_execution_summary, init_debug_context
from input import extract_lambda_input
from data import get_akamai_onboarding_compliance
from validate import validate_akamai
from output import build_result, write_result


@debug_trace("handler")
def handler(event, context):
    """
    Main Lambda handler — orchestrates the validation pipeline.
    
    Performs: Parse input → Query Athena → Validate → Build result → Write to DB
    """
    # Initialize debugger context for this invocation
    init_debug_context()
    
    try:
        # Step 1: Extract and validate input (identifier, control, validator config)
        identifier, control, validator = extract_lambda_input(event)
        log_metric("input_parsed", True)

        # Step 2: Fetch Akamai compliance data from Athena
        logger.info(f"Querying Akamai onboarding data for AppCI {identifier}")
        akamai_data = get_akamai_onboarding_compliance(identifier)
        log_metric("akamai_data_retrieved", len(akamai_data), "items")

        # Step 3: Run validation logic against collected data
        passed = validate_akamai(validator, akamai_data)
        log_metric("validation_passed", passed)

        # Step 4: Assemble standardised result structure with evidence
        result = build_result(identifier, control, validator, passed)
        logger.info(f"Result built: passed={passed}")

        # Step 5: Persist result to DynamoDB validation table
        write_result(identifier, control, validator, result)
        log_metric("result_persisted", True)

        # Log execution summary with all collected metrics
        log_execution_summary()
        
        return result

    except Exception as e:
        logger.exception(f"Akamai validator failed: {e}")
        raise


# ---------------------------------------------------------------------------
# Local testing — run directly:  python index.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    test_event = {
        "identifier": "BFM",
        "control": "CDR-NSS3.4.2 - App01",
        "validator": {
            "type": "akamai",
            "criteria": ["akamai"]
        }
    }

    result = handler(test_event, None)
    print(json.dumps(result, indent=2))

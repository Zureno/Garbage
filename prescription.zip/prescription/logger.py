from aws_lambda_powertools import Logger

# Singleton logger for prescription-lambda
logger = Logger(service="prescription-lambda")

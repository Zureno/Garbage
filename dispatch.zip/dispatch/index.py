import boto3
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError
import json
import os
from logger import logger

HEADERS = {'Content-Type': 'application/json'}

# ---------------------------------------------------------------------------
# Dispatch mode toggle: 0 = legacy SNS broadcast, 1 = SQS per-validator
# ---------------------------------------------------------------------------
DISPATCH_MODE = 1

CONFIG = {
    "ENV": "dev" # Change to local for local testing 
}

if CONFIG["ENV"] == "dev":
    REGION = os.environ['AWS_REGION']
else:
    REGION = "us-east-1"

# ---------------------------------------------------------------------------
# Validator type → SQS queue name mapping (used when DISPATCH_MODE = 1)
# ---------------------------------------------------------------------------
ENV = os.getenv("UAL_ENV", "dev").lower()

VALIDATOR_QUEUE_MAP = {
    "findings":  f"eqa-findingsvalidator-queue-{ENV}",
    "akamai":    f"eqa-akamaivalidator-queue-{ENV}",
    "pipeline":  f"eqa-pipelinevalidator-queue-{ENV}",
    "codeql":    f"eqa-codeqlalertsvalidator-queue-{ENV}",
    "onboarded": f"eqa-onboardedvalidator-queue-{ENV}",
    "ghas":      f"eqa-ghasvalidator-queue-{ENV}",
    "gitleaks":  f"eqa-gitleaksvalidator-queue-{ENV}",
    "venafi":    f"eqa-venafivalidator-queue-{ENV}",
}

def get_secret(secret_name):
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        logger.error("In get_secret function")
        raise e
    
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)


def scan_processing_table():
    """Scan the processing table for identifiers with a non-empty validation queue."""
    dynamo = boto3.resource('dynamodb')
    processing_table = dynamo.Table("eqa-cdr-processing-table")
    items = []

    response = processing_table.scan(
        ProjectionExpression="identifier, validation_queue",
        FilterExpression=Attr("validation_queue").exists() & Attr("validation_queue").ne("[]")
    )
    items.extend(response.get("Items", []))

    while "LastEvaluatedKey" in response:
        response = processing_table.scan(
            ProjectionExpression="identifier, validation_queue",
            FilterExpression=Attr("validation_queue").exists() & Attr("validation_queue").ne("[]"),
            ExclusiveStartKey=response["LastEvaluatedKey"]
        )
        items.extend(response["Items"])

    return items


def dispatch_legacy(items):
    """Mode 0: Send entire validation queue per identifier to SNS (legacy behaviour)."""
    sns = boto3.client('sns')
    service_now_secrets = get_secret("eqa-snow-secret")
    datalake_arn = service_now_secrets['datalake_topic_arn']

    for item in items:
        validation_message = {
            "identifier": item["identifier"],
            "controls": item["validation_queue"]
        }
        json_data = json.dumps({"default": json.dumps(validation_message)})
        sns.publish(
            TargetArn=datalake_arn,
            Message=json_data,
            MessageStructure='json'
        )
    logger.info(f"[Legacy] Published {len(items)} messages to SNS")


def dispatch_to_queues(items):
    """Mode 1: Decompose validation queue and route each validator to its SQS microservice queue."""
    sqs = boto3.client('sqs', region_name=REGION)

    # Resolve queue URLs once
    queue_url_cache = {}
    for v_type, queue_name in VALIDATOR_QUEUE_MAP.items():
        try:
            resp = sqs.get_queue_url(QueueName=queue_name)
            queue_url_cache[v_type] = resp['QueueUrl']
        except ClientError as e:
            logger.error(f"Could not resolve queue URL for {queue_name}: {e}")

    sent_counts = {}
    skipped_types = set()

    for item in items:
        identifier = item["identifier"]
        validation_queue = item.get("validation_queue", "[]")

        if isinstance(validation_queue, str):
            try:
                controls = json.loads(validation_queue)
            except json.JSONDecodeError:
                logger.warning(f"Skipping {identifier}: could not parse validation_queue")
                continue
        else:
            controls = validation_queue

        for control_entry in controls:
            control_name = control_entry.get("control", "")
            validators = control_entry.get("validators", [])

            for validator in validators:
                v_type = validator.get("type", "")
                queue_url = queue_url_cache.get(v_type)

                if not queue_url:
                    if v_type not in skipped_types:
                        logger.warning(f"No queue mapped for validator type '{v_type}' — skipping")
                        skipped_types.add(v_type)
                    continue

                # Findings expects validator as a list; all others as a dict
                if v_type == "findings":
                    message = {
                        "identifier": identifier,
                        "control": control_name,
                        "validator": [validator],
                    }
                else:
                    message = {
                        "identifier": identifier,
                        "control": control_name,
                        "validator": validator,
                    }

                sqs.send_message(
                    QueueUrl=queue_url,
                    MessageBody=json.dumps(message),
                )
                sent_counts[v_type] = sent_counts.get(v_type, 0) + 1

    for v_type, count in sorted(sent_counts.items()):
        logger.info(f"[SQS] Sent {count} messages to {VALIDATOR_QUEUE_MAP[v_type]}")
    logger.info(f"[SQS] Total messages sent: {sum(sent_counts.values())}")


def handler(event, context):

    logger.info("Starting dispatch lambda..")

    # Support single-identifier dispatch: pass {"identifier": "XYZ"} in the event
    # or leave it blank / empty string to process all identifiers
    target_identifier = event.get("identifier", "").strip() if isinstance(event, dict) else ""

    if target_identifier:
        logger.info(f"Dispatching for single identifier: {target_identifier}")
        items = scan_processing_table()
        items = [i for i in items if i.get("identifier") == target_identifier]
        if not items:
            logger.warning(f"No pending validation queue found for identifier: {target_identifier}")
            return
    else:
        logger.info("No identifier specified — dispatching for all identifiers")
        items = scan_processing_table()

    logger.info(f"Found {len(items)} identifiers with pending validation queues")

    if DISPATCH_MODE == 0:
        dispatch_legacy(items)
    else:
        dispatch_to_queues(items)

    logger.info(f"Dispatch complete (mode={DISPATCH_MODE})")


if __name__ == '__main__':
    handler({"identifier": "EHF"}, {})  # single
    # handler({}, {})                    # all


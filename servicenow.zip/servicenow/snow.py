import os
import json
import boto3
from botocore.exceptions import ClientError
import requests
import logging
from config import CONFIG
from helpers.filters import is_cdr
from logger import logger

HEADERS = {'Content-Type': 'application/json'}

REQUEST_TIMEOUT = 60  # seconds



if CONFIG["ENV"] == "dev":
    REGION = os.environ['AWS_REGION']
else:
    REGION = "us-east-1"
    
def get_secret(secret_name):
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=REGION
        )
        try:
            get_secret_value_response = client.get_secret_value(
                SecretId=secret_name
            )
        except ClientError as e:
            logger.error(f"Failed to retrieve secret '{secret_name}': {e}")
            raise e
        
        secret = get_secret_value_response['SecretString']
        return json.loads(secret)

class NewSnowIntegration:

    def __init__(self):
        self.service_now_secrets = get_secret("eqa-snow-secret")
        for key in ('snow_url', 'snow_user', 'snow_password'):
            if key not in self.service_now_secrets:
                logger.error(f"Missing required key '{key}' in eqa-snow-secret")
                raise ValueError(f"Missing required key '{key}' in eqa-snow-secret")
        self.snow_url = self.service_now_secrets['snow_url']
        logger.info(f"ServiceNow integration initialized for {self.snow_url}")
    
    def send_compliance_status(self, asset_id, control, indicator_id, status, evidence, raw_evidence):       
        json_data = {}
        json_data["indicator_template_id"] = indicator_id
        json_data["control_objective_reference"] = control
        json_data["asset_id"] = asset_id
        if status:
            json_data["compliance_status"] = "compliant"
        else:
            json_data["compliance_status"] = "non_compliant"

        json_data["metadata"] = raw_evidence
        json_data["value"] = evidence

        data_array = [json_data]

        url = f'{self.snow_url}/api/sn_compliance/aws_control_automation/update_external_validator_results'
        try:
            response = requests.request("POST", url, auth=(self.service_now_secrets['snow_user'], self.service_now_secrets['snow_password']), data=json.dumps(data_array), headers=HEADERS, timeout=REQUEST_TIMEOUT)
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error sending compliance status for control={control} asset={asset_id}: {e}")
            raise
        except requests.exceptions.Timeout as e:
            logger.error(f"Timeout sending compliance status for control={control} asset={asset_id}: {e}")
            raise
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error sending compliance status for control={control} asset={asset_id}: {e}")
            raise

        status_code = response.status_code
        try:
            response_body = response.json()
        except (ValueError, json.JSONDecodeError):
            response_body = response.text
        logger.debug(f"SNOW response status={status_code} body={response_body}")
        if status_code not in (200, 201):
            logger.error(f"Failed to send compliance status for control={control} asset={asset_id}: HTTP {status_code} - {response_body}")
            raise RuntimeError(f"Unable to send results to snow endpoint. Status: {status_code}")

        return

    def send_compliance_status_batch(self, payloads: list):
        """
        Send multiple compliance results in a single POST.
        Each payload dict must have: indicator_template_id, control_objective_reference,
        asset_id, compliance_status, metadata, value.
        The ServiceNow endpoint already accepts an array — this avoids one round-trip per control.
        """
        if not payloads:
            return
        url = f'{self.snow_url}/api/sn_compliance/aws_control_automation/update_external_validator_results'
        logger.info(f"Sending batch of {len(payloads)} compliance results to ServiceNow")
        try:
            response = requests.request(
                "POST", url,
                auth=(self.service_now_secrets['snow_user'], self.service_now_secrets['snow_password']),
                data=json.dumps(payloads),
                headers=HEADERS,
                timeout=REQUEST_TIMEOUT
            )
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error sending batch to ServiceNow ({len(payloads)} payloads): {e}")
            raise
        except requests.exceptions.Timeout as e:
            logger.error(f"Timeout sending batch to ServiceNow ({len(payloads)} payloads): {e}")
            raise
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error sending batch to ServiceNow ({len(payloads)} payloads): {e}")
            raise

        status_code = response.status_code
        try:
            response_body = response.json()
        except (ValueError, json.JSONDecodeError):
            response_body = response.text
        logger.debug(f"SNOW batch response status={status_code} body={response_body}")
        if status_code not in (200, 201):
            controls = [p.get('control_objective_reference', '?') for p in payloads]
            logger.error(f"Failed to send batch to ServiceNow: HTTP {status_code} - {response_body} - controls={controls}")
            raise RuntimeError(f"Unable to send batch results to snow endpoint. Status: {status_code}")
        logger.info(f"Successfully sent batch of {len(payloads)} results to ServiceNow")

    def get_template_sys_ids(self, asset):
        # gets indicators for a particular asset
        url = f'{self.snow_url}/api/sn_compliance/aws_control_automation/get_indicators_scheduled_for_today?&entity_sys_id={asset}&ci_requested_fields=u_application_key'
        try:  
            response = requests.get(url, auth=(self.service_now_secrets['snow_user'], self.service_now_secrets['snow_password']), headers=HEADERS, timeout=REQUEST_TIMEOUT)  
            status = response.status_code

            if status == 401 or status == 403:
                logger.error(f"Authentication failed fetching template sys IDs for asset={asset}: HTTP {status} - check snow_user/snow_password credentials")
                return None
            if status not in [200, 201]:  
                logger.warning(f"Unable to fetch template sys IDs for asset={asset}. Status code: {response.status_code}, Response: {response.text}")
                return None 
            else:  
                data = response.json()   
                result = data.get('result')

                if result is None:  
                    logger.info("No 'result' field found in the response.")  
                    return None  

                for item in result:
                    item.pop('urls', None)
                    item.pop('Obj',None)

                return result  

        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error fetching template sys IDs for asset={asset}: {e}")
            return None
        except requests.exceptions.Timeout as e:
            logger.error(f"Timeout fetching template sys IDs for asset={asset}: {e}")
            return None
        except Exception as e:  
            logger.error(f"Exception occurred while fetching templateSysIds for asset={asset}: {e}")  
            return None 
    def normalize_template_map(raw):
        """Make a dict: CDR-control -> template_sys_id from ServiceNow response.
        Accepts either {"result": [...]} or just plain lists of dicts.
        """
        if not raw:
            return {}
        
        if isinstance(raw, dict) and "result" in raw:
            # Unwrap if needed
            raw = raw["result"]

        mapping = {}
        if isinstance(raw, list):
            for entry in raw:
                control = (
                    entry.get("controlReference")
                    or entry.get("control") 
                    or entry.get("cdr_control")
                    or entry.get("name")
                    or entry.get("control_id")
                )
                sys_id = (
                    entry.get("sys_id") 
                    or entry.get("template_sys_id") 
                    or entry.get("id")
                )
                if is_cdr(control) and sys_id:
                    mapping[control] = sys_id
        elif isinstance(raw, dict):
            for control, sys_id in raw.items():
                if is_cdr(control) and sys_id:
                    mapping[control] = sys_id
        return mapping
    # Get indicators scheduled to be ran today, and all of their associated metadata
    def get_indicators(self, page_size=1000):
        url = f'{self.snow_url}/api/sn_compliance/aws_control_automation/get_indicators_scheduled_for_today'
        attributes = [
            "indicatorTemplateSysID",
            "entitySysID",
            "entityName",
            "entityClass",
            "controlReference"
        ]
        ci_attributes = ','.join(attributes)
        all_results = []
        page_no = 0

        while True:
            params = {
                "ci_requested_fields": ci_attributes,
                "page_no": page_no,
                "page_size": page_size
            }
            try:
                response = requests.get(
                    url,
                    auth=(self.service_now_secrets['snow_user'], self.service_now_secrets['snow_password']),
                    headers=HEADERS,
                    params=params,
                    timeout=REQUEST_TIMEOUT
                )
                status = response.status_code

                if status == 401 or status == 403:
                    logger.error(f"Authentication failed fetching indicators: HTTP {status} - check snow_user/snow_password credentials")
                    break
                if status not in [200, 201]:
                    logger.error(f"Error fetching indicators: HTTP {response.status_code}, Response: {response.text}")
                    break

                data = response.json()
                result = data.get('result', [])
                for item in result:
                    item.pop('urls', None)

                if not result:
                    logger.info(f"Page {page_no}: empty result, pagination complete")
                    break

                all_results.extend(result)
                logger.info(f"Page {page_no}: received {len(result)} indicators (running total: {len(all_results)})")
                if len(result) < page_size:
                    break
                page_no += 1
            except requests.exceptions.ConnectionError as e:
                logger.error(f"Connection error fetching indicators (page {page_no}): {e}")
                break
            except requests.exceptions.Timeout as e:
                logger.error(f"Timeout fetching indicators (page {page_no}): {e}")
                break
            except Exception as e:
                logger.error(f"Exception occurred while fetching indicators (page {page_no}): {e}")
                break

        logger.info(f"Fetched {len(all_results)} total indicators from ServiceNow")
        return all_results if all_results else None

    # def get_indicators_test(self):
    #     """Test function to get indicators without auth, for local testing with mock data"""
    #     # For local testing, return mock data
    #     return [
    #         {   "identifier": "AFN",
    #             "indicator_id": "AFN",
    #             "control": "CDR-OTSCS3.2.6 - OT01",
    #             "entitySysId": "640bc5ebdb1c7d50735a4a6c1396198e",
    #             "entityName": "OT Infra for Baggage Handling System (BHS)",
    #             "attributes":"MyApplication",
    #         },
    #         {   "identifier": "AFN",
    #             "indicator_id": "BDZ",
    #             "control": "CDR-API9.9.9",
    #             "entitySysId": "640bc5ebdb1c7d50735a4a6c1396198e",
    #             "entityName": "OT Infra for Baggage Handling System (BHS)",
    #             "attributes":"MyApplication2",
    #         }
    #     ]

if __name__ == "__main__":  
    snow = NewSnowIntegration()
    # Example of sending compliance status uncomment below for local testing
    # snow.send_compliance_status("640bc5ebdb1c7d50735a4a6c1396198e", "CDR-OTSCS3.2.6 - OT01","59c8f421878cd290a912eacd8bbb3576", True, "This is test evidence for control OWASP-V14.2.5", [])

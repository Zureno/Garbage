import json
from helpers.dynamo_ops import get_processing_item, control_exists
from helpers.filters import is_fresh
from logger import logger

def early_filter_identifier(dynamo, identifier, controls, entity_sys_id=None):
    """
    Quick pre-checks before heavy work:
    - identifier exists in the controls table
    - last_processed is fresh
    - asset entitySysID exists (from DynamoDB item or provided as fallback)
    - validation_results present and json-parsable
    Returns (ok: bool, reason: str, item: dict | None)
    """
    if controls is not None and isinstance(controls, str):
        if not control_exists(dynamo, controls):
            return (False, f"[SKIP] One or more controls do not exist in controls table: {controls}", None)
        
    item = get_processing_item(dynamo, identifier)
    if not item:
        return (False, f"[SKIP] No item found for identifier='{identifier}'", item)
    if not is_fresh(item.get("last_processed", "")):
        logger.info(f"[SKIP] Item for identifier='{identifier}' is stale")
        return (False, f"[SKIP] Item for identifier='{identifier}' is stale", item)
    asset = item.get("entitySysID") or item.get("entitySysId") or entity_sys_id
    if not asset:
        logger.info(f"[SKIP] No asset (entitySysID) for identifier='{identifier}'")
        return (False, f"[SKIP] No asset (entitySysID) for identifier='{identifier}'", item)
    # Ensure asset is available to downstream code via the item dict
    item["entitySysID"] = asset
    raw_val = item.get("validation_results", [])
    parsed = []
    if isinstance(raw_val, str):
        try:
            parsed = json.loads(raw_val)
        except Exception as e:
            return (False, f"[SKIP] Error parsing validation_results for identifier='{identifier}': {e}", item)
    elif isinstance(raw_val, list):
        parsed = raw_val
    else:
        return (False, f"[SKIP] Unexpected type for validation_results for identifier='{identifier}': {type(raw_val)}", item)
    if not parsed:
        return (False, f"[SKIP] No validation_results for identifier='{identifier}'", item)
    # Update item with parsed results for downstream use
    item["validation_results"] = parsed
    return (True, "OK", item)
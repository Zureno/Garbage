from __future__ import annotations
import json
from datetime import datetime
from typing import Any, Dict, Optional
from helpers.filters import is_fresh
from logger import logger

# Table names
PROCESSING_TABLE = "eqa-cdr-processing-table"
CONTROLS_TABLE = "eqa-control-table"

# Reads
def get_processing_item(dynamo_resource, identifier: str) -> Dict[str, Any] | None:
    """Fetch one row from the processing table by identifier."""
    table = dynamo_resource.Table(PROCESSING_TABLE)
    response = table.get_item(Key={"identifier": identifier})
    return response.get("Item")

# def list_candidate_identifiers(dynamo_resource) -> list[str]:
#     """List all identifiers from the processing table that are fresh."""
#     table = dynamo_resource.Table(PROCESSING_TABLE)
#     response = table.scan()
#     items = response.get("Items", [])
#     candidates = []
#     for item in items:
#         if item.get("enabled") is True and is_fresh(item.get("last_processed", "")):
#             candidates.append(item["identifier"])
#     return candidates

def _load_control_set(dynamo_resource) -> set[str]:
    """Load all control names from the controls table into a set for quick lookup."""
    table = dynamo_resource.Table(CONTROLS_TABLE)
    controls = set()
    response = table.scan(ProjectionExpression="#C", ExpressionAttributeNames={"#C": "control"})
    for item in response.get("Items", []):
        if isinstance(item.get("control"), str):
            controls.add(item["control"].strip())
    while "LastEvaluatedKey" in response:
        response = table.scan(
            ProjectionExpression="#C",
            ExpressionAttributeNames={"#C": "control"},
            ExclusiveStartKey=response["LastEvaluatedKey"],
        )
        for item in response.get("Items", []):
            if isinstance(item.get("control"), str):
                controls.add(item["control"].strip())
    return controls

def control_exists(dynamo_resource, controls: list[str]) -> bool:
    """return True if all controls exist in the controls table."""
    if not controls:
        logger.warning("Control_exists got empty controls list")
        return False
    valid_controls = _load_control_set(dynamo_resource)

    for control in controls:
        if not isinstance(control, str) or not control.strip():
            logger.warning(f"Control_exists: invalid type or empty value — {repr(control)} ({type(control)})")
            return False
        if control.strip() not in valid_controls:
            logger.warning(f"Control_exists: '{control.strip()}' not found in {CONTROLS_TABLE} — raw repr: {repr(control)}")
            return False
    return True


def read_control_definition(dynamo_resource, control_name: str) -> Dict[str, Any] | None:
    """
    Fetch the control definition by control name.
    Returns None if not found or on error, otherwise returns the item dict."""
    if not isinstance(control_name, str) or not control_name:
        logger.warning(f"Read_control_definition got non-string control_name: {control_name} ({type(control_name)})")
        return None
    table = dynamo_resource.Table(CONTROLS_TABLE)
    response = table.get_item(Key={"control": control_name})
    return response.get("Item")


def batch_read_control_definitions(dynamo_resource, control_names: list) -> Dict[str, Any]:
    """
    Fetch multiple control definitions in a single batch DynamoDB call.
    Returns a dict keyed by control name. Handles DynamoDB's 100-key limit per batch.
    Use this instead of calling read_control_definition in a loop.
    """
    if not control_names:
        return {}

    client = dynamo_resource.meta.client
    unique_names = list({n for n in control_names if isinstance(n, str) and n})
    result: Dict[str, Any] = {}

    for i in range(0, len(unique_names), 100):
        batch = unique_names[i:i + 100]
        request_items = {CONTROLS_TABLE: {"Keys": [{"control": name} for name in batch]}}
        try:
            response = client.batch_get_item(RequestItems=request_items)
        except Exception as e:
            logger.warning(f"batch_read_control_definitions error: {e}")
            continue

        for item in response.get("Responses", {}).get(CONTROLS_TABLE, []):
            if isinstance(item.get("control"), str):
                result[item["control"]] = item

        # Retry any unprocessed keys (DynamoDB may throttle partial batches)
        unprocessed = response.get("UnprocessedKeys", {})
        while unprocessed:
            try:
                response = client.batch_get_item(RequestItems=unprocessed)
            except Exception as e:
                logger.warning(f"batch_read_control_definitions retry error: {e}")
                break
            for item in response.get("Responses", {}).get(CONTROLS_TABLE, []):
                if isinstance(item.get("control"), str):
                    result[item["control"]] = item
            unprocessed = response.get("UnprocessedKeys", {})

    return result

# Writes
def reset_processing_item(dynamo_resource, identifier: str) -> None:
    """
    idempotent reset after successful processing:
    - set enabled to False
    - leave validation_results intact and reset validation_queue
    """
    table = dynamo_resource.Table(PROCESSING_TABLE)
    table.update_item(
        Key={"identifier": identifier},
        UpdateExpression="SET validation_queue = :queue",
        ExpressionAttributeValues={":queue": []},
    )
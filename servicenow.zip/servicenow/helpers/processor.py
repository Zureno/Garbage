from config import CONFIG
from helpers.filters import is_cdr       
from helpers.dynamo_ops import control_exists, batch_read_control_definitions, reset_processing_item 
from helpers.pipeline import early_filter_identifier
from snow import NewSnowIntegration
from logger import logger

def process_one_identifier(dynamo, snow, identifier, controls, entity_sys_id=None):
    """
    Process a single identifier: fetch validation results, filter, send to ServiceNow, and update the processing table.
    Returns a summary dict of the processing outcome.
    """

    # Early filtering based on identifier and controls returns a tuple (ok: bool, reason: str, item: dict)
    ok, reason, item = early_filter_identifier(dynamo, identifier, controls, entity_sys_id=entity_sys_id)
    if not ok:
        logger.info(f"[SKIP] {identifier}: {reason}")
        return {"identifier": identifier, "status": f"skipped_{reason}"}
    
    asset = item.get("entitySysID") or item.get("entitySysId")
    attributes = item.get("attributes")
    validation_results = item.get("validation_results", [])
    
    allowed_controls = set(ctrl.strip() for ctrl in (controls or []) if isinstance(ctrl, str))

    # --- Pre-fetch all data needed for the loop in bulk ---

    # 1. Fetch template sys IDs for this asset ONCE (previously called once per control)
    template_sys_ids = snow.get_template_sys_ids(asset)
    if not template_sys_ids:
        logger.warning(f"[SKIP] get_template_sys_ids returned no data for asset={asset} identifier={identifier}")
        reset_processing_item(dynamo, identifier)
        return {
            "identifier": identifier,
            "status": "completed",
            "sent": False,
            "indicators_sent": [],
            "indicators_skipped": [r.get("control") for r in validation_results if isinstance(r.get("control"), str)],
            "control_stats": {},
        }

    # Build a fast O(1) lookup dict: controlReference -> indicatorTemplateSysID
    template_map = {
        entry["controlReference"]: entry["indicatorTemplateSysID"]
        for entry in template_sys_ids
        if "controlReference" in entry and "indicatorTemplateSysID" in entry
    }

    # 2. Batch-fetch all control definitions in one DynamoDB call (previously one get_item per control)
    candidate_controls = [
        r.get("control") for r in validation_results
        if isinstance(r.get("control"), str) and r.get("control")
    ]
    control_defs = batch_read_control_definitions(dynamo, candidate_controls)

    all_results = []
    indicators_found = []
    indicators_not_found = []
    sent_any = False
    control_stats = {}
    batch_payloads = []  # Accumulate all payloads for a single batch POST

    for results in validation_results:
        control = results.get("control")
        passed = results.get("passed")
        avit = results.get("avit")
        evidence = results.get("evidence")
        raw = results.get("raw_evidence")

        # Further filtering non-existing controls
        if allowed_controls and control not in allowed_controls:
            continue
        if isinstance(control, dict) and "S" in control:
            control = control["S"]
        if not isinstance(control, str) or not control:
            continue
        if passed in ("SKIP_FAILURE", "SKIP_PASS"):
            continue

        # Enrich with control definition from pre-fetched batch dict
        control_def = control_defs.get(control) or {}
        description = control_def.get("description", "")
        chapter = control_def.get("chapter_name", "")
        result = {
            "control": {"S": control},
            "description": {"S": description},
            "chapter_name": {"S": chapter},
            "avit": {"S": avit},
            "indicator_id": {"S": ""},  # Updated below if template found
            "pass": {"BOOL": bool(passed)},
            "evidence": {"S": evidence},
            "raw_evidence": {"S": raw},
        }
        all_results.append(result)

        # Look up template sys ID from pre-fetched map (no HTTP call here)
        template_sys_id = template_map.get(control)
        if template_sys_id:
            logger.info(f"[SNOW SEND] asset={asset} control={control} template={template_sys_id} pass={passed}, evidence={evidence}")
            batch_payloads.append({
                "indicator_template_id": template_sys_id,
                "control_objective_reference": control,
                "asset_id": asset,
                "compliance_status": "compliant" if bool(passed) else "non_compliant",
                "metadata": str(raw),
                "value": evidence,
            })
            indicators_found.append(control)
            sent_any = True
            stats = control_stats.setdefault(control, {"passed": 0, "failed": 0})
            if bool(passed):
                stats["passed"] += 1
            else:
                stats["failed"] += 1
        else:
            indicators_not_found.append(control)

    # Send all results in a single batch POST instead of one POST per control
    if batch_payloads:
        try:
            snow.send_compliance_status_batch(batch_payloads)
        except Exception as e:
            logger.error(f"[BATCH FAIL] Failed to send {len(batch_payloads)} results to ServiceNow for identifier={identifier}: {e}")
            reset_processing_item(dynamo, identifier)
            return {
                "identifier": identifier,
                "status": "error",
                "sent": False,
                "error": str(e),
                "indicators_sent": [],
                "indicators_skipped": indicators_found + indicators_not_found,
                "control_stats": {},
            }
    else:
        logger.info(f"[{identifier}] No templates matched — nothing to send to ServiceNow")

    if indicators_not_found:
        logger.warning(f"[{identifier}] {len(indicators_not_found)} controls had no matching template in ServiceNow: {indicators_not_found}")
    logger.info(f"[{identifier}] Sent {len(indicators_found)} indicators, skipped {len(indicators_not_found)}")

    # Upsert results into results table(idempotent) and reset processing item
    reset_processing_item(dynamo, identifier)
    return {
        "identifier": identifier,
        "status": "completed",
        "sent": sent_any,
        "indicators_sent": indicators_found,
        "indicators_skipped": indicators_not_found,
        "control_stats": control_stats,
    }
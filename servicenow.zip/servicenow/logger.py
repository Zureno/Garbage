from aws_lambda_powertools import Logger

# Singleton logger for servicenow-lambda
logger = Logger(service="servicenow-lambda")

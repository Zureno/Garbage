import boto3
# import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import CONFIG
from snow import NewSnowIntegration
from helpers.processor import process_one_identifier
from helpers.entity_handling import extract_app_key_from_entity_name, get_ot_identifier

"""
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..', 'src')))
from SourceDataLayer.snow import NewSnowIntegration
"""

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    h = logging.StreamHandler()
    h.setLevel(os.getenv("LOGGING_LEVEL", logging.DEBUG))
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    h.setFormatter(formatter)
    logger.addHandler(h)

HEADERS = {"Content-Type": "application/json"}

if CONFIG["ENV"] == "dev":
    REGION = os.environ["AWS_REGION"]
else:
    REGION = "us-east-1"

# Max parallel threads for processing identifiers. Matches reservedConcurrentExecutions on the Lambda.
_MAX_WORKERS = 20


def _identifier_from_snow(indicators: list):
    """
    Build identifier->controls and identifier->asset maps from pre-fetched indicators.
    Accepts the already-fetched indicator list so get_indicators() is only called once.
    Returns a tuple of:
      - identifier_to_controls: dict mapping identifier -> set of controls
      - identifier_to_asset:    dict mapping identifier -> entitySysID
    """
    identifier_to_controls = {}
    identifier_to_asset = {}
    for ind in indicators:
        if ind.get("hasNext") is False:
            break
        entity_class = ind.get("entityClass", {}).get("displayName", "")
        entity_name = ind.get("entityName", "")
        if entity_class == "OT Infrastructure (Automation)":
            identifier = get_ot_identifier(entity_name)
        elif entity_class in ["Application", "Cloud Applications", "Non-Cloud Applications"]:
            identifier = extract_app_key_from_entity_name(entity_name)
        else:
            identifier = ""
        control = ind.get("controlReference", "").strip()
        if not identifier or not control:
            continue
        bucket = identifier_to_controls.setdefault(identifier, set())
        bucket.add(control)
        # Capture entitySysID from the indicator (first seen wins)
        if identifier not in identifier_to_asset:
            entity_sys_id = ind.get("entitySysID") or ind.get("entitySysId", "")
            if entity_sys_id:
                identifier_to_asset[identifier] = entity_sys_id
    return identifier_to_controls, identifier_to_asset


def _process_with_own_dynamo(identifier, allowed_controls, entity_sys_id, snow):
    """
    Thread worker: creates its own DynamoDB resource per thread.
    boto3 resources are not thread-safe and must not be shared across threads.
    The `snow` object is safe to share (uses requests, read-only state after init).
    """
    dynamo = boto3.resource("dynamodb")
    return process_one_identifier(dynamo, snow, identifier, allowed_controls, entity_sys_id=entity_sys_id)


def handler(event, context):
    """Main Lambda handler to process identifiers from ServiceNow."""
    try:
        snow = NewSnowIntegration()
        # Fetch indicators once — passed into _identifier_from_snow to avoid a duplicate call
        indicators = snow.get_indicators() or []
    except Exception as e:
        logger.error(f"Failed to initialize ServiceNow integration or fetch indicators: {e}")
        return {"status": "error", "error": str(e)}

    # # Dump raw indicators to JSON for debugging
    # try:
    #     dump_path = os.path.join(os.path.dirname(__file__), "indicators_dump.json")
    #     with open(dump_path, "w") as f:
    #         json.dump(indicators, f, indent=2, default=str)
    #     logger.info(f"Dumped {len(indicators)} indicators to {dump_path}")
    # except Exception as e:
    #     logger.warning(f"Failed to dump indicators to file: {e}")

    try:
        identifier_to_controls, identifier_to_asset = _identifier_from_snow(indicators)
    except Exception as e:
        logger.error(f"Failed to build identifier map from indicators: {e}")
        return {"status": "error", "error": str(e)}

    if not identifier_to_controls:
        logger.info("No identifiers found from ServiceNow indicators — nothing to process")
        return {"status": "no_identifiers", "processed": 0}

    logger.info(f"Found {len(identifier_to_controls)} identifiers to process from {len(indicators)} indicators")

    summaries = {"processed": 0, "skipped": 0, "errors": 0}
    global_control_stats = {}

    # Process all identifiers in parallel. Results are collected serially via as_completed
    # so summaries/global_control_stats are only mutated in the main thread.
    with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as executor:
        futures = {
            executor.submit(
                _process_with_own_dynamo,
                identifier, allowed_controls, identifier_to_asset.get(identifier), snow
            ): identifier
            for identifier, allowed_controls in identifier_to_controls.items()
        }
        for future in as_completed(futures):
            identifier = futures[future]
            try:
                result = future.result()
            except Exception as e:
                logger.error(f"Error processing identifier '{identifier}': {e}")
                summaries["skipped"] += 1
                summaries["errors"] += 1
                continue

            if isinstance(result, dict) and result.get("status") == "completed":
                summaries["processed"] += 1
                for ctrl, counts in result.get("control_stats", {}).items():
                    gs = global_control_stats.setdefault(ctrl, {"passed": 0, "failed": 0})
                    gs["passed"] += counts["passed"]
                    gs["failed"] += counts["failed"]
            else:
                summaries["skipped"] += 1

    logger.info("===== UDCRM Send Summary (per control) =====")
    for ctrl, counts in sorted(global_control_stats.items()):
        total = counts["passed"] + counts["failed"]
        logger.info(
            f"Control: {ctrl}\n"
            f"  Found entries: {total}\n"
            f"  Passed:        {counts['passed']}\n"
            f"  Failed:        {counts['failed']}"
        )
    logger.info("==========================================")

    return {"status": "ok", "summary": summaries}


if __name__ == "__main__":
    event = {}
    context = {}
    handler(event, context)
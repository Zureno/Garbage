from pydantic import ValidationError
from integrations.input_validation.validation_models import FindingsResponse,SbomResponse,GitHubCodeSearchResponse,TemplateUsageResponse,VersionsListResponse,ProjectDetailResponse

def validate_findings_payload(raw_payload):
    try:
        validated = FindingsResponse.model_validate(raw_payload)
        return {"ok": True, "data": validated}
    except ValidationError as e:
        return {"ok": False, "errors": e.errors()}

def validate_sbom_payload(raw_payload):
    try:
        validated = SbomResponse.model_validate(raw_payload)
        return {"ok": True, "data": validated}
    except ValidationError as e:
        return {"ok": False, "errors": e.errors()}
 
def validate_template_usage_payload(raw_payload):
    try:
        validated = TemplateUsageResponse.model_validate(raw_payload)
        return {"ok": True, "data": validated}
    except ValidationError as e:
        return {"ok": False, "errors": e.errors()}
 
def validate_versions_list_payload(raw_payload):
    try:
        validated = VersionsListResponse.model_validate(raw_payload)
        return {"ok": True, "data": validated}
    except ValidationError as e:
        return {"ok": False, "errors": e.errors()}
 
def validate_project_detail_payload(raw_payload):
    try:
        validated = ProjectDetailResponse.model_validate(raw_payload)
        return {"ok": True, "data": validated}
    except ValidationError as e:
        return {"ok": False, "errors": e.errors()}
    
def validate_github_search_payload(raw_payload):
    try:
        validated = GitHubCodeSearchResponse.model_validate(raw_payload)

        return {"ok": True, "data": validated}
    except ValidationError as e:
        return {"ok": False, "errors": e.errors()}
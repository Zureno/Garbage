import requests
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from shared.secrets_manager import get_secret
from shared.ssm import get_ssm_parameter
from integrations.input_validation.input_validation import validate_template_usage_payload,validate_project_detail_payload,validate_versions_list_payload
from logger import logger


class HarnessIntegration:

    def __init__(self):
        evidence_secrets = get_secret()
        self.api_key = evidence_secrets["HARNESS_SAT"]
        self.api_base = "https://app.harness.io"
        self.account_id = get_ssm_parameter('/eqa/udcrm-control-automation/config/harness-account-id')

    def get_headers(self):
        return {"Content-Type": "application/json", "x-api-key": self.api_key,  'Harness-Account': self.account_id}

    def query_template(self, version, template):
        request_url = f"{self.api_base}/gateway/template/api/templates/entitySetupUsage/{template}?routingId={self.account_id}&accountIdentifier={self.account_id}&searchTerm=&pageSize=1000"
        if version is not None:
            request_url = request_url + "&versionLabel={version}".format(version=version)
        try:
            result = requests.get(url=request_url,
                                headers=self.get_headers())
            raw = result.json()
            validation = validate_template_usage_payload(raw)
            if not validation["ok"]:
                return {"error": "Template-usage payload invalid", "details": validation["errors"]}
            return raw
        except requests.exceptions.HTTPError as http_err:
            return {"error": "HTTP error occurred", "details": str(http_err)}
        except ValueError:
            return {"error": "Invalid JSON returned from Harness"}
        except Exception as e:
            return {"error": "Unexpected error during request", "details": str(e)}
    
    def get_versions(self, template):
        versions = []
        request_url = f'{self.api_base}/template/api/templates/list-metadata?routingId={self.account_id}&accountIdentifier={self.account_id}&templateListType=All&size=200000&sort=name%2CASC&searchTerm={template}'
        payload = {"filterType": "Template"}
        try:
            result = requests.post(url=request_url, params=payload,
                                headers=self.get_headers())
        except requests.exceptions.HTTPError as http_err:
            return {"error": "HTTP error occurred", "details": str(http_err)}
        except ValueError:
            return {"error": "Invalid JSON returned from Harness"}
        except Exception as e:
            return {"error": "Unexpected error during request", "details": str(e)}

        raw = result.json()
        validation = validate_versions_list_payload(raw)
        if not validation["ok"]:
            return {"error": "Versions list payload invalid", "details": validation["errors"]}
        
        for item in raw['data']['content']:
            versions.append(item["versionLabel"])

        return versions
    
    def get_appci_project_tag(self, project, org):
        request_url = f'{self.api_base}/v1/orgs/{org}/projects/{project}'
        try:
            result = requests.get(url=request_url, headers=self.get_headers())
        except requests.exceptions.HTTPError as http_err:
            return {"error": "HTTP error occurred", "details": str(http_err)}
        except ValueError:
            return {"error": "Invalid JSON returned from Harness"}
        except Exception as e:
            return {"error": "Unexpected error during request", "details": str(e)}

        appci = None
        raw = result.json()
        validation = validate_project_detail_payload(raw)
        if not validation["ok"]:
            return {"error": "Project-detail payload invalid", "details": validation["errors"]}
        
        tags = raw["project"]["tags"]
        if "ApplicationCI" in tags:
            appci = tags["ApplicationCI"]
        return appci

    def _check_appci_match(self, appci, final_project, final_pipeline, final_org):
        """Check collected projects/pipelines for an AppCI match. Returns (found, raw_evidence) early."""
        found = 0
        raw_evidence = []
        appci_lower = appci.lower()

        for project in final_project:
            if project is not None and appci_lower in project.lower():
                found += 1
                return found, raw_evidence

        for pipeline in final_pipeline:
            if pipeline is not None and appci_lower in pipeline.lower():
                found += 1
                if pipeline not in raw_evidence:
                    raw_evidence.append(pipeline)
                return found, raw_evidence

        # Fallback: check project tags in parallel (most expensive — individual API call per project)
        pairs = [(p, o) for p, o in zip(final_project, final_org) if p is not None]
        if not pairs:
            return found, raw_evidence

        match_found = False

        def _check_tag(pair):
            project, org = pair
            if match_found:
                return None
            return self.get_appci_project_tag(project, org)

        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(_check_tag, pair): pair for pair in pairs}
            for future in as_completed(futures):
                tag = future.result()
                if tag == appci:
                    found += 1
                    match_found = True
                    # Cancel remaining futures
                    for f in futures:
                        f.cancel()
                    return found, raw_evidence

        return found, raw_evidence

    def validate_template_usage(self, template, appci):
        found = 0
        final_project = []
        final_pipeline = []
        final_org = []
        raw_evidence = []

        try:
            versions = self.get_versions(template)
            for version in versions:
                # try the API call; if it raises, log & skip
                try:
                    results = self.query_template(version=version, template=template)  
                except Exception as e:
                    logger.warning(f"Version {version} skipped due to error: {e}")
                    continue

                # if payload validation failed, skip this version
                if results.get("error"):
                    logger.warning(f"Version {version} returned error payload; skipping.")
                    continue

                for item in results['data']['content']:
                    referredBy = item["referredByEntity"]
                    if item["referredByEntity"]["type"] == "Template":
                        sub_results = self.query_template(referredBy["entityRef"]["versionLabel"], referredBy["entityRef"]["identifier"])
                        if sub_results.get("error"):
                            continue
                        for result in sub_results['data']['content']:
                            subReferredBy = result["referredByEntity"]
                            if subReferredBy["entityRef"]["identifier"] not in final_pipeline:
                                final_project.append(subReferredBy["entityRef"]["projectIdentifier"])
                                final_pipeline.append(subReferredBy["entityRef"]["identifier"])
                                final_org.append(subReferredBy["entityRef"]["orgIdentifier"])
                    else:
                        if referredBy["entityRef"]["identifier"] not in final_pipeline:
                            final_project.append(referredBy["entityRef"]["projectIdentifier"])
                            final_pipeline.append(referredBy["entityRef"]["identifier"])
                            final_org.append(referredBy["entityRef"]["orgIdentifier"])

                # After each version, check if we already have a match
                found, raw_evidence = self._check_appci_match(appci, final_project, final_pipeline, final_org)
                if found > 0:
                    logger.info(f"Early exit: found match for {appci} in template {template} at version {version}")
                    return found, raw_evidence

            # Final check with all collected data (covers edge case where match
            # only appears after all versions are processed)
            found, raw_evidence = self._check_appci_match(appci, final_project, final_pipeline, final_org)
        except:
            logger.warning("Could not find {appci} using the {template} template".format(appci=appci, template=template))
        return found, raw_evidence

import json
import copy
import boto3
import logging
from datetime import datetime
from botocore.exceptions import ClientError
from logger import logger
from integrations.harness import HarnessIntegration
from integrations.github import GithubIntegration

TABLE_NAME = "eqa-validation-results-table"
dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
table = dynamodb.Table(TABLE_NAME)

# ---------------------------------------------------------------------------
# Input extraction — matches validator_template pattern
# ---------------------------------------------------------------------------

def extract_lambda_input(event: dict) -> tuple[str, str, dict]:

    # format A/B: SQS or SNS-triggered
    if "Records" in event:
        try:
            record = event["Records"][0]
            if "body" in record:
                raw = record["body"]
                logger.info("Parsed SQS message body")
            else:
                raw = record["Sns"]["Message"]
                logger.info("Parsed SNS message body")
            body = json.loads(raw)
        except (KeyError, IndexError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not parse message from event: {exc}") from exc
    # format C: Direct / QA invocation
    else:
        body = event
        logger.info(f"Direct invocation body: {body}")

    identifier: str = body.get("identifier", "")
    control: str    = body.get("control", "")
    validator       = body.get("validator")

    if isinstance(validator, str):
        try:
            validator = json.loads(validator)
        except json.JSONDecodeError as exc:
            raise ValueError(f"'validator' field is not valid JSON: {exc}") from exc

    missing = [name for name, val in
               [("identifier", identifier), ("control", control), ("validator", validator)]
               if not val]
    if missing:
        raise ValueError(f"Missing required field(s) in lambda event: {missing}")

    if not isinstance(validator, dict):
        raise ValueError(f"'validator' must be a dict, got {type(validator).__name__}")

    logger.info(
        f"Input extracted — identifier: {identifier!r}, "
        f"control: {control!r}, validator type: {validator.get('type')!r}"
    )
    return identifier, control, validator

# ---------------------------------------------------------------------------
# Output builder — matches validator_template pattern exactly
# ---------------------------------------------------------------------------

def build_lambda_output(
    control:        str,
    passed:         bool,
    avit:           list,
    number:         int,
    confidence:     str,
    validations:    list,
    raw_evidence:   str,
    evidence:       str,
    finding_ids:    str,
    review_required: str,
) -> str:

    if not control or not isinstance(control, str):
        raise ValueError("Invalid control")

    def safe_str(val, default=""):
        return val if isinstance(val, str) else default

    def safe_list(val):
        return val if isinstance(val, list) else []

    cleaned_validations = [
        {
            **{k: v for k, v in v.items() if k != "_evidence_internal"},
            "status": v.get("status", "NA"),
            "criteria": v.get("criteria", []),
            "type": v.get("type", "unknown")
        }
        for v in safe_list(validations)
        if isinstance(v, dict)
    ]

    if isinstance(finding_ids, list):
        finding_ids = ", ".join(map(str, finding_ids))
    finding_ids = safe_str(finding_ids)

    LIMIT_MSG = "Size limit exceeded."
    def truncate(val, limit=4000):
        return LIMIT_MSG if isinstance(val, str) and len(val) > limit else val

    output = {
        "control":          control,
        "passed":           bool(passed),
        "avit":             safe_list(avit),
        "number":           int(number) if str(number).isdigit() else 0,
        "confidence":       confidence,
        "validations":      cleaned_validations,
        "raw_evidence":     safe_str(raw_evidence),
        "evidence":         truncate(safe_str(evidence)),
        "finding_ids":      truncate(finding_ids),
        "review_required":  review_required if review_required in ("Yes", "No") else "No"
    }

    return json.dumps(output)

# ---------------------------------------------------------------------------
# DynamoDB write — matches validator_template pattern
# ---------------------------------------------------------------------------


def build_sort_key(control: str, validator: dict) -> str:
    """Create a composite sort key: ``control#[validator-spec]``."""
    return f"{control}#[{json.dumps(validator, separators=(',', ':'), sort_keys=True)}]"

def write_validator_result(table, identifier, control_validator, result):
    try:
        current_date = datetime.now().strftime("%m/%d/%Y")
        table.update_item(
            Key={
                "identifier": identifier,
                "control#validator": control_validator
            },
            UpdateExpression="SET #res = :res, last_processed = :date",
            ExpressionAttributeNames={"#res": "result"},
            ExpressionAttributeValues={":res": result, ":date": current_date},
            ReturnValues="UPDATED_NEW"
        )
        return f"Successfully updated results for identifier {identifier}, control {control_validator}"
    except ClientError as e:
        raise ValueError(f"Error updating validator result: {e.response['Error']['Message']}")

# ---------------------------------------------------------------------------
# Pipeline Validator — mirrors process.py logic exactly
# ---------------------------------------------------------------------------

class PipelineValidator:

    def __init__(self):
        self.harness = HarnessIntegration()
        self.github = GithubIntegration()

    def validate(self, mapping: dict, identifier: str, repos: dict) -> bool:
        """
        Mirrors process.py PipelineValidator.validate():
        - tool == "harness": calls harness.validate_template_usage(criteria, appci)
        - tool == "github":  calls github.search_code(criteria, repos)
        Returns True if any results found, False otherwise.
        """
        success = False  # fail by default, prove positive
        results = 0

        try:
            for criteria in mapping.get("criteria", []):
                if mapping.get("tool") == "harness":
                    count, raw = self.harness.validate_template_usage(criteria, identifier)
                elif mapping.get("tool") == "github":
                    count, raw = self.github.search_code(criteria, repos)
                else:
                    count = 0
                results += count
                if results > 0:
                    logger.info(f"Early exit: match found for criteria '{criteria}', skipping remaining criteria")
                    break
        except Exception as error:
            logger.warning(f"In pipeline validator: {error}")
            raise SystemError("Error occurred in pipeline validator while getting templates")

        if results > 0:
            success = True

        return success

# ---------------------------------------------------------------------------
# Evidence builder 
# ---------------------------------------------------------------------------

def build_pipeline_evidence(passed: bool, criteria: list) -> str:
    """
    Mirrors process.py pipeline message builder:
    - FAIL: "Pipeline-fail: <criteria>"  (or "Pipeline-fail: This control has not been implemented yet" if no criteria)
    - PASS: "This requirement has passed; no action is required."
    """
    if passed:
        return "This requirement has passed; no action is required."
    criteria_str = ", ".join([c for c in criteria if str(c).strip()])
    if criteria_str:
        return f"Pipeline-fail: {criteria_str}"
    return "Pipeline-fail: This control has not been implemented yet"

# ---------------------------------------------------------------------------
# Lambda handler
# ---------------------------------------------------------------------------

def handler(event, context):
    try:
        logger.info(f"Event received: {event}")

        # 1. Extract input using the standard template pattern
        identifier, control, validator = extract_lambda_input(event)
        
        # 2. Fetch repos for this identifier (same as process.py:
        #    "if pipeline in validation_types: repos = github.get_repos_by_appci(identifier)")
        pipeline_validator = PipelineValidator()
        repos = pipeline_validator.github.get_repos_by_appci(identifier)

        # 3. Run validation — returns bool (same as process.py case "pipeline")
        success = pipeline_validator.validate(validator, identifier, repos)

        # 4. Build validation entry (same shape process.py builds in process_control)
        criteria = validator.get("criteria", [])
        validation_entry = copy.deepcopy(validator)
        validation_entry["identifier"] = identifier
        validation_entry["name"] = control
        validation_entry["status"] = "PASS" if success else "FAIL"

        # 5. Build evidence strings — mirrors process.py evidence logic
        evidence = build_pipeline_evidence(success, criteria)

        if success:
            raw_evidence = (
                f"Validation of requirement {control} for AppCI {identifier} has passed "
                f"because the following criteria passed: {criteria}"
            )
        else:
            raw_evidence = (
                f"Validation of requirement {control} for AppCI {identifier} has failed "
                f"because the following criteria failed: {criteria}"
            )

        # 6. Build output in the standard validator_template format
        result = build_lambda_output(
            control=control,
            passed=success,
            avit=[],            # pipeline validator never produces avits (mirrors process.py)
            number=1 if success else 0,
            confidence="",
            validations=[validation_entry],
            raw_evidence=raw_evidence,
            evidence=evidence,
            finding_ids="",     # pipeline validator never produces finding IDs
            review_required="No"
        )

        # 7. Write to DynamoDB results table (same as other standalone validators)
        sort_key = build_sort_key(control, validator)
        write_validator_result(table, identifier, sort_key, result)

        logger.info(f"Pipeline validation complete for {identifier} / {control}: passed={success}")
        return json.loads(result)

    except Exception as e:
        error_message = f"An error occurred: {str(e)}"
        logger.warning(error_message)
        return {"error": error_message, "status": "FAILED"}



#FOR TESTING PURPOSE

if __name__ == "__main__":
    import json

    control_data = {
        "identifier": "BFM",
        "control": "CDR-SSDF2.3.7",
        "validator": {
            "criteria": [
                "stgrpVeracodeCI",
                "stgrpVeracodeCD",
                "stgrpWizCustom_CD",
                "stgrpWizCustom_CI"
                ],
                "type": "pipeline",
                "tool": "harness"
        }
    }

    validator = control_data["validator"]

    event = {
        "identifier": control_data["identifier"],
        "control": control_data["control"],
        "validator": control_data["validator"]
    }

    response = handler(event, None)

    print("\n===== FINAL RESPONSE =====")
    print(json.dumps(response, indent=2))

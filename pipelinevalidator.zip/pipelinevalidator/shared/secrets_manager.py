import boto3
from botocore.exceptions import ClientError
import json
import os
from shared.config import CONFIG
from logger import logger

if CONFIG["ENV"] == "dev":
    REGION = os.environ['AWS_REGION']
else:
    REGION = "us-east-1"

def get_secret(secret_id="eqa-evidence-integrations"):
    # gets secret from aws
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_id
        )
    except ClientError as e:
        logger.warning("In get_secret function")
        raise e
    
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

def get_dtConnectionAuthToken(secret_id="DT_CONNECTION_AUTH_TOKEN"):
    # gets dynatrace secret from aws
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_id
        )
    except ClientError as e:
        logger.warning("In get_dt_connection_auth_token function")
        raise e
    
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

def get_dtConnectionBaseUrl(secret_id="DT_CONNECTION_BASE_URL"):
    # gets dynatrace secret from aws
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_id
        )
    except ClientError as e:
        logger.warning("In get_dtconnectionbaseurl function")
        raise e
    
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)
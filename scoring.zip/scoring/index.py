import os
import json
import boto3
from logger import logger

logger.info("Loading scoring Lambda...")

def scan_all(dynamo, table_name):
    items = []
    response = dynamo.scan(TableName=table_name)
    items.extend(response.get('Items', []))
    while 'LastEvaluatedKey' in response:
        response = dynamo.scan(
            TableName=table_name,
            ExclusiveStartKey=response['LastEvaluatedKey']
        )
        items.extend(response.get('Items', []))
    return items


def ingest_scores(directory):
    scores = []
    for file in os.listdir(directory):
        path = os.path.join(directory, file)
        if os.path.isfile(path) and file.endswith(".json"):
            with open(path, 'r', encoding='utf-8') as score_file:
                data = json.load(score_file)
                for entry in data:
                    control = entry.get("control")
                    if "requirements" in entry:
                        for req in entry["requirements"]:
                            scores.append({
                                "control": control,
                                "requirement": req["requirement"],
                                "score": req["score"],
                                "Impact": req.get("Impact", None)
                            })
                    else:
                        scores.append(entry)
    return scores


def score_entities(identifiers, requirements):
    grades = {}
    for attribute in identifiers:
        identifier = attribute['identifier']['S']

        validation_queue_raw = attribute['validation_queue']['S']
        if isinstance(validation_queue_raw, str):
            try:
                validation_queue = json.loads(validation_queue_raw)
            except Exception:
                validation_queue = []
        else:
            validation_queue = validation_queue_raw

        validation_results_raw = attribute.get('validation_results', {}).get('S', '[]')
        if isinstance(validation_results_raw, str):
            try:
                validation_results = json.loads(validation_results_raw)
            except Exception:
                validation_results = []
        else:
            validation_results = validation_results_raw

        controls_to_score = set()
        for item in validation_queue:
            control = item.get('control')
            if control:
                controls_to_score.add(control)

        for control in controls_to_score:
            # Score requirements by matching requirement name in validation_results['control']
            evaluated_requirements = set()
            for result in validation_results:
                control_field = result.get('control', '')
                # Extract requirement name from control field (e.g., OWASP-V1.5.2 -> V1.5.2)
                if '-' in control_field:
                    req_name = control_field.split('-')[-1]
                elif ':' in control_field:
                    req_name = control_field.split(':')[-1]
                else:
                    req_name = control_field
                evaluated_requirements.add(req_name)

            relevant_requirements = [req for req in requirements if req['control'] == control and req['requirement'] in evaluated_requirements]
            if not relevant_requirements:
                continue

            total_score = sum(req['score'] for req in relevant_requirements)
            passed_score = 0
            passed_control = 0
            failed_control = 0

            def is_passed(result):
                return result and result.get('passed', False) is True
            
            def get_evidence(result):
                return result.get("evidence")

            failed_critical = False

            for req in relevant_requirements:
                # Find result where requirement matches (regardless of control prefix)
                result = next(
                    (r for r in validation_results
                     if r.get('control', '').endswith(req['requirement']) or r.get('control', '').split('-')[-1] == req['requirement']),
                    None
                )
                if is_passed(result):
                    passed_score += req['score']
                    passed_control += 1
                else:
                    failed_control += 1
                    if req.get('Impact', '').lower() == 'critical':
                        failed_critical = True

            grade = (passed_score / total_score) * 100 if total_score else 0

            if failed_critical and grade > 79:
                grade = 79

            evidence_list = [
                f"requirement={req['requirement']},score={req['score']},Impact={req.get('Impact', None)},passed={is_passed(next((r for r in validation_results if r.get('control', '').endswith(req['requirement']) or r.get('control', '').split('-')[-1] == req['requirement']), None))},evidence={get_evidence(next((r for r in validation_results if r.get('control', '').endswith(req['requirement']) or r.get('control', '').split('-')[-1] == req['requirement']), None))}"
                for req in relevant_requirements
            ]
            raw_evidence =  "; ".join(evidence_list)
            
            grades[f"{identifier}:{control}"] = {
                "control": control,
                "passed": grade >= 80,  
                "identifier": identifier,
                "grade": grade,
                "failed_count": failed_control,
                "passed_count": passed_control,
                "scoring_metadata": raw_evidence,
                "evidence": "Please Reference UCAS Dashboard: https://turbo-adventure-n15e6lm.pages.github.io/dashboard/how_to_use/"
            }

    return grades


def filter_identifiers_with_validation_queue(identifiers):
    filtered = []
    for attribute in identifiers:
        validation_queue_attr = attribute.get('validation_queue')
        if not validation_queue_attr:
            continue
        validation_queue_raw = validation_queue_attr.get('S') if isinstance(validation_queue_attr, dict) else validation_queue_attr
        if isinstance(validation_queue_raw, str):
            try:
                validation_queue = json.loads(validation_queue_raw)
            except Exception:
                validation_queue = []
        else:
            validation_queue = validation_queue_raw
        if validation_queue:
            filtered.append(attribute)
    return filtered


def append_and_update_results(dynamo, table_name, grades):
    """
    For each identifier and control, append or update the grade result for each control in DynamoDB and update the table.
    Only the newest result for each control is kept (no duplicates).
    """
    # Group grades by identifier
    from collections import defaultdict
    grades_by_identifier = defaultdict(list)
    for key, grade_result in grades.items():
        identifier = grade_result["identifier"]
        grades_by_identifier[identifier].append(grade_result)

    for identifier, grade_results in grades_by_identifier.items():
        logger.info(f"Writing to identifier: {identifier}")
        # Fetch the current item
        response = dynamo.get_item(
            TableName=table_name,
            Key={'identifier': {'S': identifier}}
        )
        item = response.get('Item', {})
        # Get current validation_results or initialize as empty list
        current_results_raw = item.get('validation_results', {}).get('S', '[]')
        try:
            current_results = json.loads(current_results_raw)
        except Exception:
            current_results = []

        # Remove any existing results for the same controls
        new_controls = set(gr["control"] for gr in grade_results)
        filtered_results = [
            res for res in current_results
            if res.get("control") not in new_controls
        ]
        # Add the new grade results (with control names at top level)
        filtered_results.extend(grade_results)

        # Log each control and grade
        for gr in grade_results:
            logger.info(f"  Control: {gr['control']}, Grade: {gr['grade']}")

        # Update the item in DynamoDB
        dynamo.update_item(
            TableName=table_name,
            Key={'identifier': {'S': identifier}},
            UpdateExpression="SET #validation_results = :results",
            ExpressionAttributeNames={"#validation_results": "validation_results"},
            ExpressionAttributeValues={":results": {'S': json.dumps(filtered_results)}}
        )


def clean_validation_results(dynamo, table_name):
    """
    Removes any entries in 'validation_results' that have the word 'score' in any key or value.
    """
    items = scan_all(dynamo, table_name)
    for attribute in items:
        identifier = attribute['identifier']['S']
        validation_results_raw = attribute.get('validation_results', {}).get('S', '[]')
        try:
            validation_results = json.loads(validation_results_raw)
        except Exception:
            validation_results = []

        # Filter out any result where any key or value contains 'score'
        def has_score(obj):
            if isinstance(obj, dict):
                return any('score' in str(k).lower() or 'score' in str(v).lower() for k, v in obj.items())
            return False

        cleaned_results = [res for res in validation_results if not has_score(res)]

        # Only update if something was removed
        if len(cleaned_results) != len(validation_results):
            logger.info(f"Cleaning validation_results for identifier: {identifier}")
            dynamo.update_item(
                TableName=table_name,
                Key={'identifier': {'S': identifier}},
                UpdateExpression="SET #validation_results = :results",
                ExpressionAttributeNames={"#validation_results": "validation_results"},
                ExpressionAttributeValues={":results": {'S': json.dumps(cleaned_results)}}
            )


def handler(event, context):
    dynamo = boto3.client('dynamodb')
    # clean_validation_results(dynamo, 'eqa-cdr-processing-table') # Uncomment to clean old scores for manual testing
    identifiers = scan_all(dynamo, 'eqa-cdr-processing-table')
    identifiers = filter_identifiers_with_validation_queue(identifiers)
    score_folder = os.path.join(os.path.dirname(__file__), "score")
    scores = ingest_scores(score_folder)

    grades = score_entities(identifiers, scores)
    # print(json.dumps(grades, indent=2))
    append_and_update_results(dynamo, 'eqa-cdr-processing-table', grades)


if __name__ == "__main__":
    event = {}
    context = {}
    handler(event, context)
from aws_lambda_powertools import Logger
import os

# Detect environment: local vs Lambda
is_local = os.getenv('AWS_EXECUTION_ENV') is None

if is_local:
    # Suppress logger locally (UCAS handles output)
    logger = Logger(service="codeqlalertsvalidator-lambda", level="CRITICAL")
else:
    # Full logging in Lambda
    logger = Logger(service="codeqlalertsvalidator-lambda", level="INFO")

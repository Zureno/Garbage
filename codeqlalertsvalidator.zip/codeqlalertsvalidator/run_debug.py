#!/usr/bin/env python3
"""
UCAS Debug Mode Launcher
Quick way to toggle debug modes without typing environment variables.
"""

import sys
import os
import subprocess

MODES = {
    'prod': {
        'UCAS_EXECUTION_MODE': 'PRODUCTION',
    },
    'debug': {
        'UCAS_EXECUTION_MODE': 'DEBUG',
    },
    'verbose': {
        'UCAS_EXECUTION_MODE': 'VERBOSE',
        'UCAS_ENABLE_QUERY_LOGGING': 'true',
        'UCAS_ENABLE_RESPONSE_LOGGING': 'true',
        'UCAS_ENABLE_RAW_DATA_LOGGING': 'false',
    },
}

USAGE = """
Usage: python run_debug.py [MODE]

Modes:
  prod      - PRODUCTION: Minimal logging (errors only)
  debug     - DEBUG: Standard output with timing (default)
  verbose   - VERBOSE: Super detailed (queries, responses, data)

Examples:
  python run_debug.py debug
  python run_debug.py verbose
  python run_debug.py prod
"""

def run_mode(mode: str):
    """Run the validator in the specified mode."""
    if mode not in MODES:
        print(f"Unknown mode: {mode}")
        print(USAGE)
        sys.exit(1)
    
    config = MODES[mode]
    
    # Set environment variables
    for key, value in config.items():
        os.environ[key] = value
    
    print(f"Running in {mode.upper()} mode...")
    print(f"   UCAS_EXECUTION_MODE={config['UCAS_EXECUTION_MODE']}")
    if 'UCAS_ENABLE_QUERY_LOGGING' in config:
        print(f"   UCAS_ENABLE_QUERY_LOGGING={config['UCAS_ENABLE_QUERY_LOGGING']}")
    if 'UCAS_ENABLE_RESPONSE_LOGGING' in config:
        print(f"   UCAS_ENABLE_RESPONSE_LOGGING={config['UCAS_ENABLE_RESPONSE_LOGGING']}")
    print()
    
    # Run index.py
    subprocess.run([sys.executable, 'index.py'])

if __name__ == '__main__':
    if len(sys.argv) < 2:
        mode = 'debug'  # Default to debug
        print("No mode specified, using DEBUG mode")
        print()
    else:
        mode = sys.argv[1]
    
    run_mode(mode)

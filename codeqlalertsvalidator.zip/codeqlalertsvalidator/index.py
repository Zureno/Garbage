"""
index.py - CodeQL Validator with UCAS Enhanced v2.0

Lambda entry point for the standalone CodeQL Validator microservice with UCAS debugging.

Flow:
  1. input.py     - parse the Lambda event
  2. data.py      - fetch CodeQL findings from GitHub
  3. validator.py - match findings against the control criteria
  4. evidence.py  - build human-readable evidence strings
  5. output.py    - assemble result dict and write to DynamoDB

Version: 2.0 (Enhanced with UCAS execution modes, DynamoDB config, verbose logging)
"""

import os
import sys
import json
from datetime import datetime
from input     import extract_lambda_input
from data      import CodeqlData
from validator import CodeqlValidator
from evidence  import build_raw_evidence, build_evidence, build_finding_ids
from output    import build_result, build_sort_key, write_validator_result
from logger    import logger
import boto3

# Import UCAS Debugger
from ucas_debugger import UCASDebugger

# Initialize UCAS with environment detection and validator name
is_local = os.getenv('AWS_EXECUTION_ENV') is None
ucas = UCASDebugger(
    logger,
    colored_output=is_local,
    validator_name='codeqlalertsvalidator'  # For DynamoDB config lookup
)

dynamodb = boto3.client('dynamodb', region_name="us-east-1")


def handler(event: dict, context) -> dict:
    """
    CodeQL Validator Lambda with UCAS Enhanced v2.0 debugging.
    
    Supports execution modes:
    - PRODUCTION: Minimal logging (errors only)
    - DEBUG: Standard UCAS output with timing
    - VERBOSE: Super detailed (queries, responses, raw data)
    
    Toggle mode via DynamoDB (no code changes needed!)
    """
    # Get actual Lambda request ID
    request_id = getattr(context, 'aws_request_id', 'local') if context else 'local'
    ucas.method_start("handler", request_id=request_id)
    
    try:
        logger.info(f"Event received: {event}")

        # ------------------------------------------------------------------
        # 1. Parse input
        # ------------------------------------------------------------------
        ucas.method_start("extract_lambda_input")
        try:
            identifier, control, validator = extract_lambda_input(event)
            
            # VERBOSE: Log raw event data
            ucas.log_raw_data("extract_lambda_input", event, "Raw Event")
            
            ucas.method_stop("extract_lambda_input", 
                           identifier=identifier, 
                           control=control[:30] if len(control) > 30 else control,
                           validator_type=validator.get('type', 'unknown'))
        except ValueError as exc:
            ucas.method_stop("extract_lambda_input", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            logger.error(f"Input parsing failed: {exc}")
            ucas.method_stop("handler", final_status="ERROR", error_type="ValueError")
            return {"error": str(exc), "status": "FAILED"}

        # ------------------------------------------------------------------
        # 2. Fetch CodeQL findings from GitHub
        # ------------------------------------------------------------------
        logger.info(f"Fetching CodeQL findings for {identifier}")
        
        ucas.method_start("get_codeql_findings", identifier=identifier)
        try:
            # VERBOSE: Log the GitHub API request (conceptual - would need data.py modification)
            github_request = {
                'organization': 'your-org',
                'repository': identifier,
                'endpoint': '/code-scanning/alerts'
            }
            ucas.log_query("get_codeql_findings", 
                          json.dumps(github_request, indent=2), 
                          "GitHub API Request")
            
            # Execute query
            findings = CodeqlData().get_codeql_findings(identifier)
            
            # VERBOSE: Log the actual response
            ucas.log_response("get_codeql_findings", findings, "GitHub API Response")
            
            # VERBOSE: Log raw data structure
            if findings:
                ucas.log_raw_data("get_codeql_findings", 
                                findings[0] if len(findings) > 0 else {}, 
                                "First Finding")
            
            ucas.method_stop("get_codeql_findings", 
                           finding_count=len(findings) if findings else 0)
        except Exception as exc:
            ucas.method_stop("get_codeql_findings", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            logger.error(f"Data fetch failed: {exc}")
            ucas.method_stop("handler", final_status="ERROR", error_type=type(exc).__name__)
            return {"error": str(exc), "status": "FAILED"}

        # ------------------------------------------------------------------
        # 3. Run validation
        # ------------------------------------------------------------------
        ucas.method_start("validate", 
                         validator_type=validator.get('type'),
                         criteria_count=len(validator.get('criteria', [])))
        try:
            # VERBOSE: Log validation criteria
            ucas.log_raw_data("validate", validator, "Validator Config")
            
            success, avits, exception, evidence_internal = CodeqlValidator().validate(
                validator, findings
            )
            
            validation_result = "EXCEPTION" if exception else ("PASS" if success else "FAIL")
            
            # VERBOSE: Log validation details
            validation_details = {
                'criteria': validator.get('criteria', []),
                'findings_count': len(findings) if findings else 0,
                'matched_avits': len(avits) if avits else 0,
                'result': validation_result
            }
            ucas.log_raw_data("validate", validation_details, "Validation Details")
            
            ucas.method_stop("validate", 
                           validation_result=validation_result,
                           avit_count=len(avits) if avits else 0,
                           exception_occurred=exception)
        except Exception as exc:
            ucas.method_stop("validate", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            logger.error(f"Validation failed: {exc}")
            ucas.method_stop("handler", final_status="ERROR", error_type=type(exc).__name__)
            return {"error": str(exc), "status": "FAILED"}

        # ------------------------------------------------------------------
        # 4. Determine pass/fail status and confidence
        # ------------------------------------------------------------------
        if exception:
            status_str = "NA"
            passed     = False
        elif success is True:
            status_str = "PASS"
            passed     = True
        else:
            status_str = "FAIL"
            passed     = False

        # Build the single validation entry
        validation_entry = {
            "type":               validator.get("type", "codeql"),
            "scope":              validator.get("scope", ""),
            "criteria":           validator.get("criteria", []),
            "identifier":         identifier,
            "name":               control,
            "status":             status_str,
            "_evidence_internal": evidence_internal,
        }

        validations = [validation_entry]

        # ------------------------------------------------------------------
        # 5. Build evidence strings
        # ------------------------------------------------------------------
        ucas.method_start("build_evidence", control=control[:30] if len(control) > 30 else control)
        try:
            raw_evidence = build_raw_evidence(control, identifier, passed, validations)
            evidence_msg = build_evidence(validation_entry)
            finding_ids  = build_finding_ids(evidence_internal)
            
            # VERBOSE: Log evidence details
            evidence_details = {
                'raw_evidence': raw_evidence[:200] if raw_evidence else '',
                'evidence_message': evidence_msg[:200] if evidence_msg else '',
                'finding_ids': finding_ids
            }
            ucas.log_raw_data("build_evidence", evidence_details, "Evidence Summary")
            
            ucas.method_stop("build_evidence", 
                           finding_id_count=len(finding_ids) if finding_ids else 0,
                           evidence_length=len(evidence_msg) if evidence_msg else 0)
        except Exception as exc:
            ucas.method_stop("build_evidence", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            raise

        # ------------------------------------------------------------------
        # 6. Get control configuration from DynamoDB
        # ------------------------------------------------------------------
        ucas.method_start("get_control_config", control=control[:30] if len(control) > 30 else control)
        try:
            # VERBOSE: Log DynamoDB query
            dynamodb_query = {
                'table': 'eqa-control-table',
                'key': {'control': control}
            }
            ucas.log_query("get_control_config", 
                          json.dumps(dynamodb_query, indent=2), 
                          "DynamoDB GetItem")
            
            response = dynamodb.get_item(
                TableName='eqa-control-table',
                Key={'control': {'S': control}}
            )
            
            # VERBOSE: Log DynamoDB response
            ucas.log_response("get_control_config", 
                            response.get('Item', {}), 
                            "DynamoDB Item")
            
            skip_failure = response['Item'].get('skip_failure', {}).get('BOOL', False)
            skip_pass    = response['Item'].get('skip_pass',    {}).get('BOOL', False)
            
            ucas.method_stop("get_control_config", 
                           skip_failure=skip_failure, 
                           skip_pass=skip_pass)
        except Exception as exc:
            ucas.method_stop("get_control_config", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            raise

        review_required = "No"
        if skip_failure and not passed:
            review_required = "Yes"
        if skip_pass and passed:
            review_required = "Yes"

        # ------------------------------------------------------------------
        # 7. Assemble result
        # ------------------------------------------------------------------
        ucas.method_start("build_result", passed=passed)
        try:
            result = build_result(
                control          = control,
                passed           = passed,
                avit             = avits,
                number           = 1 if passed else 0,
                confidence       = "",
                validations      = validations,
                raw_evidence     = raw_evidence,
                evidence         = evidence_msg,
                finding_ids      = finding_ids,
                review_required  = review_required,
            )
            
            sort_key = build_sort_key(control, validator)
            
            # VERBOSE: Log result structure
            result_summary = {
                'control': control,
                'passed': passed,
                'sort_key': sort_key,
                'result_keys': list(result.keys()) if result else []
            }
            ucas.log_raw_data("build_result", result_summary, "Result Summary")
            
            ucas.method_stop("build_result", 
                           result_size=len(str(result)),
                           sort_key=sort_key[:30] if sort_key and len(sort_key) > 30 else sort_key)
        except Exception as exc:
            ucas.method_stop("build_result", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            raise

        # ------------------------------------------------------------------
        # 8. Write to DynamoDB
        # ------------------------------------------------------------------
        ucas.method_start("write_validator_result", identifier=identifier)
        try:
            # VERBOSE: Log write details
            write_details = {
                'table': 'eqa-validation-results-table',
                'identifier': identifier,
                'sort_key': sort_key,
                'result_size': len(str(result))
            }
            ucas.log_raw_data("write_validator_result", write_details, "DynamoDB Write Details")
            
            write_validator_result(identifier, sort_key, result)
            
            ucas.method_stop("write_validator_result", status="success")
        except ValueError as exc:
            ucas.method_stop("write_validator_result", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            logger.error(f"Failed to write result: {exc}")
            ucas.method_stop("handler", final_status="ERROR", error_type="ValueError")
            return {"error": str(exc), "status": "FAILED"}
        except Exception as exc:
            ucas.method_stop("write_validator_result", 
                           error_type=type(exc).__name__, 
                           error_message=str(exc))
            raise

        logger.info(f"Validation complete — control: {control}, passed: {passed}")
        
        # Success
        ucas.method_stop("handler", 
                        final_status="PASS" if passed else "FAIL",
                        validation_passed=passed,
                        result_size=len(str(result)))
        return result

    except Exception as e:
        # Error handling
        error_type = type(e).__name__
        error_message = str(e)
        
        # Log error with UCAS
        ucas.print_error(e)
        ucas.method_stop("handler", 
                        final_status="ERROR",
                        error_type=error_type,
                        error_message=error_message)
        
        # In Lambda: raise the error
        # Locally: exit cleanly
        if is_local:
            sys.exit(1)
        else:
            raise


# ---------------------------------------------------------------------------
# Local testing — run directly:  python index.py
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    # Mock context for local testing
    class MockContext:
        aws_request_id = "local"
        function_name = "local"
    
    # Test event
    test_event = {
        "identifier": "AQQ",
        "control": "OWASP-V1.14.3",
        "validator": {
            "criteria": ["131", "119"],
            "type": "codeql",
            "scope": "rule_id"
        }
    }
    
    # Print header (only locally)
    if is_local:
        from ucas_debugger import Colors
        print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*70}{Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}  UCAS Debugger - codeqlalertsvalidator (Enhanced V2){Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Colors.END}")
        print(f"{Colors.HEADER}{Colors.BOLD}{'='*70}{Colors.END}\n")
    
    # Run handler
    try:
        result = handler(test_event, MockContext())
        
        # Print summary (only locally)
        if is_local:
            status = "PASS" if result.get('passed') else "FAIL"
            status_color = Colors.PASS if result.get('passed') else Colors.ERROR
            
            print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*70}{Colors.END}")
            print(f"{status_color}{Colors.BOLD}{status}{Colors.END} | {test_event['identifier']} | {result.get('control', 'N/A')}")
            print(f"{Colors.HEADER}{Colors.BOLD}{'='*70}{Colors.END}\n")
    
    except SystemExit:
        pass  # Clean exit on error

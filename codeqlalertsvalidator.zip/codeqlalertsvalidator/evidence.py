"""
evidence.py
Builds the human-readable evidence strings and finding_ids from
the validator result.

  build_raw_evidence  - one-line summary sentence (what passed / failed)
  build_evidence      - detailed action message for ServiceNow
  build_finding_ids   - comma-separated list of Finding URLs (truncated if needed)
"""

_SIZE_LIMIT = 4000


def build_raw_evidence(control: str, identifier: str, passed: bool, validations: list) -> str:
    """
    Build the raw_evidence summary sentence.

    Examples:
      "Validation of requirement CDR-X for AppCI BFM has passed because
       the following criteria passed: ['codeql']"
    """
    if passed:
        passed_criteria = list({
            c
            for v in validations if v.get("status") == "PASS"
            for c in v.get("criteria", [])
        })
        return (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has passed because the following criteria passed: {passed_criteria}"
        )
    else:
        failed_criteria = list({
            c
            for v in validations if v.get("status") in ("FAIL", "NA")
            for c in v.get("criteria", [])
        })
        return (
            f"Validation of requirement {control} for AppCI {identifier} "
            f"has failed because the following criteria failed: {failed_criteria}"
        )


def build_evidence(validation: dict) -> str:
    """
    Build the detailed evidence / action message for a single CodeQL validation.

    - PASS → generic pass message
    - NA   → not-implemented message
    - FAIL → lists CWE IDs and finding names with remediation instructions
    """
    status   = validation.get("status")
    internal = validation.get("_evidence_internal", {})

    if status == "PASS":
        return "This requirement has passed; no action is required."

    if status == "NA":
        return "CodeQL-fail: This control has not been implemented yet"

    # FAIL path
    if not isinstance(internal, dict):
        return ""

    cwe_details = internal.get("cwe_details", [])

    cwe_ids = sorted(
        {str(d.get("id", "")).strip() for d in cwe_details if str(d.get("id", "")).strip()},
        key=lambda x: int(x) if x.isdigit() else x,
    )
    finding_names = sorted(
        {str(d.get("description", "")).strip() for d in cwe_details if str(d.get("description", "")).strip()}
    )

    cwe_ids_str      = ", ".join(cwe_ids)
    finding_names_str = ", ".join(finding_names)

    if not cwe_ids_str and not finding_names_str:
        return ""

    msg = (
        "This requirement has failed due to CodeQL findings detected in the "
        f"following CWE(s) and Finding Name(s) combinations: "
        f"{cwe_ids_str} - {finding_names_str}. "
        "To pass this requirement, please remediate the findings in the Finding IDs column."
    )

    # Truncate if over ServiceNow limit
    if len(msg) > _SIZE_LIMIT:
        msg = msg[: _SIZE_LIMIT - 3] + "..."

    return msg


def build_finding_ids(internal: dict) -> str:
    """
    Build a sorted, comma-separated string of Finding ID URLs.
    Truncated to _SIZE_LIMIT characters if necessary.
    """
    if not isinstance(internal, dict):
        return ""

    ids = sorted({str(s).strip() for s in internal.get("FindingIDs", []) if str(s).strip()})
    result = ", ".join(ids)

    if len(result) > _SIZE_LIMIT:
        result = result[: _SIZE_LIMIT - 3] + "..."

    return result
"""Standalone onboarded-validator Lambda.

Receives an event with {identifier, control, validator} (via SNS or direct),
determines SAST/DAST scan compliance, runs the onboarded check, builds
evidence, writes results to the validation-results table, and returns
the normalised control output.
"""

import boto3
from logger import logger
from config import CONFIG
from input import extract_lambda_input
from output import build_lambda_output, build_sort_key, write_validator_result
from data import get_scannable_flags, get_scan_compliance, get_control_record
from validate import determine_skip, validate_onboarded, build_evidence
from helpers import get_control_confidence, check_snow_limit

# ---------------------------------------------------------------------------
# DynamoDB table for per-validator results
# ---------------------------------------------------------------------------
RESULTS_TABLE_NAME = "eqa-validation-results-table"
_dynamodb = boto3.resource("dynamodb")
_results_table = _dynamodb.Table(RESULTS_TABLE_NAME)


def handler(event, context):
    """Lambda entry point."""
    logger.info(f"Event received: {event}")

    # ---- 1. Parse input --------------------------------------------------
    identifier, control_name, validator = extract_lambda_input(event)

    criteria = validator.get("criteria", [])
    validator_type = validator.get("type", "onboarded")

    # ---- 2. Fetch scannable flags from processing table ------------------
    sast_scannable, dast_scannable = get_scannable_flags(identifier)
    logger.info(f"Scannable flags — sast={sast_scannable}, dast={dast_scannable}")

    # ---- 3. Determine if validation should be skipped --------------------
    skipped = determine_skip(criteria, sast_scannable, dast_scannable)

    passed = False
    status_label = "NA"

    if not skipped:
        # ---- 4. Fetch SAST / DAST compliance from Athena -----------------
        sast_compliant, dast_compliant = get_scan_compliance(
            identifier, sast_scannable, dast_scannable
        )
        logger.info(f"Compliance — sast={sast_compliant}, dast={dast_compliant}")

        # ---- 5. Run the onboarded validation -----------------------------
        passed = validate_onboarded(criteria, sast_compliant, dast_compliant)
        status_label = "PASS" if passed else "FAIL"
    else:
        logger.info("Validation skipped (tool not scannable)")

    # ---- 6. Build evidence -----------------------------------------------
    raw_evidence, evidence = build_evidence(
        control_name, identifier, criteria, passed, skipped
    )

    # ---- 7. Build the validation detail record ---------------------------
    validation_record = {
        "type": validator_type,
        "criteria": criteria,
        "identifier": identifier,
        "name": control_name,
        "status": status_label,
    }

    # ---- 8. Determine confidence (always "low" for 1 validator type) -----
    confidence = get_control_confidence(1)

    # ---- 9. Determine review_required from control table -----------------
    review_required = "No"
    control_record = get_control_record(control_name)
    if control_record:
        skip_failure = control_record.get("skip_failure", {}).get("BOOL", False)
        skip_pass = control_record.get("skip_pass", {}).get("BOOL", False)
        if skip_failure and not passed and not skipped:
            review_required = "Yes"
        if skip_pass and passed:
            review_required = "Yes"

    # ---- 10. Build normalised output -------------------------------------
    number = 1 if passed else 0
    result = build_lambda_output(
        control=control_name,
        passed=passed,
        avit=[],
        number=number,
        confidence=confidence,
        validations=[validation_record],
        raw_evidence=raw_evidence,
        evidence=evidence,
        finding_ids="",
        review_required=review_required,
    )

    # Apply ServiceNow size limit
    result = check_snow_limit(result)

    # ---- 11. Persist to DynamoDB -----------------------------------------
    sort_key = build_sort_key(control_name, validator)
    write_validator_result(_results_table, identifier, sort_key, result)

    logger.info(f"Onboarded validation complete — control={control_name}, "
                f"identifier={identifier}, passed={passed}")
    return result


# ---------------------------------------------------------------------------
# Local testing
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import json

    test_event = {
        "identifier": "RDL",
        "control": "OWASP-V10.1.1",
        "validator": {
            "type": "onboarded",
            "criteria": ["sast"]
        }
    }

    print("\n=== Test Event ===")
    print(json.dumps(test_event, indent=2))
    print("==================\n")

    result = handler(test_event, None)

    print("\n=== Result ===")
    print(json.dumps(result, indent=2))
    print("==============\n")
 
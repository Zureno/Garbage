"""Self-contained Athena data layer for SAST / DAST scan compliance.

Queries the Veracode and Netsparker shared datalake tables to determine
whether an AppCI is compliant for SAST and/or DAST scanning.  Also
provides a helper to fetch the scannable flags from the processing table.

No external dependencies beyond boto3 — SQLAlchemy is intentionally avoided
because this microservice only needs two fixed Athena queries.
"""

import os
import re
import time
from datetime import datetime, timedelta
import boto3
from logger import logger
from config import CONFIG


# ---------------------------------------------------------------------------
# Environment / region helpers
# ---------------------------------------------------------------------------

def _get_region():
    if CONFIG["ENV"] == "dev":
        return os.environ.get("AWS_REGION", "us-east-1")
    return "us-east-1"


def _get_ual_env():
    """Return the deployment environment label (e.g. 'dev', 'qa', 'prod')."""
    return os.getenv("UAL_ENV", "dev").lower()


def _get_s3_output_bucket():
    env = _get_ual_env()
    region = _get_region()
    if region == "us-east-1":
        return f"s3://eqa-udcrm-datalake-bucket-{env}"
    return f"s3://eqa-udcrm-datalake-bucket-{env}-{region}"


# ---------------------------------------------------------------------------
# Athena low-level helpers
# ---------------------------------------------------------------------------

_athena = boto3.client("athena")
_DATABASE = "appsec_database_for_datalake_shared_resources"


def _sanitize_identifier(value: str) -> str:
    """Strip everything except word characters to prevent injection in identifiers."""
    sanitized = re.sub(r"[^\w]", "", value)
    if sanitized and sanitized[0].isdigit():
        sanitized = "_" + sanitized
    return sanitized


def _execute_athena_query(sql: str, blocking: bool = False, workgroup: str = "primary") -> str:
    """Start an Athena query and return the execution ID."""
    response = _athena.start_query_execution(
        QueryString=sql,
        QueryExecutionContext={"Database": _DATABASE},
        ResultConfiguration={"OutputLocation": _get_s3_output_bucket()},
        WorkGroup=workgroup,
    )
    qid = response["QueryExecutionId"]

    if blocking:
        _wait_for_query(qid)

    return qid


def _wait_for_query(query_execution_id: str, max_wait: int = 300, poll_interval: int = 5):
    """Block until the Athena query finishes (or raise on failure / timeout)."""
    elapsed = 0
    while elapsed < max_wait:
        resp = _athena.get_query_execution(QueryExecutionId=query_execution_id)
        state = resp["QueryExecution"]["Status"]["State"]
        if state == "SUCCEEDED":
            return
        if state in ("FAILED", "CANCELLED"):
            reason = resp["QueryExecution"]["Status"].get("StateChangeReason", "Unknown")
            raise RuntimeError(f"Athena query {query_execution_id} failed: {reason}")
        time.sleep(poll_interval)
        elapsed += poll_interval
    raise TimeoutError(f"Athena query {query_execution_id} did not complete in {max_wait}s")


def _get_query_results(query_execution_id: str) -> list[dict]:
    """Paginate through Athena results and return a list of dicts."""
    results: list[dict] = []
    next_token = None
    first_page = True

    while True:
        kwargs = {"QueryExecutionId": query_execution_id}
        if next_token:
            kwargs["NextToken"] = next_token

        response = _athena.get_query_results(**kwargs)
        columns = [col["Name"] for col in response["ResultSet"]["ResultSetMetadata"]["ColumnInfo"]]

        # Skip header row on the first page
        rows = response["ResultSet"]["Rows"]
        if first_page and rows:
            rows = rows[1:]
            first_page = False

        for row in rows:
            items = [d.get("VarCharValue", "") for d in row["Data"]]
            results.append(dict(zip(columns, items)))

        next_token = response.get("NextToken")
        if not next_token:
            break

    return results


# ---------------------------------------------------------------------------
# Fixed Athena SQL queries (parameterised via identifier sanitisation)
# ---------------------------------------------------------------------------

_SAST_QUERY_TEMPLATE = """
SELECT appci, profile_name, compliant_scan, last_scan_date,
       in_veracode, operational_status, last_scan_age
FROM   veracode_sast_scan_profile_all_shared
WHERE  appci = '{appci}'
  AND  operational_status = 'Production'
  AND  last_scan_date <> 'NA'
  AND  (compliant_scan = 'Yes' OR compliant_scan = 'Scan present')
  AND  (in_veracode = 'onBoarded' OR in_veracode = 'Onboarded')
ORDER BY last_scan_date DESC
LIMIT 1
"""

_DAST_QUERY_TEMPLATE = """
SELECT appci, last_scan_date, has_compliant_scan,
       operational_status, is_onboarded
FROM   netsparker_scan_profile_shared
WHERE  appci = '{appci}'
  AND  operational_status = 'Production'
  AND  has_compliant_scan = 'true'
  AND  is_onboarded = 'true'
ORDER BY last_scan_date DESC
LIMIT 1
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_scannable_flags(identifier: str) -> tuple[bool, bool]:
    """Fetch ``sast_scannable`` and ``dast_scannable`` from the processing table.

    Returns (sast_scannable, dast_scannable) as bools.
    """
    dynamo = boto3.client("dynamodb")
    resp = dynamo.get_item(
        TableName="eqa-cdr-processing-table",
        Key={"identifier": {"S": identifier}},
    )
    item = resp.get("Item")
    if not item:
        raise ValueError(f"No item found in eqa-cdr-processing-table for identifier: {identifier}")

    sast = item.get("sast_scannable", {})
    dast = item.get("dast_scannable", {})

    # DynamoDB stores booleans under the BOOL type key
    sast_val = sast.get("BOOL", False) if isinstance(sast, dict) else bool(sast)
    dast_val = dast.get("BOOL", False) if isinstance(dast, dict) else bool(dast)
    return sast_val, dast_val


def get_scan_compliance(appci: str, sast_enabled: bool, dast_enabled: bool) -> tuple[bool, bool]:
    """Query Athena to determine SAST and DAST compliance for an AppCI.

    Returns (sast_compliant, dast_compliant).
    """
    safe_appci = _sanitize_identifier(appci)
    sast_compliant = None
    dast_compliant = None
    sast_qid = None
    dast_qid = None

    # Fire both queries in parallel (non-blocking)
    if sast_enabled:
        sql = _SAST_QUERY_TEMPLATE.format(appci=safe_appci)
        sast_qid = _execute_athena_query(sql, blocking=False)
        logger.info("SAST Athena query submitted")

    if dast_enabled:
        sql = _DAST_QUERY_TEMPLATE.format(appci=safe_appci)
        dast_qid = _execute_athena_query(sql, blocking=False)
        logger.info("DAST Athena query submitted")

    # Give Athena a head start before polling
    if sast_qid or dast_qid:
        time.sleep(30)

    # --- Evaluate SAST compliance ---
    if sast_qid:
        _wait_for_query(sast_qid)
        rows = _get_query_results(sast_qid)
        if rows:
            sast_compliant = True
            for record in rows:
                try:
                    scan_age = int(record.get("last_scan_age", 9999))
                except (ValueError, TypeError):
                    sast_compliant = None
                    break

                compliant_scan = str(record.get("compliant_scan", "")).lower()
                in_veracode = str(record.get("in_veracode", "")).lower()

                if (compliant_scan in ("scan present", "yes")
                        and in_veracode == "onboarded"
                        and scan_age <= 365):
                    sast_compliant = True
                else:
                    sast_compliant = False
                    break
        else:
            sast_compliant = False
        logger.info(f"SAST compliance for {appci}: {sast_compliant}")

    # --- Evaluate DAST compliance ---
    if dast_qid:
        _wait_for_query(dast_qid)
        rows = _get_query_results(dast_qid)
        if rows:
            latest_date_str = rows[0].get("last_scan_date", "")
            for record in rows:
                if record.get("last_scan_date") == latest_date_str and dast_compliant is not False:
                    if str(record.get("has_compliant_scan", "")).lower() == "true":
                        dast_compliant = True
                    else:
                        dast_compliant = False

            # Check 90-day freshness (skip in local/dev override)
            ual_env = _get_ual_env()
            if dast_compliant is not False and not (CONFIG.get("ENV", "").lower() == "local" and ual_env == "dev"):
                try:
                    last_scan = datetime.strptime(latest_date_str, "%Y-%m-%d").date()
                    cutoff = datetime.today().date() - timedelta(days=90)
                    dast_compliant = last_scan >= cutoff
                except ValueError:
                    logger.warning(f"Invalid DAST date format: {latest_date_str}")
                    dast_compliant = False
        else:
            dast_compliant = False
        logger.info(f"DAST compliance for {appci}: {dast_compliant}")

    return (
        sast_compliant if sast_compliant is not None else False,
        dast_compliant if dast_compliant is not None else False,
    )


def get_control_record(control_name: str) -> dict | None:
    """Look up a control from the control table to retrieve skip_failure / skip_pass flags.

    Returns the raw DynamoDB item dict, or None if not found / not enabled.
    """
    dynamo = boto3.client("dynamodb")
    resp = dynamo.scan(
        TableName="eqa-control-table",
        FilterExpression="enabled = :enabled AND control = :ctrl",
        ExpressionAttributeValues={
            ":enabled": {"BOOL": True},
            ":ctrl": {"S": control_name},
        },
    )
    items = resp.get("Items", [])
    return items[0] if items else None

"""Core validation logic, skip determination, and evidence building
for the onboarded validator.
"""

from logger import logger
from helpers import determine_skipped


# ---------------------------------------------------------------------------
# Skip logic  (ported from process.py → process_single_validation, onboarded case)
# ---------------------------------------------------------------------------

def determine_skip(criteria: list, sast_scannable: bool, dast_scannable: bool) -> bool:
    """Decide whether this onboarded validation should be skipped.

    Rules (mirror the monolith):
      * Both "sast" and "dast" in criteria → skip only if BOTH are not scannable
      * Only "sast" in criteria → skip if SAST not scannable
      * Only "dast" in criteria → skip if DAST not scannable
    """
    has_sast = "sast" in criteria
    has_dast = "dast" in criteria

    if has_sast and has_dast:
        return determine_skipped(sast_scannable) and determine_skipped(dast_scannable)
    if has_sast:
        return determine_skipped(sast_scannable)
    if has_dast:
        return determine_skipped(dast_scannable)

    # No recognised criteria → skip
    return True


# ---------------------------------------------------------------------------
# Validation  (ported from validator/onboarded_validator.py)
# ---------------------------------------------------------------------------

def validate_onboarded(criteria: list, sast_compliant: bool, dast_compliant: bool) -> bool:
    """Return True if the AppCI passes the onboarded check for the given criteria.

    Criteria may contain "sast", "dast", or both.  Passing *any* applicable
    criterion is enough (OR logic, matching the original validator).
    """
    logger.debug(f"Validating onboarded — sast_compliant={sast_compliant}, "
                 f"dast_compliant={dast_compliant}, criteria={criteria}")

    if sast_compliant and "sast" in criteria:
        return True
    if dast_compliant and "dast" in criteria:
        return True
    return False


# ---------------------------------------------------------------------------
# Evidence building  (ported from process.py → process_control)
# ---------------------------------------------------------------------------

def build_evidence(
    control_name: str,
    identifier: str,
    criteria: list,
    passed: bool,
    skipped: bool,
) -> tuple[str, str]:
    """Return ``(raw_evidence, evidence)`` strings for the control result.

    * ``raw_evidence`` — detailed machine-oriented message (goes to DynamoDB / CSV).
    * ``evidence``     — human-oriented message (goes to ServiceNow).
    """
    if skipped:
        raw_evidence = (
            f"{control_name} validation has been skipped because "
            "all control validations were skipped.  "
        )
        evidence = raw_evidence.strip()
        return raw_evidence, evidence

    if passed:
        passed_criteria = criteria
        raw_evidence = (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has passed because the following criteria passed: {passed_criteria}"
        )
        evidence = "This requirement has passed; no action is required."
    else:
        failed_criteria = criteria
        raw_evidence = (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has failed because the following criteria failed: {failed_criteria}"
        )
        # Build the specific "Onboarded-fail" message (mirrors VALIDATOR_MESSAGE_BUILDERS["onboarded"])
        criteria_str = ", ".join(c for c in criteria if str(c).strip())
        if criteria_str:
            evidence = f"Onboarded-fail: {criteria_str}"
        else:
            evidence = "Onboarded-fail: This control has not been implemented yet"

    return raw_evidence, evidence

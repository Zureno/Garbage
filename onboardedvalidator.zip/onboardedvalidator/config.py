CONFIG = {
    "ENV": "dev",       # Change to "local" for local testing
    "USE_API": False    # Change to True for Veracode API instead of Athena datalake
}

"""Standalone helper utilities for the onboarded validator lambda."""


def determine_skipped(scannable):
    """Return True if validation should be skipped because the tool is not scannable."""
    if scannable is False:
        return True
    return False


def get_control_confidence(num_validation_types):
    """Map the number of distinct validation types to a confidence label."""
    mapping = {1: "low", 2: "medium"}
    return mapping.get(num_validation_types, "high" if num_validation_types >= 3 else "NA")


def check_snow_limit(control_status):
    """Truncate raw_evidence if it exceeds the ServiceNow 4 000-char limit."""
    limit_msg = (
        "Size limit exceeded. Review output in Value field "
        "for more information about this control validation."
    )
    if "raw_evidence" in control_status:
        if len(str(control_status["raw_evidence"])) > 4000:
            control_status["raw_evidence"] = limit_msg
    return control_status

"""Build the normalised validator output and persist results to DynamoDB."""

import json
from datetime import datetime
from botocore.exceptions import ClientError
from logger import logger


# ---------------------------------------------------------------------------
# Output formatting
# ---------------------------------------------------------------------------

def build_lambda_output(
    control: str,
    passed: bool,
    avit: list,
    number: int,
    confidence: str,
    validations: list,
    raw_evidence: str,
    evidence: str,
    finding_ids: str,
    review_required: str,
) -> dict:
    """Return a normalised result dict matching the expected control output schema."""

    if not control or not isinstance(control, str):
        raise ValueError("Invalid control")

    def safe_str(val, default=""):
        return val if isinstance(val, str) else default

    def safe_list(val):
        return val if isinstance(val, list) else []

    # Clean internal fields from individual validations
    cleaned_validations = [
        {
            "type": v.get("type", "unknown"),
            "criteria": v.get("criteria", []),
            "identifier": v.get("identifier", ""),
            "name": v.get("name", ""),
            "status": v.get("status", "NA"),
        }
        for v in safe_list(validations)
        if isinstance(v, dict)
    ]

    # Normalise finding_ids to a comma-separated string
    if isinstance(finding_ids, list):
        finding_ids = ", ".join(map(str, finding_ids))
    finding_ids = safe_str(finding_ids)

    LIMIT_MSG = "Size limit exceeded."

    def truncate(val, limit=4000):
        return LIMIT_MSG if isinstance(val, str) and len(val) > limit else val

    return {
        "control": control,
        "passed": bool(passed),
        "avit": safe_list(avit),
        "number": int(number) if isinstance(number, (int, float)) else 0,
        "confidence": safe_str(confidence, "medium") or "medium",
        "validations": cleaned_validations,
        "raw_evidence": safe_str(raw_evidence),
        "evidence": truncate(safe_str(evidence)),
        "finding_ids": truncate(finding_ids),
        "review_required": review_required if review_required in ("Yes", "No") else "No",
    }


# ---------------------------------------------------------------------------
# DynamoDB sort key
# ---------------------------------------------------------------------------

def build_sort_key(control: str, validator: dict) -> str:
    """Create a composite sort key: ``control#[validator-spec]``."""
    return f"{control}#[{json.dumps(validator, separators=(',', ':'), sort_keys=True)}]"


# ---------------------------------------------------------------------------
# DynamoDB persistence
# ---------------------------------------------------------------------------

def write_validator_result(table, identifier: str, sort_key: str, result: dict):
    """Upsert a single validator result row into the validation-results table."""
    try:
        current_date = datetime.now().strftime("%m/%d/%Y")
        table.update_item(
            Key={
                "identifier": identifier,
                "control#validator": sort_key,
            },
            UpdateExpression="SET #res = :res, last_processed = :date",
            ExpressionAttributeNames={"#res": "result"},
            ExpressionAttributeValues={
                ":res": json.dumps(result),
                ":date": current_date,
            },
            ReturnValues="UPDATED_NEW",
        )
        logger.info(f"Wrote result for {identifier} / {sort_key}")
    except ClientError as e:
        error = f"Error writing validator result: {e.response['Error']['Message']}"
        raise ValueError(error)

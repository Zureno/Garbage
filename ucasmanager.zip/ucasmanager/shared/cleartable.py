import boto3


def _validate_args(args: dict):
    if not isinstance(args, dict):
        raise ValueError("args must be a dict")
    table_name = args.get("tableName")
    partition_key = args.get("partitionKey")
    sort_key = args.get("sortKey")
    if not table_name or not partition_key:
        raise ValueError("'tableName' and 'partitionKey' are required arguments")
    return table_name, partition_key, sort_key


def main(args: dict | None = None):
    if args is None:
        args = {}
    table_name, partition_key, sort_key = _validate_args(args)

    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(table_name)

    projection_keys = partition_key
    if sort_key:
        projection_keys = f"{partition_key}, #sk"

    scan_args: dict = {
        "ProjectionExpression": projection_keys,
    }

    if sort_key:
        scan_args["ExpressionAttributeNames"] = {"#sk": sort_key}

    # Optional filter controls (string expression passthrough)
    if args.get("filterExpression"):
        scan_args["FilterExpression"] = args["filterExpression"]
    if args.get("expressionAttributeNames"):
        scan_args["ExpressionAttributeNames"] = args["expressionAttributeNames"]
    if args.get("expressionAttributeValues"):
        scan_args["ExpressionAttributeValues"] = args["expressionAttributeValues"]
    if args.get("projectionExpression"):
        scan_args["ProjectionExpression"] = args["projectionExpression"]

    deleted = 0
    last_evaluated_key = None
    while True:
        if last_evaluated_key:
            scan_args["ExclusiveStartKey"] = last_evaluated_key
        resp = table.scan(**scan_args)
        items = resp.get("Items", [])
        if items:
            with table.batch_writer() as batch:
                for it in items:
                    key = {partition_key: it[partition_key]}
                    if sort_key:
                        key[sort_key] = it[sort_key]
                    batch.delete_item(Key=key)
                    deleted += 1
        last_evaluated_key = resp.get("LastEvaluatedKey")
        if not last_evaluated_key and not items:
            break

    print(f"Deleted {deleted} item(s) from '{table_name}'.")

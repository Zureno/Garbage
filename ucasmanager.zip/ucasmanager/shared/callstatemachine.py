import json
import boto3


def _resolve_from_cloudformation(export_name: str | None):
    if not export_name:
        return None
    cf = boto3.client("cloudformation")
    paginator = cf.get_paginator("list_exports")
    for page in paginator.paginate():
        for exp in page.get("Exports", []):
            name = exp.get("Name")
            if name == export_name:
                return exp.get("Value")
    return None


def _resolve_from_stepfunctions(name_substr: str | None):
    if not name_substr:
        return None
    sf = boto3.client("stepfunctions")
    paginator = sf.get_paginator("list_state_machines")
    candidates = []
    for page in paginator.paginate():
        for sm in page.get("stateMachines", []):
            name = sm.get("name", "")
            if name_substr in name:
                candidates.append(sm)
    if not candidates:
        return None
    candidates.sort(key=lambda x: x.get("creationDate"), reverse=True)
    return candidates[0].get("stateMachineArn")


def resolve_state_machine_arn(args: dict):
    # Prefer explicit CloudFormation export, fallback to name substring search
    arn = _resolve_from_cloudformation(args.get("exportName"))
    if arn:
        return arn
    arn = _resolve_from_stepfunctions(args.get("nameSubstr"))
    if arn:
        return arn
    raise RuntimeError("State Machine not found (exportName/nameSubstr).")


def _build_input(args: dict):
    # Return JSON string if input is provided; else None
    provided = args.get("input")
    if provided is None:
        return None
    return json.dumps(provided)


def main(args: dict | None = None):
    if args is None:
        args = {}
    arn = resolve_state_machine_arn(args)
    sf = boto3.client("stepfunctions")
    input_str = _build_input(args)
    if input_str is None:
        resp = sf.start_execution(stateMachineArn=arn)
    else:
        resp = sf.start_execution(stateMachineArn=arn, input=input_str)
    print(resp["executionArn"])
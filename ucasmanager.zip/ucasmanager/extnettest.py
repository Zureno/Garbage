import boto3
import requests
import json
from datetime import datetime
from botocore.exceptions import ClientError
from requests.auth import HTTPBasicAuth
from aws_lambda_powertools import Logger
import jwt
import time
import urllib.parse

# Singleton logger for extnettest
logger = Logger(service="ucasmanager-extnettest")

# JSON Logging Configuration (set to 1 to enable JSON log file output for local testing)
JSONLOG = 0
log_entries = []

# Test AppCI
TEST_APPCI = "BFM"


def log_and_collect(level, message, extra_data=None):
    """Log message and optionally collect for JSON output"""
    if level == "info":
        logger.info(message)
    elif level == "error":
        logger.error(message)
    elif level == "warning":
        logger.warning(message)
    
    if JSONLOG:
        entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "message": message
        }
        if extra_data:
            entry["data"] = extra_data
        log_entries.append(entry)


def get_secret(secret_id="eqa-evidence-integrations"):
    """Get secrets from AWS Secrets Manager"""
    logger.info(f"Retrieving secret: {secret_id}")
    try:
        region = "us-east-1"
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=region
        )
        get_secret_value_response = client.get_secret_value(SecretId=secret_id)
        secret = get_secret_value_response['SecretString']
        logger.info(f"Successfully retrieved secret: {secret_id}")
        return json.loads(secret)
    except ClientError as e:
        logger.error(f"Error retrieving secret {secret_id}: {e}")
        raise e


def get_snow_secrets():
    """Get ServiceNow secrets"""
    logger.info("Retrieving ServiceNow secrets")
    try:
        region = "us-east-1"
        secret_name = "eqa-snow-secret"
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=region
        )
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        secret = get_secret_value_response['SecretString']
        logger.info("Successfully retrieved ServiceNow secrets")
        return json.loads(secret)
    except ClientError as e:
        logger.error(f"Error retrieving ServiceNow secrets: {e}")
        raise e


def test_servicenow():
    """Test ServiceNow API"""
    log_and_collect("info", "=" * 80)
    log_and_collect("info", "TESTING SERVICENOW API")
    log_and_collect("info", "=" * 80)
    
    try:
        secrets = get_snow_secrets()
        snow_url = secrets['snow_url']
        username = secrets['snow_user']
        password = secrets['snow_password']
        
        url = f"{snow_url}/api/sn_compliance/aws_control_automation/get_entities_and_supporting_data"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        params = {"page_no": 0, "page_size": 10}  # Small page size for testing
        
        logger.info(f"About to call ServiceNow API: {url}")
        logger.info(f"Parameters: {params}")
        
        response = requests.get(
            url,
            headers=headers,
            params=params,
            auth=(username, password),
            timeout=30
        )
        
        log_and_collect("info", f"ServiceNow API Response Status: {response.status_code}", {"status_code": response.status_code})
        
        if response.status_code == 200:
            data = response.json()
            result_count = len(data.get("result", []))
            log_and_collect("info", f"✓ ServiceNow API SUCCESS - Retrieved {result_count} entities", {"result_count": result_count})
            logger.info(f"Sample response keys: {list(data.keys())}")
            if data.get("result") and len(data["result"]) > 0:
                first_item = data['result'][0]
                # Log only safe, non-sensitive fields
                safe_data = {
                    "entitySysID": first_item.get("entitySysID", "N/A"),
                    "entity_name": first_item.get("entity", {}).get("name", "N/A"),
                    "has_Obj": "Obj" in first_item
                }
                log_and_collect("info", f"First result sample fields: {json.dumps(safe_data, indent=2)}", {"sample_data": safe_data})
            return True
        else:
            log_and_collect("error", f"✗ ServiceNow API FAILED - Status: {response.status_code}", {"status_code": response.status_code})
            logger.error(f"Response: {response.text[:500]}")
            return False
            
    except Exception as e:
        log_and_collect("error", f"✗ ServiceNow API EXCEPTION: {str(e)}", {"exception": str(e)})
        return False


def test_veracode():
    """Test Veracode API (SAST)"""
    log_and_collect("info", "=" * 80)
    log_and_collect("info", "TESTING VERACODE API (SAST)")
    log_and_collect("info", "=" * 80)
    
    try:
        from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC
        
        secrets = get_secret()
        vid = secrets["VERACODE_VID"]
        vkey = secrets["VERACODE_VKEY"]
        
        api_base = "https://api.veracode.com/appsec/v1"
        url = f"{api_base}/applications?custom_field_names=Application Key&custom_field_values={TEST_APPCI}&size=200"
        headers = {'Content-Type': 'application/json'}
        
        logger.info(f"About to call Veracode API for AppCI: {TEST_APPCI}")
        logger.info(f"URL: {url}")
        
        response = requests.get(
            url,
            auth=RequestsAuthPluginVeracodeHMAC(api_key_id=vid, api_key_secret=vkey),
            headers=headers,
            timeout=30
        )
        
        logger.info(f"Veracode API Response Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            apps = data.get('_embedded', {}).get('applications', [])
            log_and_collect("info", f"✓ VERACODE API SUCCESS - Found {len(apps)} applications for {TEST_APPCI}", {"app_count": len(apps)})
            if apps:
                logger.info(f"Sample app names: {[app.get('profile', {}).get('name', 'Unknown') for app in apps[:3]]}")
                # Log only safe, non-sensitive fields
                first_app = apps[0]
                safe_data = {
                    "profile_name": first_app.get('profile', {}).get('name', 'N/A'),
                    "guid": first_app.get('guid', 'N/A'),
                    "has_scans": len(first_app.get('scans', [])) > 0
                }
                log_and_collect("info", f"First application sample fields: {json.dumps(safe_data, indent=2)}", {"sample_data": safe_data})
            return True
        else:
            log_and_collect("error", f"✗ VERACODE API FAILED - Status: {response.status_code}", {"status_code": response.status_code})
            logger.error(f"Response: {response.text[:500]}")
            return False
            
    except ImportError:
        log_and_collect("error", "✗ VERACODE API SKIPPED - veracode_api_signing module not available")
        return False
    except Exception as e:
        log_and_collect("error", f"✗ VERACODE API EXCEPTION: {str(e)}", {"exception": str(e)})
        return False


def test_netsparker():
    """Test Netsparker API (DAST)"""
    log_and_collect("info", "=" * 80)
    log_and_collect("info", "TESTING NETSPARKER API (DAST)")
    log_and_collect("info", "=" * 80)
    
    try:
        secrets = get_secret()
        userid = secrets["NETSPARKER_USERID"]
        token = secrets["NETSPARKER_TOKEN"]
        
        url = "https://www.netsparkercloud.com/api/1.0/scanprofiles/list?page=1&pageSize=10"
        
        logger.info(f"About to call Netsparker API")
        logger.info(f"URL: {url}")
        
        response = requests.get(
            url=url,
            auth=HTTPBasicAuth(userid, token),
            timeout=30
        )
        
        logger.info(f"Netsparker API Response Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            profiles = data.get('List', [])
            log_and_collect("info", f"✓ NETSPARKER API SUCCESS - Retrieved {len(profiles)} scan profiles", {"profile_count": len(profiles)})
            if profiles:
                # Log the first 3 profiles to show actual data structure
                sample_profiles = []
                for i, profile in enumerate(profiles[:3]):
                    # Get all keys from the profile to understand the structure
                    profile_keys = list(profile.keys()) if isinstance(profile, dict) else []
                    logger.info(f"Profile {i+1} keys: {profile_keys}")
                    
                    # Create safe data dict with available fields
                    safe_profile = {}
                    for key in profile_keys:
                        if key.lower() not in ['password', 'token', 'key', 'secret', 'credential']:
                            value = profile.get(key)
                            # Truncate long string values
                            if isinstance(value, str) and len(value) > 100:
                                safe_profile[key] = value[:100] + "..."
                            else:
                                safe_profile[key] = value
                    sample_profiles.append(safe_profile)
                
                log_and_collect("info", f"First 3 profile samples: {json.dumps(sample_profiles, indent=2)}", {"sample_data": sample_profiles})
            return True
        else:
            log_and_collect("error", f"✗ NETSPARKER API FAILED - Status: {response.status_code}", {"status_code": response.status_code})
            logger.error(f"Response: {response.text[:500]}")
            return False
            
    except Exception as e:
        log_and_collect("error", f"✗ NETSPARKER API EXCEPTION: {str(e)}", {"exception": str(e)})
        return False


def test_github():
    """Test GitHub API"""
    log_and_collect("info", "=" * 80)
    log_and_collect("info", "TESTING GITHUB API")
    log_and_collect("info", "=" * 80)
    
    try:
        secrets = get_secret()
        key = secrets["Git-App-Key"].replace('\\n', '\n')
        clientid = secrets["Git-App-ClientID"]
        installid = secrets["Git-App-InstallID"]
        
        # Generate JWT
        logger.info("Generating GitHub JWT token")
        payload = {
            'iat': int(time.time()),
            'exp': int(time.time()) + 590,
            'iss': clientid
        }
        jwt_token = jwt.encode(payload, key, algorithm='RS256')
        
        # Get installation token
        logger.info("Getting GitHub installation token")
        headers = {
            'Authorization': f'Bearer {jwt_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        token_url = f"https://api.github.com/app/installations/{installid}/access_tokens"
        token_response = requests.post(token_url, headers=headers, timeout=30)
        token_data = token_response.json()
        access_token = token_data.get('token')
        
        if not access_token:
            logger.error("✗ GITHUB API FAILED - Could not get installation token")
            return False
        
        # Search for repositories by AppCI
        api_base = "https://api.github.com/search/"
        query_string = f"props.AppCI:{TEST_APPCI} org:United-Airlines-Org archived:false"
        url = f"{api_base}repositories?q={urllib.parse.quote(query_string)}&per_page=10"
        
        search_headers = {
            "Authorization": f"token {access_token}",
            "Accept": "application/vnd.github+json"
        }
        
        logger.info(f"About to call GitHub API for AppCI: {TEST_APPCI}")
        logger.info(f"URL: {url}")
        
        response = requests.get(url, headers=search_headers, timeout=30)
        
        logger.info(f"GitHub API Response Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            repos = data.get('items', [])
            log_and_collect("info", f"✓ GITHUB API SUCCESS - Found {len(repos)} repositories for {TEST_APPCI}", {"repo_count": len(repos)})
            if repos:
                logger.info(f"Sample repos: {[repo.get('full_name', 'Unknown') for repo in repos[:3]]}")
                # Log only safe, non-sensitive fields (no tokens/credentials)
                first_repo = repos[0]
                safe_data = {
                    "full_name": first_repo.get('full_name', 'N/A'),
                    "name": first_repo.get('name', 'N/A'),
                    "private": first_repo.get('private', 'N/A'),
                    "description": (first_repo.get('description', 'N/A') or 'N/A')[:100]
                }
                log_and_collect("info", f"First repository sample fields: {json.dumps(safe_data, indent=2)}", {"sample_data": safe_data})
            return True
        else:
            log_and_collect("error", f"✗ GITHUB API FAILED - Status: {response.status_code}", {"status_code": response.status_code})
            logger.error(f"Response: {response.text[:500]}")
            return False
            
    except Exception as e:
        log_and_collect("error", f"✗ GITHUB API EXCEPTION: {str(e)}", {"exception": str(e)})
        return False


def main():
    """Main execution function"""
    log_and_collect("info", "=" * 80)
    log_and_collect("info", "STARTING EXTERNAL NETWORK API TESTS")
    log_and_collect("info", f"Test AppCI: {TEST_APPCI}", {"test_appci": TEST_APPCI})
    log_and_collect("info", f"Timestamp: {datetime.now().isoformat()}", {"timestamp": datetime.now().isoformat()})
    log_and_collect("info", "=" * 80)
    
    results = {}
    
    # Run all tests
    tests = [
        ("ServiceNow", test_servicenow),
        ("Veracode", test_veracode),
        ("Netsparker", test_netsparker),
        ("GitHub", test_github)
    ]
    
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            logger.error(f"CRITICAL ERROR in {test_name}: {str(e)}")
            results[test_name] = False
        
        # Add spacing between tests
        logger.info("")
    
    # Summary
    log_and_collect("info", "=" * 80)
    log_and_collect("info", "TEST SUMMARY")
    log_and_collect("info", "=" * 80)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        log_and_collect("info", f"{test_name:20s}: {status}", {"test": test_name, "passed": result})
    
    logger.info("-" * 80)
    log_and_collect("info", f"Results: {passed}/{total} tests passed", {"passed": passed, "total": total, "success_rate": f"{(passed/total)*100:.1f}%"})
    logger.info("=" * 80)
    
    # Write logs to JSON file if enabled
    if JSONLOG:
        output_file = f"extnettest_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        try:
            with open(output_file, 'w') as f:
                json.dump({
                    "test_run": {
                        "timestamp": datetime.now().isoformat(),
                        "test_appci": TEST_APPCI,
                        "total_tests": total,
                        "passed": passed,
                        "failed": total - passed,
                        "overall_success": passed == total
                    },
                    "test_results": results,
                    "log_entries": log_entries
                }, f, indent=2)
            logger.info(f"JSON log file written to: {output_file}")
        except Exception as e:
            logger.error(f"Failed to write JSON log file: {str(e)}")
    
    return passed == total


def handler(event=None, context=None):
    """Lambda handler function for external network testing"""
    try:
        success = main()
        return {
            "statusCode": 200 if success else 500,
            "body": json.dumps({
                "success": success,
                "message": "External network tests completed",
                "timestamp": datetime.now().isoformat()
            })
        }
    except Exception as e:
        logger.error(f"Handler error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            })
        }


if __name__ == "__main__":
    try:
        success = main()
        log_and_collect("info", f"Test execution completed: {'SUCCESS' if success else 'FAILURE'}", {"overall_success": success})
    except KeyboardInterrupt:
        log_and_collect("info", "\n\nTest interrupted by user")
    except Exception as e:
        log_and_collect("error", f"\n\nFATAL ERROR: {str(e)}", {"exception": str(e)})
import json
import boto3
from botocore.exceptions import ClientError
import requests
from logger import logger

REGION = "us-east-1"
SNOW_SECRET_NAME = "eqa-snow-secret"
HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}

def get_snow_secret():
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        response = client.get_secret_value(SecretId=SNOW_SECRET_NAME)
        return json.loads(response['SecretString'])
    except ClientError as e:
        logger.error(f"Error retrieving secret: {e}")
        raise

def get_all_policy_statements():
    secrets = get_snow_secret()
    snow_url = secrets['snow_url']
    snow_user = secrets['snow_user']
    snow_password = secrets['snow_password']
    
    endpoint = f"{snow_url}/api/now/table/sn_compliance_policy_statement"
    
    all_records = []
    offset = 0
    limit = 1000
    
    logger.info("Fetching data from ServiceNow...")
    
    while True:
        params = {
            'sysparm_limit': limit,
            'sysparm_offset': offset
        }
        
        try:
            response = requests.get(
                endpoint,
                auth=(snow_user, snow_password),
                headers=HEADERS,
                params=params
            )
            
            if response.status_code != 200:
                logger.error(f"Error: Status code {response.status_code}")
                logger.error(f"Response: {response.text}")
                break
            
            data = response.json()
            records = data.get('result', [])
            
            if not records:
                break
            
            all_records.extend(records)
            logger.info(f"Retrieved {len(records)} records (Total: {len(all_records)})")
            
            if len(records) == 0:
                break
            
            offset += limit
            
        except Exception as e:
            logger.error(f"Error fetching data: {e}")
            break
    
    logger.info(f"Total records retrieved: {len(all_records)}")
    return all_records

def get_sysid_mapping():
    try:
        policy_statements = get_all_policy_statements()
        
        filtered_data = [
            {
                "reference": record.get("reference", ""),
                "sys_id": record.get("sys_id", "")
            }
            for record in policy_statements
        ]
        
        mapping = {item['reference']: item['sys_id'] for item in filtered_data if item.get('reference') and item.get('sys_id')}
        logger.info(f"Created mapping with {len(mapping)} entries")
        
        # with open('udcrm_sysid_mapping.json', 'w') as f:
        #     json.dump(filtered_data, f, indent=2)
        # logger.info("Mapping written to udcrm_sysid_mapping.json")
        
        return mapping
        
    except Exception as e:
        logger.error(f"Error getting sys_id mapping: {e}")
        raise

def main():
    try:
        policy_statements = get_all_policy_statements()
        
        filtered_data = [
            {
                "reference": record.get("reference", ""),
                "sys_id": record.get("sys_id", "")
            }
            for record in policy_statements
        ]
        
        logger.info(f"Mapping ready with {len(filtered_data)} entries")
        
        with open('udcrm_sysid_mapping.json', 'w') as f:
            json.dump(filtered_data, f, indent=2)
        logger.info("Mapping written to udcrm_sysid_mapping.json")
        
    except Exception as e:
        logger.error(f"Error in main: {e}")
        raise

if __name__ == "__main__":
    main()

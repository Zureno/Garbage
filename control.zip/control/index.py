import os
import json
import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Attr
from control import get_num_validators_tools, get_control_confidence
from config import CONFIG
from logger import logger
from get_udcrm_sysid import get_sysid_mapping

def scan_all(table):
    items = []
    response = table.scan()
    items.extend(response.get('Items', []))
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
    return items

def delete_controls_not_in_files(table, controls_in_files):
    items = scan_all(table)
    controls_in_files_set = set(controls_in_files)
    with table.batch_writer() as batch:
        for item in items:
            control_key = item.get('control')
            if control_key and control_key not in controls_in_files_set:
                batch.delete_item(Key={'control': control_key})

def delete_all_records(table):
    items = scan_all(table)
    with table.batch_writer() as batch:
        for item in items:
            control_key = item.get('control')
            if control_key:
                batch.delete_item(Key={'control': control_key})

def ingest_files(directory):
    controls = []
    for file in os.listdir(directory):
        path = os.path.join(directory, file)
        if os.path.isfile(path) and file.endswith(".json"):
            with open(path, 'r', encoding='utf-8') as control_file:
                controls = controls + json.load(control_file)
    
    return controls 

def load_udcrm_sysid_mapping():
    try:
        mapping = get_sysid_mapping()
        logger.info(f"Loaded {len(mapping)} UDCRM sys_id mappings from ServiceNow")
        return mapping
    except Exception as e:
        logger.error(f"Error loading UDCRM sys_id mapping: {e}")
        return {}

def add_udcrm_sysid_attribute(control, sysid_mapping):
    control_ref = control.get('control', '')
    if control_ref in sysid_mapping:
        sys_id = sysid_mapping[control_ref]
        
        if 'attributes' not in control:
            control['attributes'] = []
        
        control['attributes'].append({
            "name": "udcrmsysid",
            "value": sys_id,
            "groupId": 999
        })
        logger.info(f"Added udcrmsysid attribute to control {control_ref}: {sys_id}")

def prepareDBItems(control):
    if "control" not in control:
        raise ValueError("Item is missing the required control used for primary key.")
    num_validation_types = get_num_validators_tools(control)
    confidence = get_control_confidence(num_validation_types)
    control.update({"confidence":confidence})

    dynamodbItem = {k:(json.dumps(v) if k == 'validators' else v)
                    for k, v in control.items()}
    return dynamodbItem

def get_ual_env():
    return os.getenv("UAL_ENV", "").lower()

def handler(event, context):
    folder_path = os.path.join(os.path.dirname(__file__), "appsecrequirements")
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('eqa-control-table')

    controls = ingest_files(folder_path)
    
    sysid_mapping = load_udcrm_sysid_mapping()
    for control in controls:
        add_udcrm_sysid_attribute(control, sysid_mapping)
    
    controls_in_files = [control['control'] for control in controls if 'control' in control]

    ual_env = None if CONFIG.get("ENV", "").lower() == "local" else get_ual_env()
    if CONFIG.get("ENV", "").lower() == "local":
        delete_controls_not_in_files(table, controls_in_files)
    elif ual_env == "dev":
        delete_all_records(table)
        logger.info("Deleted all records from control table for dev environment.")
    else:
        delete_controls_not_in_files(table, controls_in_files)

    dynamoDBItems = [prepareDBItems(control) for control in controls]

    for obj in dynamoDBItems:
        try:
            control_key = obj['control']
            update_fields = {k: v for k, v in obj.items() if k != 'control'}
            update_expr = "SET " + ", ".join([f"#{k} = :{k}" for k in update_fields])
            expr_attr_names = {f"#{k}": k for k in update_fields}
            expr_attr_values = {f":{k}": v for k, v in update_fields.items()}

            table.update_item(
                Key={'control': control_key},
                UpdateExpression=update_expr,
                ExpressionAttributeNames=expr_attr_names,
                ExpressionAttributeValues=expr_attr_values
            )
            logger.info(f"Successfully updated {control_key}")
        except ClientError as e:
            error = f"Error updating {obj} control in DynamoDB"
            raise ValueError(error)

if __name__ == '__main__':
    handler({}, {})
import json

def get_all_validation_types(controls):
    types = []
    for control in controls:
        validators = control['validators']
        for details in validators:
            if details["type"] not in types:
                types.append(details["type"])
    return types

def get_all_tool_types(controls):
    tools = []
    for control in controls:
        validators = control['validators']
        for details in validators:
            if "tool" in details:
                if details["tool"] not in tools:
                    tools.append(details["tool"])
    return tools

def get_control_confidence(num_validation_types):
    confidence_mapping = {1:"low", 2:"medium"}
    confidence = confidence_mapping.get(num_validation_types, 
                                        "high" if num_validation_types >= 3
                                        else "NA")
    
    return confidence

def get_num_validators_tools(control):
    num_validations = len(get_all_validation_types([control]))
    num_tools = len(get_all_tool_types([control]))
    return num_validations+num_tools
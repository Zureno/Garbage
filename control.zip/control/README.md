# Controls.Json

The Controls json files serves as a central repository for managing ASVS ( Application Security Verification Standard) controls with in United. Each control defines the criteria for validating application’s security posture against industry standard practices.
  
## This document explains:
 
1. The structure of the controls.json file.
2. Key attributes for each ASVS control.
3. How the validation process works using the defined attributes.
4. How the services consume this file.
 
## Structure of controls.json:
 
The file is a JSON array, where each entry represents an ASVS control with the following key-value pairs:
 
Control : Unique identifier for the ASVS control( e.g., V14.4.5)
Chapter_name: indicates the category through which the control will be validated
 
#### Possible values:
- Configuration
- Sanitization
- Encoding
- Architecture
- Design
- Threat Modeling etc..
Description: Detailed explanation of the control and what it aims to achieve
( e.g., Verify that a Strict-Transport-Security header is included on all responses and for all subdomains, such as Strict-Transport-Security: max-age=15724800; includeSubdomains."
)
 
Definition: Specifies the validation logic.
- ALL: All validators must pass for the control to be considered validated
- ANY: At least one validator must pass for the control to be considered validated
Validators: A list of validators that will be used to validate.  Each validator in turn specifies the criteria and tool used to validate the control.
Criteria: List of criteria that will be checked in order to validate the control
CWE: Indicates the Common Weakness Enumeration(CWE)
Type: Specifies the area where the criteria will be collected and checked
(e.g., findings, pipeline etc..)
   
Index.py script developed and runs as cron job to upload all controls from controls.json file to AWS DynamoDB table called eqa-control-table. 
This table is used by ASVS dashboard to determine which controls are applicable to each individual AppCI.
This storage eliminates the need for multiple versions of controls.json as different ASVS automation services rely on list of controls recorded in controls.json.

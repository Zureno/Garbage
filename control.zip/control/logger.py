from aws_lambda_powertools import Logger

# Singleton logger for control-lambda
logger = Logger(service="control-lambda")

"""Core Venafi validation logic and evidence building."""

from logger import logger


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate(mapping: dict, raw: list) -> bool:
    """Validate Venafi findings against the control mapping criteria.

    Supported criteria:
      - "check_onboarded": passes when raw findings list is non-empty
        (i.e. the AppCI has at least one certificate registered in Venafi)

    Unknown criteria are skipped with a warning.

    Returns True (pass) or False (fail).
    """
    success = False

    try:
        for criteria in mapping.get("criteria", []):
            if criteria == "check_onboarded":
                if raw:
                    success = True
                    logger.info(
                        f"Venafi check_onboarded PASSED — {len(raw)} certificate(s) found"
                    )
                else:
                    logger.info("Venafi check_onboarded FAILED — no certificates found")
            else:
                logger.warning(f"Unknown Venafi criteria '{criteria}'; skipping.")
                continue

    except Exception as error:
        logger.warning(f"Error in Venafi validate(): {error}")
        raise SystemError("Error occurred in Venafi validator while checking certificates")

    logger.info(f"Venafi validation result: success={success}")
    return success


# ---------------------------------------------------------------------------
# Evidence building
# ---------------------------------------------------------------------------

def build_evidence(
    control_name: str,
    identifier: str,
    criteria: list,
    passed: bool,
    findings: list,
) -> tuple[str, str]:
    """Return (raw_evidence, evidence) strings.

    raw_evidence — detailed message stored in DynamoDB.
    evidence     — human-oriented message sent to ServiceNow.
    """
    count = len(findings) if findings else 0

    if passed:
        raw_evidence = (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has passed because the following criteria passed: {criteria}. "
            f"Found {count} certificate(s) registered in Venafi."
        )
        evidence = "This requirement has passed; no action is required."
    else:
        raw_evidence = (
            f"Validation of requirement {control_name} for AppCI {identifier} "
            f"has failed because the following criteria failed: {criteria}. "
            f"No certificates found in Venafi for this AppCI."
        )
        criteria_str = ", ".join(str(c) for c in criteria if str(c).strip())
        if criteria_str:
            evidence = f"Venafi-fail: {criteria_str}"
        else:
            evidence = "Venafi-fail: This control has not been implemented yet"

    return raw_evidence, evidence


# ---------------------------------------------------------------------------
# Finding ID extraction
# ---------------------------------------------------------------------------

def extract_finding_ids(findings: list) -> str:
    """Return a comma-separated string of Venafi object DNs (finding identifiers)."""
    if not findings:
        return ""
    ids = [
        str(f.get("DN", f.get("Name", "")))
        for f in findings
        if f.get("DN") or f.get("Name")
    ]
    return ", ".join(ids)

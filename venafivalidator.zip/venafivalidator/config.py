CONFIG = {
    "ENV": "dev",          # Change to "local" for local testing
    "REGION": "us-east-1",
    "RESULTS_TABLE": "eqa-validation-results-table",
    "CONTROL_TABLE": "eqa-control-table",
    "SECRETS_ID": "eqa-evidence-integrations",
}

"""
index.py
Lambda entry point for the standalone Venafi Validator microservice.

Flow:
  1. input.py   — parse the Lambda event
  2. data.py    — fetch Venafi certificate findings via TPP API
  3. validate.py — match findings against the control criteria
  4. validate.py — build evidence strings
  5. output.py  — assemble result dict and write to DynamoDB
"""

import boto3
from logger import logger
from config import CONFIG
from input import extract_lambda_input
from output import build_lambda_output, build_sort_key, write_validator_result
from data import VenafiData
from validate import validate, build_evidence, extract_finding_ids
from helpers import get_control_confidence, check_snow_limit

ENV = CONFIG["ENV"]

# ---------------------------------------------------------------------------
# DynamoDB
# ---------------------------------------------------------------------------
_dynamodb = boto3.resource("dynamodb", region_name=CONFIG["REGION"])
_results_table = _dynamodb.Table(CONFIG["RESULTS_TABLE"])
_control_client = boto3.client("dynamodb", region_name=CONFIG["REGION"])


def handler(event: dict, context) -> dict:
    """Lambda entry point."""
    logger.info(f"Event received: {event}")

    # ---- 1. Parse input --------------------------------------------------
    identifier, control_name, validator = extract_lambda_input(event)

    criteria = validator.get("criteria", [])
    validator_type = validator.get("type", "venafi")

    # ---- 2. Fetch Venafi findings via TPP API ----------------------------
    venafi_data = VenafiData()
    findings = venafi_data.get_venafi_findings(identifier)
    logger.info(
        f"Fetched {len(findings) if findings else 0} Venafi finding(s) for {identifier}"
    )

    # ---- 3. Run validation -----------------------------------------------
    passed = validate(validator, findings)
    status_label = "PASS" if passed else "FAIL"

    # ---- 4. Build evidence -----------------------------------------------
    raw_evidence, evidence = build_evidence(
        control_name, identifier, criteria, passed, findings
    )

    # ---- 5. Extract finding IDs ------------------------------------------
    finding_ids = extract_finding_ids(findings)

    # ---- 6. Build the validation detail record ---------------------------
    validation_record = {
        "type": validator_type,
        "criteria": criteria,
        "identifier": identifier,
        "name": control_name,
        "status": status_label,
    }

    # ---- 7. Determine confidence (single validation type → "low") --------
    confidence = get_control_confidence(1)

    # ---- 8. Determine review_required from control table -----------------
    review_required = "No"
    try:
        response = _control_client.get_item(
            TableName=CONFIG["CONTROL_TABLE"],
            Key={"control": {"S": control_name}},
        )
        item = response.get("Item", {})
        skip_failure = item.get("skip_failure", {}).get("BOOL", False)
        skip_pass    = item.get("skip_pass",    {}).get("BOOL", False)
        if skip_failure and not passed:
            review_required = "Yes"
        if skip_pass and passed:
            review_required = "Yes"
    except Exception as exc:
        logger.warning(f"Could not read control table record for '{control_name}': {exc}")

    # ---- 9. Build normalised output --------------------------------------
    number = 1 if passed else 0
    result = build_lambda_output(
        control=control_name,
        passed=passed,
        avit=[],
        number=number,
        confidence=confidence,
        validations=[validation_record],
        raw_evidence=raw_evidence,
        evidence=evidence,
        finding_ids=finding_ids,
        review_required=review_required,
    )

    # Apply ServiceNow size limit
    result = check_snow_limit(result)

    # ---- 10. Persist to DynamoDB -----------------------------------------
    sort_key = build_sort_key(control_name, validator)
    write_validator_result(_results_table, identifier, sort_key, result)

    logger.info(
        f"Venafi validation complete — control={control_name}, "
        f"identifier={identifier}, passed={passed}"
    )
    return result


# ---------------------------------------------------------------------------
# Local testing
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import json    
    test_event = {
        "identifier": "AQQ",
        "control": "CDR-DS3.5.2-App03",
        "validator": {
            "type": "venafi",
            "criteria": ["check_onboarded"],
        },
    }

    print("\n=== Test Event ===")
    print(json.dumps(test_event, indent=2))
    print("==================\n")

    result = handler(test_event, None)

    print("\n=== Result ===")
    print(json.dumps(result, indent=2))
    print("==============\n")

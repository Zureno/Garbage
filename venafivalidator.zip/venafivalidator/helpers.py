"""Helper utilities for the Venafi validator Lambda.

Contains:
  - get_secret()            — fetch credentials from Secrets Manager
  - get_control_confidence() — map validation count to confidence label
  - check_snow_limit()      — truncate raw_evidence if it exceeds 4 000 chars
"""

import json
import boto3
from botocore.exceptions import ClientError

from logger import logger
from config import CONFIG


# ---------------------------------------------------------------------------
# Secrets Manager
# ---------------------------------------------------------------------------

def get_secret(secret_id: str = None) -> dict:
    """Fetch and return the named secret as a dict."""
    secret_id = secret_id or CONFIG["SECRETS_ID"]
    session = boto3.session.Session()
    client = session.client(
        service_name="secretsmanager",
        region_name=CONFIG["REGION"],
    )
    try:
        response = client.get_secret_value(SecretId=secret_id)
    except ClientError as e:
        logger.error(f"Error fetching secret '{secret_id}': {e}")
        raise
    return json.loads(response["SecretString"])


# ---------------------------------------------------------------------------
# Confidence + ServiceNow size limit
# ---------------------------------------------------------------------------

def get_control_confidence(num_validation_types: int) -> str:
    """Map the number of distinct validation types to a confidence label."""
    mapping = {1: "low", 2: "medium"}
    return mapping.get(num_validation_types, "high" if num_validation_types >= 3 else "NA")


def check_snow_limit(control_status: dict) -> dict:
    """Truncate raw_evidence if it exceeds the ServiceNow 4 000-char limit."""
    limit_msg = (
        "Size limit exceeded. Review output in Value field "
        "for more information about this control validation."
    )
    if "raw_evidence" in control_status:
        if len(str(control_status["raw_evidence"])) > 4000:
            control_status["raw_evidence"] = limit_msg
    return control_status

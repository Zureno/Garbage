"""Venafi data layer — fetches certificate findings from the Venafi TPP API."""

import json
import re
import tempfile
import requests
from typing import Dict, Optional

from logger import logger
from config import CONFIG
from helpers import get_secret

# ---------------------------------------------------------------------------
# Venafi TPP connection constants
# ---------------------------------------------------------------------------

TPP_API_SCOPE = "configuration"
TPP_API_CLIENTID = "venafiAuthToken"
TPP_HOSTNAME = "venafi.ual.com"
BASE_URL = f"https://{TPP_HOSTNAME}"


# ---------------------------------------------------------------------------
# CA Bundle — pulled from Secrets Manager at module load
# ---------------------------------------------------------------------------

def _build_ca_bundle() -> str:
    """Pull the Venafi CA cert from Secrets Manager, write to a temp .pem file."""
    import re

    evidence_secret = get_secret(CONFIG["SECRETS_ID"])
    pem_raw = evidence_secret["VENAFI_CERTIFICATE"]

    # ── Normalize any escaped newlines ──
    pem_raw = pem_raw.replace("\\n", "\n")
    pem_raw = pem_raw.replace("\r\n", "\n")

    # ── Extract the raw base64 between BEGIN/END markers ──
    match = re.search(
        r"-----BEGIN CERTIFICATE-----(.*?)-----END CERTIFICATE-----",
        pem_raw,
        re.DOTALL,
    )
    if not match:
        raise ValueError("VENAFI_CA_CERT does not contain a valid PEM certificate")

    raw_b64 = match.group(1)

    # Remove ALL whitespace (spaces, newlines, tabs, etc.)
    raw_b64 = re.sub(r"\s+", "", raw_b64)

    # Re-wrap at 64 characters per line (PEM standard)
    wrapped = "\n".join(raw_b64[i:i+64] for i in range(0, len(raw_b64), 64))

    # Rebuild proper PEM
    pem_text = f"-----BEGIN CERTIFICATE-----\n{wrapped}\n-----END CERTIFICATE-----\n"

    # ── Write to temp file ──
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pem", mode="w")
    tmp.write(pem_text)
    tmp.flush()
    tmp.close()

    logger.info(f"CA bundle written to temp file: {tmp.name}")

    # Debug: verify format
    lines = pem_text.strip().split("\n")
    logger.debug(f"PEM first line: {lines[0]}")
    logger.debug(f"PEM last line:  {lines[-1]}")
    logger.debug(f"PEM total lines: {len(lines)}")

    return tmp.name

CA_BUNDLE = _build_ca_bundle()


# ---------------------------------------------------------------------------
# Low-level HTTP client
# ---------------------------------------------------------------------------

class VenafiAPIClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        self.access_token = None

    def get_oauth_token(self, username: Optional[str] = None, password: Optional[str] = None):
        uri = f"{self.base_url}/vedauth/authorize/oauth"
        payload = {
            "client_id": TPP_API_CLIENTID,
            "username": username,
            "password": password,
            "scope": "certificate:manage,discover;configuration:manage",
        }

        logger.debug(f"Requesting OAuth token from {uri}")

        try:
            response = requests.post(uri, json=payload, verify=CA_BUNDLE)
            response.raise_for_status()
            auth_data = response.json()

            self.access_token = auth_data.get("access_token")
            self.headers["Authorization"] = f"Bearer {self.access_token}"

            logger.info("OAuth token obtained successfully")
            return auth_data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get OAuth token: {str(e)}")
            raise

    def config_find_objects_of_class(self, class_name: str, search_start: str, recursive: bool = False) -> Dict:
        uri = f"{self.base_url}/vedsdk/Config/FindObjectsOfClass"
        payload = {
            "Class": class_name,
            "ObjectDN": search_start,
            "Recursive": str(recursive).lower(),
        }

        logger.debug(f"FindObjectsOfClass request: {json.dumps(payload, indent=2)}")

        try:
            response = requests.post(uri, headers=self.headers, json=payload, verify=CA_BUNDLE)
            response.raise_for_status()
            result = response.json()
            logger.debug(f"FindObjectsOfClass response: Found {len(result.get('Objects', []))} objects")
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Config-FindObjectsOfClass failed: {str(e)}")
            raise

    def metadata_find_item(self, name: str) -> Dict:
        uri = f"{self.base_url}/vedsdk/Metadata/Find"
        payload = {"ItemGuid": name}

        logger.debug(f"Metadata-FindItem request: {name}")

        try:
            response = requests.post(uri, headers=self.headers, json=payload, verify=CA_BUNDLE)
            response.raise_for_status()
            result = response.json()
            logger.debug(f"Metadata-FindItem response: {json.dumps(result, indent=2)}")
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Metadata-FindItem failed: {str(e)}")
            raise

    def metadata_find(self, item_guid: str, value: str) -> Dict:
        uri = f"{self.base_url}/vedsdk/Metadata/Find"
        payload = {"ItemGuid": item_guid, "Value": value}

        logger.debug(f"Metadata-Find request: {json.dumps(payload, indent=2)}")

        try:
            response = requests.post(uri, headers=self.headers, json=payload, verify=CA_BUNDLE)
            response.raise_for_status()
            result = response.json()
            logger.debug(f"Metadata-Find response: Found {len(result.get('Objects', []))} objects")
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Metadata-Find failed: {str(e)}")
            raise

    def metadata_get_all_items(self) -> Dict:
        """GET all custom metadata field definitions to discover correct field names."""
        uri = f"{self.base_url}/vedsdk/Metadata/Items"

        try:
            response = requests.get(uri, headers=self.headers, verify=CA_BUNDLE)
            response.raise_for_status()
            result = response.json()
            return result
        except requests.exceptions.RequestException as e:
            logger.error(f"Metadata-Items failed: {str(e)}")
            raise


# ---------------------------------------------------------------------------
# Helper: search Venafi by AppCI metadata field
# ---------------------------------------------------------------------------

def find_appci_using_metadata_find(base_url, custom_field_name, appci_identifier, username, password):
    client = VenafiAPIClient(base_url)
    client.get_oauth_token(username, password)

    item_response = client.metadata_get_all_items()

    custom_field_guid = None
    for item in item_response.get("Items", []):
        if item.get("Label") == custom_field_name:
            custom_field_guid = item.get("Guid")
            logger.info(f"Resolved '{custom_field_name}' -> GUID: {custom_field_guid}")
            break

    if not custom_field_guid:
        logger.error(f"Could not resolve GUID for custom field '{custom_field_name}'.")
        return []

    # Format matches the field's regex: ApplicationCI:xxx (lowercase)
    search_value = f"ApplicationCI:{appci_identifier.lower()},*"

    try:
        result = client.metadata_find(item_guid=custom_field_guid, value=search_value)
        objects = result.get("Objects", [])
        logger.info(f"Found {len(objects)} objects for AppCI '{appci_identifier}'")
        return objects
    except Exception as e:
        logger.error(f"Search failed for AppCI '{appci_identifier}': {e}", exc_info=True)
        return []


# ---------------------------------------------------------------------------
# Public data class
# ---------------------------------------------------------------------------

class VenafiData:
    def __init__(self):
        evidence_secret = get_secret(CONFIG["SECRETS_ID"])
        self.password = evidence_secret["VENAFI_KEY"]
        self.username = evidence_secret["VENAFI_USERNAME"]
        self.base_url = BASE_URL

    def get_venafi_findings(self, identifier: str):
        logger.info(f"Checking if AppCI '{identifier}' is onboarded in Venafi")

        results = find_appci_using_metadata_find(
            base_url=self.base_url,
            custom_field_name="AWS CI",
            appci_identifier=identifier,
            username=self.username,
            password=self.password,
        )

        count = len(results)
        logger.info(f"AppCI '{identifier}' -> {count} certificate(s) found in Venafi")
        return results

"""
input.py
Parses the Lambda event into the three required fields:
  - identifier  (AppCI / asset identifier)
  - control     (control name, e.g. "CDR-NSS3.4.2 - App01")
  - validator   (dict with type, criteria, scope, etc.)

Supports two event formats:
  A) SNS-triggered  - event has a "Records" key
  B) Direct / QA    - event is the payload itself
"""

import json
from logger import logger


def extract_lambda_input(event: dict) -> tuple[str, str, dict]:
    # --- Format A/B: SQS or SNS-triggered ---
    if "Records" in event:
        try:
            record = event["Records"][0]
            if "body" in record:
                raw = record["body"]
                logger.info("Parsed SQS message body")
            else:
                raw = record["Sns"]["Message"]
                logger.info("Parsed SNS message body")
            body = json.loads(raw)
        except (KeyError, IndexError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not parse message from event: {exc}") from exc
    # --- Format C: Direct / QA ---
    else:
        body = event
        logger.info(f"Direct invocation body: {body}")

    identifier: str = body.get("identifier", "")
    control: str    = body.get("control", "")
    validator       = body.get("validator")

    # Coerce validator to dict if it arrived as a JSON string
    if isinstance(validator, str):
        try:
            validator = json.loads(validator)
        except json.JSONDecodeError as exc:
            raise ValueError(f"'validator' is not valid JSON: {exc}") from exc

    # Guard: all three fields are mandatory
    missing = [
        name for name, val in
        [("identifier", identifier), ("control", control), ("validator", validator)]
        if not val
    ]
    if missing:
        raise ValueError(f"Missing required field(s): {missing}")

    if not isinstance(validator, dict):
        raise ValueError(
            f"'validator' must be a dict, got {type(validator).__name__}"
        )

    logger.info(
        f"Input — identifier: {identifier!r}, "
        f"control: {control!r}, "
        f"validator type: {validator.get('type')!r}"
    )
    return identifier, control, validator

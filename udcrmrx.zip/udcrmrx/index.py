import json
import boto3
from botocore.exceptions import ClientError
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from logger import logger

REGION = "us-east-1"
SNOW_SECRET_NAME = "eqa-snow-secret"
CONTROL_TABLE_NAME = "eqa-control-table"
PROCESSING_TABLE_NAME = "eqa-cdr-processing-table"
HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}

def get_snow_secret():
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=REGION
    )
    try:
        response = client.get_secret_value(SecretId=SNOW_SECRET_NAME)
        return json.loads(response['SecretString'])
    except ClientError as e:
        logger.error(f"Error retrieving secret: {e}")
        raise

def scan_control_table():
    dynamodb = boto3.resource('dynamodb', region_name=REGION)
    table = dynamodb.Table(CONTROL_TABLE_NAME)
    
    items = []
    response = table.scan()
    items.extend(response.get('Items', []))
    
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
    
    logger.info(f"Scanned {len(items)} items from control table")
    return items

def extract_sysids(items):
    sysids = set()
    
    for item in items:
        attributes = item.get('attributes', [])
        
        if isinstance(attributes, str):
            try:
                attributes = json.loads(attributes)
            except:
                pass
        
        if isinstance(attributes, list):
            for attr in attributes:
                if attr.get('name') == 'udcrmsysid':
                    sysid = attr.get('value')
                    if sysid:
                        sysids.add(sysid)
    
    logger.info(f"Found {len(sysids)} unique udcrmsysid values")
    return list(sysids)

def query_snow_endpoint(sysid, snow_url, snow_user, snow_password):
    endpoint = f"{snow_url}/api/sn_compliance/aws_control_automation/get_ctrls_under_ctrl_obj"
    
    params = {'ctrl_obj_sys_id': sysid}
    
    try:
        response = requests.get(
            endpoint,
            auth=(snow_user, snow_password),
            headers=HEADERS,
            params=params
        )
        
        if response.status_code == 200:
            data = response.json()
            result_data = data.get('result', data)
            controls_count = len(result_data.get('controls', [])) if isinstance(result_data, dict) else 0
            logger.info(f"Successfully queried sysid: {sysid} - Found {controls_count} controls")
            return data
        else:
            logger.error(f"Error querying sysid {sysid}: Status code {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Exception querying sysid {sysid}: {e}")
        return None

def write_results_to_json(results, filename='udcrm_rx_results.json'):
    if not results:
        logger.info("No results to write")
        return
    
    with open(filename, 'w') as jsonfile:
        json.dump(results, jsonfile, indent=2)
    
    logger.info(f"Results written to {filename}")

def extract_profile_mapping(results):
    mapping = []
    
    for result in results:
        ctrl_obj_sys_id = result.get('ctrl_obj_sys_id')
        data = result.get('data', {})
        
        controls = []
        if 'controls' in data:
            controls = data['controls']
        elif 'result' in data and isinstance(data['result'], dict) and 'controls' in data['result']:
            controls = data['result']['controls']
        
        profile_sys_ids = [c.get('profile_sys_id') for c in controls if c.get('profile_sys_id')]
        
        mapping.append({
            'ctrl_obj_sys_id': ctrl_obj_sys_id,
            'profile_sys_ids': profile_sys_ids
        })
        
        logger.info(f"{ctrl_obj_sys_id}: {len(profile_sys_ids)} profile_sys_ids")
    
    return mapping

def write_profile_mapping_to_json(mapping, filename='udcrm_profile_mapping.json'):
    with open(filename, 'w') as jsonfile:
        json.dump(mapping, jsonfile, indent=2)
    
    logger.info(f"Profile mapping written to {filename}")

def scan_processing_table():
    dynamodb = boto3.resource('dynamodb', region_name=REGION)
    table = dynamodb.Table(PROCESSING_TABLE_NAME)
    
    items = []
    response = table.scan()
    items.extend(response.get('Items', []))
    
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
    
    logger.info(f"Scanned {len(items)} items from processing table")
    return items

def build_identifier_updates(all_mappings, processing_items):
    entity_sys_id_map = {}
    for item in processing_items:
        entity_sys_id = item.get('entitySysID')
        if entity_sys_id:
            entity_sys_id_map[entity_sys_id] = item
    
    identifier_updates = {}
    
    for mapping in all_mappings:
        ctrl_obj_sys_id = mapping.get('ctrl_obj_sys_id')
        profile_sys_ids = mapping.get('profile_sys_ids', [])
        
        for profile_sys_id in profile_sys_ids:
            if profile_sys_id in entity_sys_id_map:
                identifier = entity_sys_id_map[profile_sys_id]
                identifier_key = identifier['identifier']
                
                if identifier_key not in identifier_updates:
                    identifier_updates[identifier_key] = {
                        'identifier': identifier,
                        'ctrl_obj_sys_ids': []
                    }
                
                identifier_updates[identifier_key]['ctrl_obj_sys_ids'].append(ctrl_obj_sys_id)
    
    logger.info(f"Built update plan for {len(identifier_updates)} identifiers")
    return identifier_updates

def apply_updates_to_identifiers(identifier_updates, max_workers=20):
    dynamodb = boto3.resource('dynamodb', region_name=REGION)
    table = dynamodb.Table(PROCESSING_TABLE_NAME)
    
    total_updates = 0
    total_attributes_added = 0
    
    def update_single_identifier(identifier_key, update_info):
        identifier = update_info['identifier']
        ctrl_obj_sys_ids = update_info['ctrl_obj_sys_ids']
        
        attributes = identifier.get('attributes', [])
        if not isinstance(attributes, list):
            attributes = []
        
        existing_udcrm_values = [
            attr.get('value')
            for attr in attributes 
            if attr.get('name') == 'udcrmsysid'
        ]
        
        new_ctrl_obj_sys_ids = [
            ctrl_id for ctrl_id in ctrl_obj_sys_ids 
            if ctrl_id not in existing_udcrm_values
        ]
        
        if not new_ctrl_obj_sys_ids:
            logger.info(f"Identifier {identifier_key} already has all udcrmsysid values, skipping")
            return 0, 0
        
        for ctrl_obj_sys_id in new_ctrl_obj_sys_ids:
            new_attribute = {
                "name": "udcrmsysid",
                "value": ctrl_obj_sys_id
            }
            attributes.append(new_attribute)
        
        try:
            table.update_item(
                Key={'identifier': identifier_key},
                UpdateExpression='SET attributes = :attrs',
                ExpressionAttributeValues={':attrs': attributes}
            )
            logger.info(f"Updated identifier {identifier_key} with {len(new_ctrl_obj_sys_ids)} udcrmsysid attributes")
            return 1, len(new_ctrl_obj_sys_ids)
        except ClientError as e:
            logger.error(f"Error updating identifier {identifier_key}: {e}")
            return 0, 0
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(update_single_identifier, key, info) for key, info in identifier_updates.items()]
        for future in as_completed(futures):
            updates, attributes_added = future.result()
            total_updates += updates
            total_attributes_added += attributes_added
    
    logger.info(f"Completed: Updated {total_updates} identifiers with {total_attributes_added} total attributes")
    return total_updates, total_attributes_added

def process_single_sysid(sysid, snow_url, snow_user, snow_password):
    logger.info(f"Processing sysid: {sysid}")

    
    data = query_snow_endpoint(sysid, snow_url, snow_user, snow_password)
    
    if not data:
        logger.error(f"No data returned for {sysid}")
        return None
    
    # filename = f"sysid_{sysid}.json"
    # with open(filename, 'w') as f:
    #     json.dump(data, f, indent=2)
    # print(f"Wrote full response to {filename}")
    
    result_data = data.get('result', {})
    control_objective = result_data.get('control_objective', {})
    controls = control_objective.get('controls', [])
    
    profile_sys_ids = []
    for control in controls:
        profile_sys_id = control.get('profile_sys_id')
        if profile_sys_id:
            profile_sys_ids.append(profile_sys_id)
    
    logger.info(f"Extracted {len(profile_sys_ids)} profile_sys_ids")
    if profile_sys_ids:
        logger.info(f"First 3: {profile_sys_ids[:3]}")
    
    return {
        'ctrl_obj_sys_id': sysid,
        'profile_sys_ids': profile_sys_ids
    }

def handler(event=None, context=None):
    try:
        secrets = get_snow_secret()
        snow_url = secrets['snow_url']
        snow_user = secrets['snow_user']
        snow_password = secrets['snow_password']
        
        items = scan_control_table()
        
        sysids = extract_sysids(items)
        
        if not sysids:
            logger.info("No udcrmsysid values found in control table")
            return
        
        all_mappings = []
        for sysid in sysids:
            mapping = process_single_sysid(sysid, snow_url, snow_user, snow_password)
            if mapping:
                all_mappings.append(mapping)
        
        # write_profile_mapping_to_json(all_mappings)
        
        logger.info("Scanning processing table once for all updates")
        processing_items = scan_processing_table()
        
        logger.info("Building update plan for all identifiers")
        identifier_updates = build_identifier_updates(all_mappings, processing_items)
        
        logger.info("Applying all updates to processing table")
        total_updates, total_attributes = apply_updates_to_identifiers(identifier_updates)

        logger.info(f"Summary: Processed {len(all_mappings)} sysids")
        total_profiles = sum(len(m['profile_sys_ids']) for m in all_mappings)
        logger.info(f"Total profile_sys_ids extracted: {total_profiles}")
        logger.info(f"Total identifiers updated: {total_updates}")
        logger.info(f"Total attributes added: {total_attributes}")

        
    except Exception as e:
        logger.error(f"Error in main: {e}")
        raise

if __name__ == "__main__":
    event = {}
    context = {}
    handler(event, context)
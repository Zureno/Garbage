import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone
from logger import logger

TABLE_NAME = "eqa-status-overwrite-table"

def _parse_opened_at(value):
    v = (value or "").strip()
    if not v:
        return 0, ""

    # Try ISO8601 first (tolerate trailing Z and T separator)
    try:
        iso_val = v.replace("Z", "+00:00")
        dt = datetime.fromisoformat(iso_val)
        # If naive, treat as UTC to avoid local-time dependence
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_utc = dt.astimezone(timezone.utc)
        return int(dt_utc.timestamp()), dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        pass

    # Fallback: explicit "YYYY-MM-DD HH:MM:SS" without TZ — treat as UTC
    try:
        dt = datetime.strptime(v, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        dt_utc = dt.astimezone(timezone.utc)
        return int(dt_utc.timestamp()), dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        return 0, v

def _dedupe_latest(overrides):
    latest = {}
    for r in overrides:
        control = r.get("control_id")
        identifier = r.get("identifier")
        if not control or not identifier:
            continue
        key = (control, identifier)
        ts, _ = _parse_opened_at(r.get("opened_at", ""))
        existing = latest.get(key)
        if not existing:
            latest[key] = r
        else:
            ex_ts, _ = _parse_opened_at(existing.get("opened_at", ""))
            if ts >= ex_ts:
                latest[key] = r
    return list(latest.values())

def write_overrides_to_table(overrides, table_name = TABLE_NAME):
    dynamo = boto3.resource("dynamodb")
    table = dynamo.Table(table_name)
    items = _dedupe_latest(overrides)
    written = 0
    written_items = []
    for r in items:
        control = r.get("control_id")
        identifier = r.get("identifier")
        if not control or not identifier:
            continue
        new_ts, opened_iso = _parse_opened_at(r.get("opened_at", ""))
        try:
            table.update_item(
                Key={"control": control, "identifier": identifier},
                UpdateExpression=(
                    "SET ritm = :ritm, sys_id = :sys_id, override_result = :ovr, "
                    "opened_at = :opened, opened_at_ts = :ts, #state = :state, #description = :desc, last_processed = :lp"
                ),
                ConditionExpression="attribute_not_exists(control) OR opened_at_ts <= :ts",
                ExpressionAttributeValues={
                    ":ritm": r.get("ritm"),
                    ":sys_id": r.get("sys_id"),
                    ":ovr": r.get("override_result"),
                    ":opened": opened_iso,
                    ":ts": new_ts,
                    ":state": "Closed",
                    ":desc": r.get("description"),
                    ":lp": r.get("last_processed"),
                },
                ExpressionAttributeNames={
                    "#state": "state",
                    "#description": "description",
                },
                ReturnValues="NONE",
            )
            written += 1
            written_items.append({
                "control_id": control,
                "identifier": identifier,
                "ritm": r.get("ritm"),
                "sys_id": r.get("sys_id"),
                "opened_at": opened_iso,
                "state": "Closed",
                "description": r.get("description"),
            })
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                logger.info({"status": "skipped_older_override", "control": control, "identifier": identifier})
                continue
            raise
    logger.info({"status": "write_overrides_to_table", "written": written})
    return {"written_count": written, "written_items": written_items}

CONFIG = {
    "ENV": "dev",                          # Change to "local" for local testing
    "REGION": "us-east-1",
    "RESULTS_TABLE": "eqa-validation-results-table",
    "CWE_TABLE": "eqa-cwe-mappings-table",
    "SECRETS_ID": "eqa-evidence-integrations",
    "GITHUB_ORG": "United-Airlines-Org",
    "GITHUB_API": "https://api.github.com",
}

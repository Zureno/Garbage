import requests
import jwt
import time
import boto3
from botocore.exceptions import ClientError
import urllib.parse
import json
import re
from logger import logger


class GhasData:

    def __init__(self):
        self.api_base = "https://api.github.com"
        self.search_api_base = "https://api.github.com/search/"
        self.token = None
        self.org = "United-Airlines-Org"
        self.token_expires_at = 0
        self.evidence_secrets = self._get_secret()
        self.key = self.evidence_secrets["Git-App-Key"].replace('\\n', '\n')
        self.clientid = self.evidence_secrets["Git-App-ClientID"]
        self.installid = self.evidence_secrets["Git-App-InstallID"]
        self._gen_new_gitaccess()

    def _get_secret(self, secret_id="eqa-evidence-integrations"):
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name='us-east-1'
        )
        try:
            response = client.get_secret_value(SecretId=secret_id)
        except ClientError as e:
            logger.error(f"Error fetching secret: {e}")
            raise e
        return json.loads(response['SecretString'])

    def _gen_new_gitaccess(self):
        self._generate_jwt()
        self._get_installation_token()
        self._get_headers()

    def _generate_jwt(self):
        payload = {
            'iat': int(time.time()),
            'exp': int(time.time()) + 590,
            'iss': self.clientid
        }
        self.jwt_token = jwt.encode(payload, self.key, algorithm='RS256')

    def _get_installation_token(self):
        headers = {
            'Authorization': f'Bearer {self.jwt_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        url = f"{self.api_base}/app/installations/{self.installid}/access_tokens"
        response = requests.post(url, headers=headers)
        data = response.json()
        self.token = data['token']
        # Tokens typically expire in 1 hour, but we'll set it conservatively
        self.token_expires_at = int(time.time()) + 3300  # 55 minutes
        logger.info(f"GitHub token refreshed, expires at {self.token_expires_at}")

    def _ensure_valid_token(self):
        """Check if token is expired and refresh if needed"""
        if int(time.time()) >= self.token_expires_at - 60:  # Refresh 1 min before expiry
            logger.info("GitHub token expired or expiring soon, refreshing...")
            self._gen_new_gitaccess()

    def _get_headers(self):
        self.headers = {
            "Authorization": "token {}".format(self.token),
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        }

    # -------------------------
    # Core public method
    # -------------------------

    def _get_repos_by_appci(self, appci):

        self._ensure_valid_token()
        query_string = f"props.AppCI:{appci} org:{self.org} archived:false"
        url = f"{self.search_api_base}repositories?q={urllib.parse.quote(query_string)}&per_page=100"
        repos = []

        try:
            response = requests.get(url, headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                for repo in data.get('items', []):
                    repo_full_name = repo['full_name']
                    if repo_full_name not in repos:
                        repos.append(repo_full_name)
                logger.info(f"Found {len(repos)} repositories for AppCI: {appci}")
            else:
                logger.warning(f"Error fetching repos for AppCI {appci}: {response.status_code} - {response.text}")
        except Exception as e:
            logger.error(f"Exception fetching repos for AppCI {appci}: {e}")
            return []

        return repos

    def _get_secret_scanning_alerts(self, repo_owner, repo_name):
        self._ensure_valid_token()
        url = f"{self.api_base}/repos/{repo_owner}/{repo_name}/secret-scanning/alerts"
        params = {
            'state': 'open',
            'secret_type': 'password',
            'per_page': 100
        }
        all_alerts = []

        try:
            while url:
                response = requests.get(url, headers=self.headers, params=params)

                if response.status_code == 200:
                    alerts = response.json()
                    all_alerts.extend(alerts)

                    # Handle pagination via Link header
                    if 'Link' in response.headers:
                        links = response.headers['Link'].split(',')
                        url = None
                        for link in links:
                            if 'rel="next"' in link:
                                url = link[link.find('<')+1:link.find('>')]
                                params = None  # params are baked into the next URL
                                break
                    else:
                        url = None

                elif response.status_code == 404:
                    logger.warning(f"Secret scanning not enabled or accessible for {repo_owner}/{repo_name}")
                    break
                elif response.status_code == 401:
                    logger.error(f"Auth failed for {repo_owner}/{repo_name}, refreshing token...")
                    self._gen_new_gitaccess()
                    continue
                else:
                    logger.warning(f"Error fetching secret scanning alerts for {repo_owner}/{repo_name}: {response.status_code} - {response.text}")
                    break

        except Exception as e:
            logger.error(f"Exception fetching secret scanning alerts for {repo_owner}/{repo_name}: {e}")
            return []

        return all_alerts

    def get_ghas_findings(self, appci):
        try:
            if not appci:
                raise Exception("Parameter appci is mandatory")

            repos = self._get_repos_by_appci(appci)

            if not repos:
                logger.info(f"No repositories found for AppCI: {appci}")
                return []

            all_alerts = []

            for repo_full_name in repos:
                parts = repo_full_name.split('/')
                if len(parts) != 2:
                    logger.warning(f"Skipping invalid repo name: {repo_full_name}")
                    continue

                repo_owner, repo_name = parts

                try:
                    alerts = self._get_secret_scanning_alerts(repo_owner, repo_name)
                    for alert in alerts:
                        alert["repo_name"] = repo_full_name  # normalize same as before
                    all_alerts.extend(alerts)

                except Exception as e:
                    logger.warning(f"Error processing alerts for {repo_full_name}: {e}")
                    continue

            logger.info(f"Total GHAS secret scanning findings for AppCI {appci}: {len(all_alerts)}")
            return all_alerts

        except Exception as error:
            logger.error(error)
            raise Exception(f"Could not get GHAS findings for appci: {appci}. Error={error}")
"""
index.py
Lambda entry point for the standalone Ghas Validator microservice.

Flow:
  1. input.py     - parse the Lambda event
  2. data.py      - fetch Ghas findings from GitHub
  3. validator.py - match findings against the control criteria
  4. evidence.py  - build human-readable evidence strings
  5. output.py    - assemble result dict and write to DynamoDB
"""

from input     import extract_lambda_input
from data      import GhasData
from validator import GhasValidator
from evidence  import build_raw_evidence, build_evidence, build_finding_ids
from output    import build_result, build_sort_key, write_validator_result
from logger import logger
import json
import boto3

dynamodb = boto3.client('dynamodb',region_name = "us-east-1")

def handler(event: dict, context) -> dict:
    logger.info(f"Event received: {event}")

    # ------------------------------------------------------------------
    # 1. Parse input
    # ------------------------------------------------------------------
    try:
       identifier, control, validator = extract_lambda_input(event)
    except ValueError as exc:
        logger.error(f"Input parsing failed: {exc}")
        return {"error": str(exc), "status": "FAILED"}

    # ------------------------------------------------------------------
    # 2. Fetch Ghas findings
    # ------------------------------------------------------------------
    try:
        findings = GhasData().get_ghas_findings(identifier)
        
    except Exception as exc:
        logger.error(f"Data fetch failed: {exc}")
        return {"error": str(exc), "status": "FAILED"}

    # ------------------------------------------------------------------
    # 3. Run validation
    # ------------------------------------------------------------------
    try:

        # validators = json.loads(response['Item']['validators']['S'])[0]

        success, avits, exception, evidence_internal = GhasValidator().validate(
            validator, findings
        )
        
    except Exception as exc:
        logger.error(f"Validation failed: {exc}")
        return {"error": str(exc), "status": "FAILED"}

    # ------------------------------------------------------------------
    # 4. Determine pass/fail status and confidence
    # ------------------------------------------------------------------
    if exception:
        status_str = "NA"
        passed     = False
    elif success is True:
        status_str = "PASS"
        passed     = True
    else:
        status_str = "FAIL"
        passed     = False

    # Build the single validation entry (mirrors process.py structure)
    validation_entry = {
        "type":               validator.get("type", "ghas"),
        "scope":              validator.get("scope", ""),
        "criteria":           validator.get("criteria", []),
        "identifier":         identifier,
        "name":               control,
        "status":             status_str,
        "_evidence_internal": evidence_internal,
    }

    validations = [validation_entry]

    # ------------------------------------------------------------------
    # 5. Build evidence strings
    # ------------------------------------------------------------------
    raw_evidence = build_raw_evidence(control, identifier, passed, validations)
    evidence_msg = build_evidence(validation_entry)
    finding_ids  = build_finding_ids(evidence_internal)

    # review_required — honour skip_pass / skip_failure 

    # Pull skip_failure and skip_pass from the control table item


    response = dynamodb.get_item(
        TableName='eqa-control-table',
        Key={'control': {'S': control}}
    )    
    item = response.get('Item', {})
    skip_failure = item.get('skip_failure', {}).get('BOOL', False)
    skip_pass    = item.get('skip_pass',    {}).get('BOOL', False)

    review_required = "No"
    if skip_failure and not passed:
        review_required = "Yes"
    if skip_pass and passed:
        review_required = "Yes"

    # ------------------------------------------------------------------
    # 6. Assemble and persist result
    # ------------------------------------------------------------------
    result = build_result(
        control          = control,
        passed           = passed,
        avit             = avits,
        number           = 1 if passed else 0,
        confidence       = "",
        validations      = validations,
        raw_evidence     = raw_evidence,
        evidence         = evidence_msg,
        finding_ids      = finding_ids,
        review_required  = review_required,
    )

    sort_key = build_sort_key(control, validator)

    try:
        write_validator_result(identifier, sort_key, result)
    except ValueError as exc:
        logger.error(f"Failed to write result: {exc}")
        return {"error": str(exc), "status": "FAILED"}

    logger.info(f"Validation complete — control: {control}, passed: {passed}")
    return result


# '''
# #FOR TESTING

# if __name__ == '__main__':

#     # Your real control object
#     control_data = {
#     "identifier": "DXE",
#     "control": "CDR-DS3.5.2-App02",
#     "validator": {
#         "criteria": [
#         ],
#         "type": "ghas"
#     }
#     }

#     validator = control_data["validator"]
#     print(type(validator))

#     event = {
#         "identifier": control_data["identifier"]  ,
#         "control": control_data["control"],
#         "validator": validator
#     }

#     response = handler(event, None)
#     print(response)
# # '''
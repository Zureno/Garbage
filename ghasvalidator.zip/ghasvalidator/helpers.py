"""
helpers.py
Shared utility functions:
  - DynamoDB full-table scan with pagination
  - CWE description lookup with in-memory cache
"""

import boto3
from config import CONFIG
from logger import logger

# ---------------------------------------------------------------------------
# DynamoDB paginated scan
# ---------------------------------------------------------------------------

def scan_all(table):
    """Scan all items from a DynamoDB table, handling pagination."""
    items = []
    resp = table.scan()
    items.extend(resp.get("Items", []))
    while "LastEvaluatedKey" in resp:
        resp = table.scan(ExclusiveStartKey=resp["LastEvaluatedKey"])
        items.extend(resp.get("Items", []))
    return items


# ---------------------------------------------------------------------------
# CWE description cache + lookup
# ---------------------------------------------------------------------------

_cwe_items_cache = None   # { cwe_id_str: dynamo_item }
_cwe_desc_cache  = {}     # { (cwe_id_str, source_str): description | None }


def _load_cwe_cache():
    """Lazily load all CWE mapping records from DynamoDB into memory."""
    global _cwe_items_cache
    if _cwe_items_cache is not None:
        return _cwe_items_cache
    try:
        dynamodb = boto3.resource("dynamodb")
        table    = dynamodb.Table(CONFIG["CWE_TABLE"])
        all_items = scan_all(table)
        _cwe_items_cache = {
            str(it.get("cwe_id")): it
            for it in all_items
            if "cwe_id" in it
        }
    except Exception as exc:
        logger.warning(f"Could not load CWE cache: {exc}")
        _cwe_items_cache = {}
    return _cwe_items_cache


def get_cwe_description(cwe_id: str, source: str) -> str | None:
    """
    Return the CWE name from the mappings table when the record's
    source matches the requested source ('codeql').
    Returns None if not found.
    """
    cache_key = (str(cwe_id), str(source).lower())
    if cache_key in _cwe_desc_cache:
        return _cwe_desc_cache[cache_key]

    items = _load_cwe_cache()
    item  = items.get(str(cwe_id))
    if not item:
        _cwe_desc_cache[cache_key] = None
        return None

    if str(item.get("source", "")).lower() == str(source).lower():
        desc = str(item.get("cwe_name", "")).strip() or None
        _cwe_desc_cache[cache_key] = desc
        return desc

    _cwe_desc_cache[cache_key] = None
    return None
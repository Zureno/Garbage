from logger import logger


class GhasValidator:
    def validate(self, mapping, vulns):
        # Fails if any open secret scanning alert is found.
        exception = False
        avits = []
        evidence = {
            "scan_type": "ghas",
            "avit_ids": [],
            "FindingIDs": []
        }

        try:
            if not vulns:
                return True, avits, exception, evidence

            for alert in vulns:
                if str(alert.get("state", "")).strip().lower() != "open":
                    continue

                secret_type = str(alert.get("secret_type", "")).strip()
                repo_name = str(alert.get("repo_name", "")).strip()
                html_url = str(alert.get("html_url", "")).strip()
                
                if repo_name:
                    repo_url = f"https://github.com/{repo_name}/security/secret-scanning"
                    if repo_url not in evidence["FindingIDs"]:
                        evidence["FindingIDs"].append(repo_url)
                        logger.info(f"GHAS validation FAILED — open secret alert detected: {secret_type} in repo {repo_name}")

                avit_id = secret_type or html_url
                if avit_id and avit_id not in avits:
                    avits.append(avit_id)

        except Exception as e:
            logger.error(f"Exception during GHAS validation: {e}")
            exception = True
            evidence["avit_ids"] = list(avits)
            return "NA", avits, exception, evidence

        success = not bool(avits)
        evidence["avit_ids"] = list(avits)
        return success, avits, exception, evidence